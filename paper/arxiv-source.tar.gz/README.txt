PLLM arXiv source bundle

Compile main.tex directly with pdfLaTeX. The bibliography and figures are embedded; no shell escape, network access, or repository files are required. This paper reports the current offline-inventory runtime identified in main.tex. The included JSON contains the public workload manifest, environment, exact measurements, and limitations.
