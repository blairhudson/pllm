from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import os
import posixpath
import secrets
import sys
import tempfile
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from collections import OrderedDict, defaultdict, deque
from collections.abc import AsyncIterator, Iterator
from contextlib import AbstractContextManager, contextmanager
from contextvars import ContextVar, copy_context
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Generic, Mapping, TypeVar
from urllib.parse import quote, urlparse, urlunparse

import httpx
import msgpack
import numpy as np
from filelock import FileLock
from pllm import _native

from .secure_random import FieldRandom
from .bundle_compression import (
    ENCODING as BUNDLE_ENCODING,
    BundleFrameError,
    decode_bundle_frames,
)
from .bundle_artifacts import (
    ENCODING as ARTIFACT_ENCODING,
    MAX_MANIFEST_BYTES,
    MAX_RAW_BYTES as MAX_ARTIFACT_RAW_BYTES,
    ArtifactError,
    configure_artifact_cache,
    parse_manifest,
    reconstruct_document,
)
from .prefill_cache import ExactPrefillCache, prefill_key
from .http_response import owned_response

from .bfv_correlations import BFVCorrelationClient, he_worker_threads
from .masked_runtime import (
    CorrelationPool,
    ModelError,
    MaskCorrelation,
    MaskedBigramClientModel,
    MaskedBigramClientSession,
    MaskedLinearRequest,
    MaskedLinearResponse,
    centered_mod,
)
from .protocol import (
    ProtocolEnvelope,
    encode_length_prefixed,
    iter_length_prefixed,
    pack_envelope,
    unpack_envelope,
)
from .preparation_protocol import (
    PREPARATION_ACCOUNTING_CAPABILITY,
    PREPARATION_ACCOUNTING_HEADER,
    PreparationAck,
    PreparationRequest,
    SessionAuthorization,
    SessionAuthorizationAck,
    freivalds_binding,
    freivalds_material_id,
    freivalds_session_id,
)
from .stage_protocol import (
    BlindedStageCorrelation,
    BlindedStageRequest,
    BlindedStageResponse,
    DirectFHEStageRequest,
    DirectFHEStageResponse,
    blinded_correlation_from_wire,
    prepared_stage_batch_rows,
)
from .quantization import dequantize_matmul, quantize_activation_per_row, signed_qmax
from .transformer_client import (
    ClientBundle,
    MaskedTransformerClientRuntime,
    PreparedInventory,
    PreparedInventoryLease,
    PreparedStageRows,
    RemoteLinear,
    RuntimeSnapshot,
    StageClientStats,
    StageMetadata,
    PreparedRemoteLinear,
    TransformerClientError,
)
from .responses import ResponsesError, normalize_input, prompt_text
from .tools import ParsedModelOutput, parse_model_output, tool_policy
from .security import derive_session_key
from .tokenizer import AlphabetTokenizer, Tokenizer
from .types import Response, ResponseEvent, ResponseUsage, new_id

if TYPE_CHECKING:
    from .conversation import AsyncConversation, Conversation
    from pllm.state.decode import DecodeCache
    from pllm.configuration import Experiment, ExperimentProfile, Model
    from pllm.runtime.model_binding import CompiledRuntimeModel
    from pllm.runtime.transformer_engine import MaskedTransformerEngine

T = TypeVar("T")

_BUNDLE_CACHE_MODES = {"read-write", "read-only", "refresh", "off"}
_MAX_CLIENT_BUNDLE_BYTES = 8 * 1024 * 1024 * 1024


class _ScopedTokenizer:
    """At most one admitted bundle's tokenizer, owned by an explicit request scope."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._bundle: ClientBundle | None = None
        self._tokenizer: Tokenizer | None = None
        self._closed = False

    def get(self, bundle: ClientBundle, factory=None) -> Tokenizer:
        with self._lock:
            if self._closed:
                raise RuntimeError("tokenizer scope is closed")
            if self._bundle is not bundle:
                # A model/bundle change cannot reuse a previous source's vocabulary.
                self._bundle = None
                close = getattr(self._tokenizer, "close", None)
                if close is not None:
                    close()
                self._tokenizer = None
                self._tokenizer = bundle.tokenizer() if factory is None else factory(bundle)
                self._bundle = bundle
            assert self._tokenizer is not None
            return self._tokenizer

    def close(self) -> None:
        with self._lock:
            self._closed = True
            close = getattr(self._tokenizer, "close", None)
            if close is not None:
                close()
            self._tokenizer = None
            self._bundle = None


def _response_contract_fields(body: dict[str, Any], *, max_output_tokens: int) -> dict[str, Any]:
    text = body.get("text")
    if not isinstance(text, dict):
        text = {"format": {"type": "text"}, "verbosity": "medium"}
    return {
        "instructions": body.get("instructions"),
        "metadata": body.get("metadata"),
        "parallel_tool_calls": bool(body.get("parallel_tool_calls", True)),
        "frequency_penalty": float(body.get("frequency_penalty") or 0.0),
        "presence_penalty": float(body.get("presence_penalty") or 0.0),
        "top_logprobs": int(body.get("top_logprobs") or 0),
        "max_tool_calls": body.get("max_tool_calls"),
        "reasoning": body.get("reasoning"),
        "safety_identifier": body.get("safety_identifier"),
        "prompt_cache_key": body.get("prompt_cache_key"),
        "temperature": body.get("temperature", 1.0),
        "top_p": body.get("top_p", 1.0),
        "max_output_tokens": max_output_tokens,
        "tools": tuple(body.get("tools") or ()),
        "tool_choice": body.get("tool_choice", "auto"),
        "truncation": str(body.get("truncation", "disabled")),
        "previous_response_id": body.get("previous_response_id"),
        "prompt": None,
        "background": bool(body.get("background", False)),
        "service_tier": str(body.get("service_tier", "default")),
        "store": bool(body.get("store", True)),
        "text": dict(text),
    }


def _sampling_temperature(body: dict[str, Any]) -> float:
    value = body.get("temperature")
    return 0.8 if value is None else float(value)


def _default_bundle_cache_dir() -> Path:
    base = Path(os.getenv("XDG_CACHE_HOME", Path.home() / ".cache"))
    return base / "pllm" / "client-bundles"


def _normalized_inference_endpoint(value: str) -> str:
    parsed = urlparse(value)
    if (
        parsed.scheme.lower() not in {"http", "https"}
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.params
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("base_url must be an HTTP(S) URL")
    scheme = parsed.scheme.lower()
    host = parsed.hostname.lower()
    port = parsed.port
    if port is not None and port != (443 if scheme == "https" else 80):
        host = f"[{host}]:{port}" if ":" in host else f"{host}:{port}"
    elif ":" in host:
        host = f"[{host}]"
    path = posixpath.normpath(parsed.path or "/")
    if not path.startswith("/"):
        path = "/" + path
    return f"{scheme}://{host}{path.rstrip('/') or '/'}"


class ProtocolError(RuntimeError):
    def __init__(self, message: str, status_code: int = 500, body: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class _BundleIntegrityError(ProtocolError):
    pass


class _NoProviderHTTP:
    """Fail closed if provider controls are called for a client-owned plan."""

    def __getattr__(self, _name: str) -> Any:
        raise ProtocolError("client-only topology has no provider endpoint", 400)


def _raise_cleanup_errors(errors: list[BaseException], primary: BaseException | None = None) -> None:
    if not errors:
        return
    error = primary if primary is not None else errors[0]
    for secondary in errors if primary is not None else errors[1:]:
        error.add_note(f"cleanup failed: {type(secondary).__name__}: {secondary}")
    if primary is None:
        raise error


def _cleanup_calls(calls, *, primary: BaseException | None = None) -> None:
    errors = []
    for call in calls:
        try:
            call()
        except BaseException as error:
            errors.append(error)
    _raise_cleanup_errors(errors, primary)


class ResponseStream(Generic[T]):
    def __init__(self, iterator: Iterator[T], close: Callable[[], None] | None = None,
                 *, terminal: Callable[[str], None] | None = None) -> None:
        self.iterator = iterator
        self._close = close
        self._closed = False
        self._terminal = terminal

    def __iter__(self) -> "ResponseStream[T]":
        return self

    def __next__(self) -> T:
        event = next(self.iterator)
        if self._terminal is not None and event.type in {"response.completed", "response.incomplete"}:
            self._terminal(event.response["id"])
        return event

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        callback, self._close = self._close, None
        try:
            iterator_close = getattr(self.iterator, "close", None)
            if iterator_close is not None:
                iterator_close()
        finally:
            if callback is not None:
                callback()

    def __enter__(self) -> "ResponseStream[T]":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


@dataclass(slots=True)
class PrivacyAudit:
    plaintext_prompt_bytes_sent: int = 0
    plaintext_token_ids_sent: int = 0
    public_context_bytes: int = 0
    encrypted_correlation_upload_bytes: int = 0
    encrypted_correlation_download_bytes: int = 0
    masked_online_upload_bytes: int = 0
    masked_online_download_bytes: int = 0
    correlation_count: int = 0
    online_steps: int = 0
    inference_stage_calls: int = 0
    token_lookup_cache_hits: int = 0
    token_lookup_cache_misses: int = 0
    kv_continuation_hits: int = 0
    kv_continuation_batched_hits: int = 0
    kv_continuation_legacy_sequential_hits: int = 0
    kv_continuation_misses: int = 0
    prefill_cache_hits: int = 0
    prefill_cache_misses: int = 0
    prefill_prefix_tokens_reused: int = 0
    inflight_prefill_tokens_reused: int = 0
    inflight_producer_registrations: int = 0
    inflight_publications: int = 0
    inflight_joins: int = 0
    inflight_failures: int = 0
    inflight_cancellations: int = 0
    inflight_cancelled_producers: int = 0
    inflight_retired: int = 0
    inflight_copy_bytes: int = 0
    inflight_bound_rejections: int = 0
    inflight_cache_bypasses: int = 0
    inflight_reserved_bytes: int = 0
    inflight_peak_reserved_bytes: int = 0
    inflight_requests: int = 0
    inflight_nodes: int = 0
    inflight_pending_nodes: int = 0
    inflight_active_producers: int = 0
    _inflight_owner: Any = field(default=None, repr=False, compare=False)
    direct_fhe_upload_bytes: int = 0
    direct_fhe_download_bytes: int = 0
    direct_fhe_steps: int = 0
    preparation_upload_bytes: int = 0
    preparation_download_bytes: int = 0
    inference_upload_bytes: int = 0
    inference_download_bytes: int = 0
    generation_completed_responses: int = 0
    generation_output_tokens: int = 0
    generation_decode_output_tokens: int = 0
    generation_prefill_online_body_bytes: int = 0
    generation_decode_online_body_bytes: int = 0
    generation_requested_output_tokens: int = 0
    generation_executed_decode_steps: int = 0
    generation_attribution_supported_responses: int = 0
    preparation_attributed_body_bytes: int = 0
    preparation_decode_material_body_bytes: int = 0
    preparation_prefill_material_body_bytes: int = 0
    preparation_decode_rows_issued: int = 0
    preparation_prefill_rows_issued: int = 0
    preparation_padding_rows_issued: int = 0
    correction_ack_bytes: int = 0
    correction_ack_accounted_push_bytes: int = 0
    preparation_server_ns: int = 0
    inference_server_ns: int = 0
    correction_push_bytes: int = 0
    correction_push_ns: int = 0
    session_authorization_upload_bytes: int = 0
    session_authorization_download_bytes: int = 0
    preparation_attempts: int = 0
    preparation_rows: int = 0
    prepared_stage_rows_issued: int = 0
    prepared_stage_rows_reserved: int = 0
    prepared_stage_rows_claimed: int = 0
    prepared_stage_rows_burned: int = 0
    prepared_stage_rows_discarded: int = 0
    _inventory_lock: threading.Lock = field(default_factory=threading.Lock, repr=False, compare=False)
    preparation_requests_during_online: int = 0
    preparation_failures: int = 0
    inference_control_upload_bytes: int = 0
    inference_control_download_bytes: int = 0
    preparation_control_upload_bytes: int = 0
    preparation_control_download_bytes: int = 0
    decode_epochs_started: int = 0
    decode_epoch_pauses: int = 0
    decode_epoch_pause_ns: int = 0
    generation_requested_prefill_tokens: int = 0
    generation_requested_decode_steps: int = 0
    generation_remote_prefill_tokens: int = 0
    generation_remote_terminal_prefill_rows: int = 0
    generation_remote_decode_steps: int = 0
    decode_cache_root_hits: int = 0
    decode_cache_branch_hits: int = 0
    decode_cache_misses: int = 0
    decode_cache_skipped_remote_rows: int = 0
    decode_cache_skipped_prefill_tokens: int = 0
    decode_cache_skipped_decode_steps: int = 0
    decode_cache_fully_warm_responses: int = 0
    bundle_network_bytes: int = 0
    bundle_cache_hits: int = 0
    bundle_cache_misses: int = 0
    bundle_cache_corruptions: int = 0
    tokenizer_artifact_local_bytes: int = 0
    public_prefix_artifact_local_bytes: int = 0
    nonlinear_elements: int = 0
    nonlinear_chunks: int = 0
    nonlinear_party_key_bytes: int = 0
    nonlinear_peer_frame_bytes: int = 0
    nonlinear_client_issuance_ns: int = 0
    nonlinear_client_issuance_cpu_ns: int = 0
    private_boundary_lookup_rows: int = 0
    private_boundary_head_calls: int = 0
    private_boundary_lookup_upload_bytes: int = 0
    private_boundary_lookup_download_bytes: int = 0
    private_boundary_head_upload_bytes: int = 0
    private_boundary_head_download_bytes: int = 0
    private_boundary_body_coverage_failures: int = 0
    role_link_bodies: dict[str, dict[str, int]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, int]:
        values = {
            name: int(getattr(self, name))
            for name in self.__dataclass_fields__
            if name != "role_link_bodies" and not name.startswith("_")
        }
        for role, phases in self.role_link_bodies.items():
            for metric, count in phases.items():
                values[f"role_link.{role}.{metric}"] = int(count)
        if self._inflight_owner is not None:
            values.update({f"inflight_{name}": value
                           for name, value in self._inflight_owner.counters().items()})
        return values

    def record_inventory(self, name: str, count: int) -> None:
        with self._inventory_lock:
            setattr(self, name, getattr(self, name) + count)


class _Channel:
    def __init__(
        self, client: httpx.Client, base_url: str, api_key: str, session_id: str, mode: str,
        *, frame_limit: int | None = None, compression: str | None = "deflate",
    ) -> None:
        self.client = client
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.session_id = session_id
        self.mode = mode
        self.socket: Any = None
        self._send_pool = None
        self.frame_limit = frame_limit
        self.compression = compression

    def _http(self, payload: bytes) -> bytes:
        with owned_response(self.client.post(
            f"/v1/runtime/sessions/{self.session_id}/execute",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/vnd.pllm.runtime+msgpack",
            },
            content=payload,
        )) as response:
            _raise(response)
            return response.content

    def _connect(self) -> None:
        if self.socket is not None:
            return
        from websockets.sync.client import connect

        parsed = urlparse(self.base_url)
        path = f"{parsed.path.rstrip('/')}/v1/runtime/ws/{self.session_id}"
        url = urlunparse(
            ("wss" if parsed.scheme == "https" else "ws", parsed.netloc, path, "", "", "")
        )
        self.socket = connect(
            url,
            subprotocols=["pllm-runtime-v1"],
            additional_headers={"Authorization": f"Bearer {self.api_key}"},
            compression=self.compression,
            open_timeout=30,
            max_size=self.frame_limit,
            max_queue=2 if self.frame_limit else 16,
            close_timeout=5 if self.frame_limit else 10,
        )

    def exchange(self, payload: bytes) -> bytes:
        if self.mode == "http":
            return self._http(payload)
        if self.mode not in {"websocket", "auto"}:
            raise ValueError(f"unsupported runtime transport {self.mode!r}")
        if self.mode == "auto" and self.socket is None:
            try:
                self._connect()
            except Exception:
                self.mode = "http"
                return self._http(payload)
        else:
            self._connect()
        # Never retry an accepted frame over HTTP: the nonce may already be consumed.
        self.socket.send(payload)
        value = self.socket.recv()
        return value.encode() if isinstance(value, str) else bytes(value)

    def close(self) -> None:
        if self.socket is not None:
            self.socket.close()
            self.socket = None
        if self._send_pool is not None:
            self._send_pool.shutdown(wait=True, cancel_futures=True)
            self._send_pool = None

    def exchange_many(self, payloads: list[bytes]) -> list[bytes]:
        """One ordered sender plus receiver: allow both TCP directions to progress."""
        from concurrent.futures import ThreadPoolExecutor
        if (self.mode != "websocket" or not 1 <= len(payloads) <= 128
                or sum(map(len, payloads)) > 16 << 20):
            raise ProtocolError("duplex stage exceeds its WebSocket frame budget")
        self._connect()
        socket = self.socket
        if self._send_pool is None:
            self._send_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="pllm-stage-send")
        def send():
            try:
                for payload in payloads:
                    socket.send(payload)
            except BaseException:
                socket.close()
                raise
        future = self._send_pool.submit(send)
        try:
            results, result_bytes = [], 0
            for _ in payloads:
                value = socket.recv(timeout=30)
                if not isinstance(value, bytes) or len(value) > 16 << 20:
                    raise ProtocolError("duplex stage returned an invalid bounded binary frame")
                results.append(value)
                result_bytes += len(value)
                if result_bytes > 16 << 20:
                    raise ProtocolError("duplex stage exceeds its result-body budget")
            future.result()
            return results
        except BaseException:
            self.close()
            raise


@dataclass(slots=True)
class _ModelCryptoState:
    model: MaskedBigramClientModel
    mode: str
    pool: CorrelationPool
    rng: FieldRandom
    bfv: BFVCorrelationClient | None = None
    context_id: str | None = None
    lock: threading.Lock = field(default_factory=threading.Lock)


class _BFVStageClient:
    def __init__(
        self,
        *,
        plain_modulus: int,
        poly_modulus_degree: int = 4096,
        pydeps_path: str | None = None,
    ) -> None:
        if pydeps_path:
            import sys

            if pydeps_path not in sys.path:
                sys.path.insert(0, pydeps_path)
        import tenseal as ts

        self.ts = ts
        self.plain_modulus = int(plain_modulus)
        self.poly_modulus_degree = int(poly_modulus_degree)
        self.slot_count = max(1, int(poly_modulus_degree) // 2)
        self.n_threads = he_worker_threads()
        self.context = ts.context(
            ts.SCHEME_TYPE.BFV,
            poly_modulus_degree=poly_modulus_degree,
            plain_modulus=self.plain_modulus,
            encryption_type=ts.ENCRYPTION_TYPE.SYMMETRIC,
            n_threads=self.n_threads,
        )
        self.context.generate_galois_keys()
        self.public_context = self.context.serialize(
            save_public_key=True,
            save_secret_key=False,
            save_galois_keys=True,
            save_relin_keys=False,
        )

    def encrypt(self, mask: np.ndarray) -> bytes:
        values = np.asarray(mask, dtype=np.int64).reshape(-1) % self.plain_modulus
        chunks = [
            self.ts.bfv_vector(
                self.context, values[start : start + self.slot_count].tolist()
            ).serialize()
            for start in range(0, values.size, self.slot_count)
        ]
        return msgpack.packb(
            {
                "v": 2,
                "plain_modulus": self.plain_modulus,
                "size": int(values.size),
                "slot_count": self.slot_count,
                "chunks": chunks,
            },
            use_bin_type=True,
        )

    def decrypt(self, payload: bytes, *, stage_id: str) -> np.ndarray:
        value = msgpack.unpackb(payload, raw=False, strict_map_key=False)
        if int(value.get("v", 0)) != 1 or str(value.get("stage_id")) != stage_id:
            raise ModelError("invalid BFV stage correlation response")
        outputs = [
            int(self.ts.bfv_vector_from(self.context, item).decrypt()[0]) % self.plain_modulus
            for item in value["ciphertexts"]
        ]
        return np.asarray(outputs, dtype=np.uint32)


def _client_freivalds_policy(authorization, stages):
    if authorization.verification_component == "none":
        return None
    max_matrix = max(stage.in_features * stage.out_features for stage in stages)
    max_input = max(stage.in_features for stage in stages)
    max_output = max(stage.out_features for stage in stages)
    rows = authorization.rows
    checks = 8
    return _native.FreivaldsPolicy(
        authorization.verification_target_failure_bits,
        authorization.max_attempts,
        max_matrix,
        rows * checks * max_input,
        rows * checks * max_output,
        rows * max_output,
        max_matrix * rows * checks,
        rows,
        freivalds_session_id(authorization),
        True,
    )


@dataclass(slots=True)
class _TransformerCryptoState:
    bundle: ClientBundle
    bundle_fingerprint: str
    mode: str
    privacy_mode: str = "public"
    privacy_protocol: str = "masked_w4a4"
    queues: dict[str, deque[Any]] = field(default_factory=lambda: defaultdict(deque))
    locks: dict[str, threading.Lock] = field(default_factory=lambda: defaultdict(threading.Lock))
    rng: FieldRandom = field(default_factory=FieldRandom)
    bfv_clients: dict[int, _BFVStageClient] = field(default_factory=dict)
    context_ids: dict[int, str] = field(default_factory=dict)
    blinded_owner_id: str = field(default_factory=lambda: new_id("owner"))
    token_cache: OrderedDict[int, np.ndarray] = field(default_factory=OrderedDict)
    token_cache_lock: threading.Lock = field(default_factory=threading.Lock)
    prefill_cache: ExactPrefillCache | None = None
    public_prefix_binding: str | None = None
    prepared_inventory: PreparedInventory | None = None
    prepared_inventory_spare: PreparedInventory | None = None
    retired_inventories: list[PreparedInventory] = field(default_factory=list)
    active_prepared_responses: int = 0
    refill_in_progress: bool = False
    refill_future: Future[None] | None = field(default=None, repr=False)
    preparation_verified: bool = False


@dataclass(slots=True)
class _TransformerConversationState:
    model_id: str
    bundle_fingerprint: str
    token_ids: list[int]
    rendered_context: str
    snapshot: RuntimeSnapshot
    next_logits: np.ndarray
    pending_token_ids: list[int]


class _BlindedCorrelationProvider:
    """Client inventory for output-blinded proprietary correlations."""

    def __init__(
        self,
        *,
        client: "RuntimeClient",
        session_id: str,
        state: _TransformerCryptoState,
        prefetch: int,
    ) -> None:
        self.owner = client
        self.session_id = session_id
        self.state = state
        self.prefetch = max(1, int(prefetch))
        self.model_id = state.bundle.model_id

    def take_many(self, stage: StageMetadata, count: int) -> list[BlindedStageCorrelation]:
        with self.state.locks[stage.id]:
            queue = self.state.queues[stage.id]
            missing = count - len(queue)
            if missing > 0:
                queue.extend(self._create(stage, max(missing, self.prefetch)))
            if len(queue) < count:
                raise ModelError(f"proprietary correlation inventory exhausted for {stage.id}")
            values = [queue.popleft() for _ in range(count)]
            output: list[BlindedStageCorrelation] = []
            for item in values:
                if not isinstance(item, BlindedStageCorrelation):
                    raise ModelError("mixed correlation protocols in proprietary inventory")
                if item.consumed:
                    raise ModelError("proprietary correlation reuse detected")
                item.consumed = True
                output.append(item)
            return output

    def _context(self, modulus: int) -> tuple[_BFVStageClient, str]:
        bfv = self.state.bfv_clients.get(modulus)
        context_id = self.state.context_ids.get(modulus)
        if bfv is not None and context_id is not None:
            return bfv, context_id
        bfv = _BFVStageClient(plain_modulus=modulus, pydeps_path=self.owner.tenseal_path)
        context_id = new_id(f"ctx{modulus}")
        response = self.owner.http.put(
            f"/v1/runtime/sessions/{self.session_id}/contexts/{context_id}",
            headers={**self.owner.headers, "Content-Type": "application/octet-stream"},
            content=bfv.public_context,
        )
        _raise(response)
        self.state.bfv_clients[modulus] = bfv
        self.state.context_ids[modulus] = context_id
        self.owner.audit.public_context_bytes += len(bfv.public_context)
        return bfv, context_id

    def _create(self, stage: StageMetadata, count: int) -> list[BlindedStageCorrelation]:
        if self.state.mode == "local-test":
            response = self.owner.http.post(
                f"/v1/runtime/sessions/{self.session_id}/correlations/proprietary/local-test",
                headers=self.owner.headers,
                json={
                    "count": count,
                    "stage_id": stage.id,
                    "owner_id": self.state.blinded_owner_id,
                },
            )
            _raise(response)
            value = msgpack.unpackb(response.content, raw=False, strict_map_key=False)
            rows = [blinded_correlation_from_wire(item) for item in value["items"]]
            self.owner.audit.correlation_count += len(rows)
            return rows
        if self.state.mode != "bfv":
            raise ValueError(f"unsupported proprietary correlation mode {self.state.mode!r}")
        bfv, context_id = self._context(int(stage.modulus))
        masks = [
            self.state.rng.integers(0, int(stage.modulus), size=stage.in_features, dtype=np.uint32)
            for _ in range(count)
        ]
        encrypted = [bfv.encrypt(mask) for mask in masks]
        upload = encode_length_prefixed(encrypted)
        self.owner.audit.encrypted_correlation_upload_bytes += len(upload)
        response = self.owner.http.post(
            f"/v1/runtime/sessions/{self.session_id}/correlations/proprietary/bfv/batch",
            headers={
                **self.owner.headers,
                "Content-Type": "application/octet-stream",
                "X-HE-Stage-ID": stage.id,
                "X-HE-Context-ID": context_id,
                "X-HE-Owner-ID": self.state.blinded_owner_id,
            },
            content=upload,
        )
        _raise(response)
        self.owner.audit.encrypted_correlation_download_bytes += len(response.content)
        payloads = list(iter_length_prefixed(response.content))
        if len(payloads) != count:
            raise ModelError("blinded BFV correlation batch returned the wrong item count")
        rows: list[BlindedStageCorrelation] = []
        for mask, payload in zip(masks, payloads, strict=True):
            envelope = msgpack.unpackb(payload, raw=False, strict_map_key=False)
            correlation_id = str(envelope.get("correlation_id", ""))
            if not correlation_id:
                raise ModelError("blinded BFV correlation is missing its id")
            transformed = bfv.decrypt(payload, stage_id=stage.id)
            rows.append(
                BlindedStageCorrelation(
                    id=correlation_id,
                    stage_id=stage.id,
                    owner_id=self.state.blinded_owner_id,
                    mask=mask,
                    blinded_transformed_mask=transformed,
                    modulus=int(stage.modulus),
                    ring="prime",
                )
            )
        self.owner.audit.correlation_count += len(rows)
        return rows


class _BlindedRemoteLinear:
    """Fast output-blinded OLE-style stage client for proprietary mode."""

    def __init__(
        self,
        *,
        stages: dict[str, StageMetadata],
        correlations: _BlindedCorrelationProvider,
        session_id: str,
        state: _TransformerCryptoState,
        exchange: Callable[[str, list[bytes]], list[bytes]],
    ) -> None:
        self.stages = stages
        self.correlations = correlations
        self.session_id = session_id
        self.state = state
        self.exchange = exchange
        self.stats = StageClientStats()

    def __call__(self, stage_id: str, activation: np.ndarray) -> np.ndarray:
        stage = self.stages.get(stage_id)
        if stage is None:
            raise ModelError(f"unknown stage {stage_id!r}")
        value = np.asarray(activation, dtype=np.float32)
        if value.shape[-1] != stage.in_features:
            raise ModelError(
                f"stage {stage_id} expects {stage.in_features} features, got {value.shape}"
            )
        quantized = quantize_activation_per_row(value, bits=stage.activation_bits)
        rows = self.correlations.take_many(stage, quantized.rows)
        modulus = int(stage.modulus)
        if any(
            item.stage_id != stage_id
            or item.owner_id != self.state.blinded_owner_id
            or item.modulus != modulus
            or (item.ring or "prime") != "prime"
            for item in rows
        ):
            raise ModelError("proprietary correlation arithmetic profile mismatch")
        masks = np.stack([np.asarray(item.mask).reshape(stage.in_features) for item in rows])
        blinded_transformed = np.stack(
            [np.asarray(item.blinded_transformed_mask).reshape(stage.out_features) for item in rows]
        )
        masked = (quantized.values.astype(np.int64) - masks.astype(np.int64)) % modulus
        request = BlindedStageRequest(
            model=self.state.bundle.model_id,
            stage_id=stage_id,
            owner_id=self.state.blinded_owner_id,
            correlation_ids=tuple(item.id for item in rows),
            masked_input=masked.astype(np.uint32),
            activation_scales=quantized.scales,
            modulus=modulus,
            wire_bits=stage.wire_bits,
            ring="prime",
        )
        packed = request.pack()
        response_payloads = self.exchange(stage_id, [packed])
        if len(response_payloads) != 1:
            raise ModelError("blinded stage exchange returned the wrong result count")
        response = BlindedStageResponse.unpack(response_payloads[0])
        if (
            response.stage_id != stage_id
            or response.correlation_ids != request.correlation_ids
            or response.modulus != modulus
        ):
            raise ModelError("blinded stage response mismatch")
        combined = (
            response.masked_output.astype(np.uint64) + blinded_transformed.astype(np.uint64)
        ) % modulus
        integers = combined.astype(np.int64)
        integers = np.where(integers > modulus // 2, integers - modulus, integers)
        output = dequantize_matmul(
            integers,
            quantized.scales,
            stage.weight_scales,
            output_shape=quantized.original_shape[:-1] + (stage.out_features,),
        )
        if stage.bias is not None:
            output = output + stage.bias
        self.stats.calls += 1
        self.stats.rows += quantized.rows
        self.stats.correlations += quantized.rows
        self.stats.upload_bytes += len(packed)
        self.stats.download_bytes += len(response_payloads[0])
        self.stats.server_ns += response.server_ns
        return output


class _DirectFHERemoteLinear:
    """Direct encrypted stage client used by proprietary mode."""

    def __init__(
        self,
        *,
        stages: dict[str, StageMetadata],
        owner: "RuntimeClient",
        session_id: str,
        state: _TransformerCryptoState,
        exchange: Callable[[str, list[bytes]], list[bytes]],
    ) -> None:
        self.stages = stages
        self.owner = owner
        self.session_id = session_id
        self.state = state
        self.exchange = exchange
        self.stats = StageClientStats()

    def _context(self, modulus: int) -> tuple[_BFVStageClient, str]:
        bfv = self.state.bfv_clients.get(modulus)
        context_id = self.state.context_ids.get(modulus)
        if bfv is not None and context_id is not None:
            return bfv, context_id
        bfv = _BFVStageClient(plain_modulus=modulus, pydeps_path=self.owner.tenseal_path)
        context_id = new_id(f"ctx{modulus}")
        response = self.owner.http.put(
            f"/v1/runtime/sessions/{self.session_id}/contexts/{context_id}",
            headers={**self.owner.headers, "Content-Type": "application/octet-stream"},
            content=bfv.public_context,
        )
        _raise(response)
        self.state.bfv_clients[modulus] = bfv
        self.state.context_ids[modulus] = context_id
        self.owner.audit.public_context_bytes += len(bfv.public_context)
        return bfv, context_id

    def __call__(self, stage_id: str, activation: np.ndarray) -> np.ndarray:
        stage = self.stages.get(stage_id)
        if stage is None:
            raise ModelError(f"unknown stage {stage_id!r}")
        value = np.asarray(activation, dtype=np.float32)
        if value.shape[-1] != stage.in_features:
            raise ModelError(
                f"stage {stage_id} expects {stage.in_features} features, got {value.shape}"
            )
        quantized = quantize_activation_per_row(value, bits=stage.activation_bits)
        bfv, context_id = self._context(stage.modulus)
        encrypted_rows = tuple(bfv.encrypt(row) for row in quantized.values)
        request = DirectFHEStageRequest(
            model=self.state.bundle.model_id,
            stage_id=stage_id,
            context_id=context_id,
            input_shape=quantized.original_shape,
            activation_scales=quantized.scales,
            encrypted_rows=encrypted_rows,
        )
        packed = request.pack()
        self.owner.audit.direct_fhe_upload_bytes += len(packed)
        result_payloads = self.exchange(stage_id, [packed])
        if len(result_payloads) != 1:
            raise ModelError("direct-FHE exchange returned the wrong result count")
        self.owner.audit.direct_fhe_download_bytes += len(result_payloads[0])
        response = DirectFHEStageResponse.unpack(result_payloads[0])
        if response.stage_id != stage_id or len(response.output_rows) != quantized.rows:
            raise ModelError("direct-FHE stage response mismatch")
        integer_rows = np.stack(
            [bfv.decrypt(item, stage_id=stage_id).astype(np.int64) for item in response.output_rows]
        )
        # BFV returns positive residues. Convert back to the signed dot-product range.
        integer_rows = np.where(
            integer_rows > stage.modulus // 2,
            integer_rows - stage.modulus,
            integer_rows,
        )
        output = dequantize_matmul(
            integer_rows,
            quantized.scales,
            stage.weight_scales,
            output_shape=quantized.original_shape[:-1] + (stage.out_features,),
        )
        if stage.bias is not None:
            output = output + stage.bias
        self.stats.calls += 1
        self.stats.rows += quantized.rows
        self.stats.upload_bytes += len(packed)
        self.stats.download_bytes += len(result_payloads[0])
        self.stats.server_ns += response.server_ns
        self.owner.audit.direct_fhe_steps += 1
        return output


class _CorrelationSource:
    def __init__(
        self,
        *,
        client: "RuntimeClient",
        session_id: str,
        state: _ModelCryptoState,
        prefetch: int,
    ) -> None:
        self.owner = client
        self.session_id = session_id
        self.state = state
        self.model = state.model
        self.mode = state.mode
        self.prefetch = max(1, prefetch)
        if self.mode == "bfv" and self.state.bfv is None:
            self.state.bfv = BFVCorrelationClient(
                dimension=self.model.tokenizer.vocab_size,
                plain_modulus=self.model.modulus,
                pydeps_path=client.tenseal_path,
            )
            self.state.context_id = new_id("ctx")
            response = client.http.put(
                f"/v1/runtime/sessions/{session_id}/contexts/{self.state.context_id}",
                headers={**client.headers, "Content-Type": "application/octet-stream"},
                content=self.state.bfv.public_context,
            )
            _raise(response)
            client.audit.public_context_bytes += len(self.state.bfv.public_context)
        elif self.mode not in {"bfv", "local-test"}:
            raise ValueError(f"unsupported correlation mode {self.mode}")

    def take(self) -> MaskCorrelation:
        with self.state.lock:
            if len(self.state.pool) == 0:
                self._replenish_locked(self.prefetch)
            return self.state.pool.take()

    def replenish(self, count: int) -> int:
        if count <= 0:
            return len(self.state.pool)
        with self.state.lock:
            self._replenish_locked(count)
            return len(self.state.pool)

    def _replenish_locked(self, count: int) -> None:
        if self.mode == "local-test":
            response = self.owner.http.post(
                f"/v1/runtime/sessions/{self.session_id}/correlations/local-test",
                headers=self.owner.headers,
                json={"count": count},
            )
            _raise(response)
            value = msgpack.unpackb(response.content, raw=False)
            for item in value["items"]:
                shape = tuple(item["shape"])
                mask = np.frombuffer(item["mask"], dtype="<i8").copy().reshape(shape)
                transformed = np.frombuffer(item["transformed"], dtype="<i8").copy()
                self.state.pool.put(MaskCorrelation(str(item["id"]), mask, transformed))
            self.owner.audit.correlation_count += count
            return

        assert self.state.bfv is not None
        for _ in range(count):
            mask = self.state.rng.integers(
                0,
                self.model.modulus,
                size=self.model.tokenizer.vocab_size,
                dtype=np.int64,
            )
            encrypted = self.state.bfv.encrypt_mask(mask)
            self.owner.audit.encrypted_correlation_upload_bytes += len(encrypted)
            response = self.owner.http.post(
                f"/v1/runtime/sessions/{self.session_id}/correlations/bfv",
                headers={**self.owner.headers, "Content-Type": "application/octet-stream"},
                content=encrypted,
            )
            _raise(response)
            self.owner.audit.encrypted_correlation_download_bytes += len(response.content)
            transformed = self.state.bfv.decrypt_transformed(response.content)
            self.state.pool.put(MaskCorrelation(new_id("corr"), mask, transformed))
            self.owner.audit.correlation_count += 1


class RuntimeClient:
    prepared_concurrency_contract = "prepared_queue_inflight_before_admission_v1"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        default_model: str | None = None,
        session_transport: str = "http",
        correlation_mode: str = "bfv",
        preparation_base_url: str | None = None,
        preparation_api_key: str | None = None,
        correlation_prefetch: int = 4,
        prepared_inventory_rows: int | None = None,
        preparation_decode_epoch_tokens: int | None = None,
        background_inventory_refill: bool | None = None,
        token_cache_size: int = 512,
        prefill_cache_bytes: int = 0,
        prefill_cache_mode: str = "exact",
        prefill_cache_bound_tokens: int | None = None,
        decode_cache: DecodeCache | None = None,
        bundle_cache_mode: str = "read-write",
        bundle_cache_dir: str | Path | None = None,
        bundle_compression: str | None = None,
        tenseal_path: str | None = None,
        timeout: float = 300.0,
        http_client: httpx.Client | None = None,
        preparation_http_client: httpx.Client | None = None,
        experiment: Experiment | ExperimentProfile | None = None,
        local_engine: MaskedTransformerEngine | None = None,
        role_connections: Mapping[str, tuple[str, str]] | None = None,
        boundary_urls: tuple[str, str] | None = None,
        boundary_api_keys: tuple[str, str] | None = None,
    ) -> None:
        from pllm.configuration import Experiment, ExperimentProfile

        if experiment is None:
            self.experiment = None
        elif isinstance(experiment, ExperimentProfile):
            self.experiment = experiment
        elif isinstance(experiment, Experiment):
            self.experiment = experiment.resolve()
        else:
            raise TypeError("experiment must be an Experiment or ExperimentProfile")
        self._experiment_budget = experiment.budget if isinstance(experiment, Experiment) else None
        self._local_engine = local_engine
        self._native_worker_limit = None
        self._private_boundary = bool(getattr(self.experiment, "private_boundary", False))
        self._boundary_connections = None
        self._boundary_timeout = timeout
        if self._private_boundary:
            from .private_boundary_transport import _origin

            if (self._experiment_budget is None or local_engine is not None
                    or type(boundary_urls) is not tuple or len(boundary_urls) != 2
                    or type(boundary_api_keys) is not tuple or len(boundary_api_keys) != 2
                    or any(type(value) is not str or not value for value in boundary_urls)
                    or any(type(value) is not str or len(value) < 16 for value in boundary_api_keys)
                    or not preparation_base_url or not preparation_api_key
                    or len({api_key, preparation_api_key, *boundary_api_keys}) != 4):
                raise ValueError("private boundary requires a bounded Experiment and four distinct role credentials")
            origins = [_origin(value) for value in (*boundary_urls, base_url, preparation_base_url)]
            if len(set(origins)) != 4:
                raise ValueError("private boundary requires four distinct provider origins")
            self._boundary_connections = tuple(zip(boundary_urls, boundary_api_keys, strict=True))
        elif boundary_urls is not None or boundary_api_keys is not None:
            raise ValueError("boundary connections require an explicit private-boundary Experiment")
        offset_execution = (
            self.experiment is not None and self.experiment.client_runtime == "compiled_offset_v1"
        )
        if offset_execution:
            if (
                role_connections is None
                or set(role_connections) != {"worker_a", "worker_b"}
                or local_engine is not None
                or preparation_base_url is not None
                or preparation_api_key is not None
                or http_client is not None
                or preparation_http_client is not None
                or any(
                    not isinstance(connection, tuple)
                    or len(connection) != 2
                    or not all(type(item) is str and item for item in connection)
                    for connection in role_connections.values()
                )
                or (base_url, api_key) != role_connections["worker_a"]
                or role_connections["worker_a"][1] == role_connections["worker_b"][1]
            ):
                raise ValueError("offset Experiment requires two distinct worker connections")
            urls = tuple(httpx.URL(role_connections[role][0]) for role in ("worker_a", "worker_b"))
            origins = tuple(
                (url.scheme, url.host, url.port or (443 if url.scheme == "https" else 80))
                for url in urls
            )
            if origins[0] == origins[1] or any(
                url.scheme != "https" and url.host not in {"127.0.0.1", "localhost", "::1"}
                for url in urls
            ):
                raise ValueError("offset workers must have distinct HTTPS or loopback origins")
        elif role_connections is not None:
            raise ValueError("worker connections require an offset Experiment")
        if local_engine is not None and (
            self.experiment is None
            or self.experiment.client_runtime != "compiled_client_local_v1"
            or http_client is not None
            or preparation_http_client is not None
            or preparation_base_url is not None
            or preparation_api_key is not None
            or bool(base_url)
            or bool(api_key)
        ):
            raise ValueError("client-owned engine requires an endpoint-free client-only Experiment")
        if (
            local_engine is None
            and self.experiment is not None
            and (self.experiment.client_runtime == "compiled_client_local_v1")
        ):
            raise ValueError("client-only Experiment requires a client-owned model engine")
        if (
            self.experiment is not None
            and default_model is not None
            and default_model != self.experiment.model
        ):
            raise ValueError("default_model conflicts with Experiment model")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.default_model = self.experiment.model if self.experiment is not None else default_model
        self.session_transport = session_transport
        self.correlation_mode = correlation_mode
        self.correlation_prefetch = correlation_prefetch
        if self.experiment is not None and "inventory" in json.loads(
            self.experiment.canonical_composition
        ).get("components", {}):
            expected_rows = self.experiment.prepared_inventory_rows
            if prepared_inventory_rows is not None and prepared_inventory_rows != expected_rows:
                raise ValueError("inventory rows conflict with immutable Experiment")
            prepared_inventory_rows = expected_rows
        if prepared_inventory_rows is None:
            prepared_inventory_rows = 64
        if prepared_inventory_rows < 1:
            raise ValueError("prepared_inventory_rows must be positive")
        self.prepared_inventory_rows = prepared_inventory_rows
        refill = getattr(self.experiment, "inventory_refill", None)
        if refill is not None:
            expected_refill = refill == "idle"
            if background_inventory_refill is not None and background_inventory_refill != expected_refill:
                raise ValueError("inventory refill override differs from Experiment")
            background_inventory_refill = expected_refill
        if background_inventory_refill is None:
            background_inventory_refill = True
        if type(background_inventory_refill) is not bool:
            raise ValueError("background_inventory_refill must be boolean")
        self.background_inventory_refill = background_inventory_refill
        self._closing = False
        self.token_cache_size = max(0, int(token_cache_size))
        if self.experiment is not None and self.experiment.prefix_cache_bytes:
            bound = self.experiment.prefix_cache_bound_tokens
            if (
                (prefill_cache_bytes and prefill_cache_bytes != self.experiment.prefix_cache_bytes)
                or prefill_cache_mode not in {"exact", "prefix"}
                or (prefill_cache_bound_tokens is not None and prefill_cache_bound_tokens != bound)
            ):
                raise ValueError("prefill cache settings conflict with immutable Experiment")
            prefill_cache_bytes = self.experiment.prefix_cache_bytes
            prefill_cache_mode = "prefix"
            prefill_cache_bound_tokens = bound
        elif self.experiment is not None and prefill_cache_mode == "prefix":
            raise ValueError(
                "Experiment prefix reuse requires the client-prefix-reuse cache component"
            )
        if type(prefill_cache_bytes) is not int or not 0 <= prefill_cache_bytes <= 256 << 20:
            raise ValueError("prefill_cache_bytes must be in [0, 256 MiB]")
        if prefill_cache_mode not in {"exact", "prefix"}:
            raise ValueError("prefill_cache_mode must be exact or prefix")
        if prefill_cache_mode == "prefix":
            if (
                not prefill_cache_bytes
                or type(prefill_cache_bound_tokens) is not int
                or not 2 <= prefill_cache_bound_tokens <= 4096
            ):
                raise ValueError(
                    "prefix reuse requires cache bytes and a fixed input bound in [2, 4096]"
                )
        elif prefill_cache_bound_tokens is not None:
            raise ValueError("prefill_cache_bound_tokens requires prefix reuse")
        if (
            self._experiment_budget is not None
            and prefill_cache_bound_tokens is not None
            and prefill_cache_bound_tokens > self._experiment_budget.max_input_tokens
        ):
            raise ValueError("prefix-cache bound exceeds immutable Experiment workload")
        self.prefill_cache_bytes = prefill_cache_bytes
        self.prefill_cache_mode = prefill_cache_mode
        self.prefill_cache_bound_tokens = prefill_cache_bound_tokens
        if self._private_boundary and (prefill_cache_bytes or decode_cache is not None):
            raise ValueError("private boundary does not admit retained prefix or decode caches")
        cache_params = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("cache", {}).get("params", {})
            if self.experiment is not None else {})
        if bool(cache_params.get("decode")) != (decode_cache is not None):
            raise ValueError("decode reuse requires its immutable component and a caller-owned DecodeCache")
        if decode_cache is not None:
            from pllm.state.decode import DecodeCache
            if type(decode_cache) is not DecodeCache:
                raise TypeError("decode_cache must be a DecodeCache")
            if decode_cache._limits["max_transient_bytes"] > cache_params.get("decode_max_bytes", 128 << 20):
                raise ValueError("decode cache exceeds the composition's additional client memory bound")
        self.decode_cache = None
        self._decode_cache_lock = threading.Lock()
        self._decode_publications = {}
        self._decode_pending_responses = set()
        self._decode_terminal_responses = set()
        if bundle_cache_mode not in _BUNDLE_CACHE_MODES:
            raise ValueError("bundle_cache_mode must be read-write, read-only, refresh, or off")
        if self.experiment is not None and "delivery" in json.loads(
            self.experiment.canonical_composition
        ).get("components", {}):
            expected_encoding = self.experiment.bundle_compression
            if bundle_compression is not None and bundle_compression != expected_encoding:
                raise ValueError("bundle encoding conflicts with immutable Experiment")
            bundle_compression = expected_encoding
        if bundle_compression is None:
            bundle_compression = "none"
        if bundle_compression not in {"none", "zlib", "artifacts", "artifacts-zlib"}:
            raise ValueError("bundle_compression must be none, zlib, artifacts, or artifacts-zlib")
        self.bundle_cache_mode = bundle_cache_mode
        self.bundle_compression = bundle_compression
        self.bundle_batch_objects = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("delivery", {}).get("params", {}).get("batch_objects", 1)
            if self.experiment is not None else 1)
        self.bundle_weight_storage = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("delivery", {}).get("params", {}).get("storage", "memory")
            if self.experiment is not None else "memory")
        self.provider_artifact_cache_bytes = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("delivery", {}).get("params", {}).get("provider_cache_bytes", 0)
            if self.experiment is not None else 0)
        self.preparation_stage_window = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("inventory", {}).get("params", {}).get("stage_window", 1)
            if self.experiment is not None else 1)
        self.preparation_stage_window_bytes = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("inventory", {}).get("params", {}).get("stage_window_bytes", 16 << 20)
            if self.experiment is not None else 16 << 20)
        self.preparation_allocation = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("inventory", {}).get("params", {}).get("allocation", "uniform")
            if self.experiment is not None else "uniform")
        components = (json.loads(self.experiment.canonical_composition).get("components", {})
                      if self.experiment is not None else {})
        epoch_tokens = components.get("inventory", {}).get("params", {}).get("decode_epoch_tokens")
        if preparation_decode_epoch_tokens is not None and (
                type(preparation_decode_epoch_tokens) is not int or not 1 <= preparation_decode_epoch_tokens <= 64):
            raise ValueError("preparation_decode_epoch_tokens must be in [1, 64]")
        if preparation_decode_epoch_tokens is not None and preparation_decode_epoch_tokens != epoch_tokens:
            raise ValueError("decode epoch override differs from immutable Experiment")
        self.preparation_decode_epoch_tokens = epoch_tokens
        epoch_schedule = components.get("inventory", {}).get("params", {}).get("decode_epoch_schedule")
        self.preparation_decode_epoch_schedule = None
        if epoch_schedule is not None:
            from pllm.preparation import validate_decode_epoch_schedule
            self.preparation_decode_epoch_schedule = validate_decode_epoch_schedule(epoch_schedule)
            if epoch_tokens is not None:
                raise ValueError("fixed and scheduled decode epochs are mutually exclusive")
        if epoch_tokens is not None or epoch_schedule is not None:
            if epoch_tokens is not None and (type(epoch_tokens) is not int or not 1 <= epoch_tokens <= 64):
                raise ValueError("preparation_decode_epoch_tokens must be in [1, 64]")
            if (self.preparation_allocation != "demand" or refill != "on-demand"
                    or self.prefill_cache_mode != "prefix" or offset_execution or local_engine is not None
                    or self.experiment.verification_component not in {None, "none"}
                    or components.get("quantization", {}).get("params", {}).get("causal_reduction") != "prefix_f32"
                    or {"verification", "state", "nonlinear", "scheduler", "public_prefix"} & components.keys()):
                raise ValueError("decode epochs require public demand/on-demand full-KV prefix execution")
            if background_inventory_refill:
                raise ValueError("decode epochs forbid background inventory refill")
        self.prefill_chunk_rows = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("linear", {}).get("params", {}).get("prefill_chunk_rows", 0)
            if self.experiment is not None else 0)
        self.prepared_request_encoding = (json.loads(self.experiment.canonical_composition)
            .get("components", {}).get("linear", {}).get("params", {}).get("request_encoding", "raw")
            if self.experiment is not None else "raw")
        if self.prefill_chunk_rows and self.session_transport == "http":
            raise ValueError("duplex prefill requires a WebSocket session transport")
        self._bundle_cache_explicit = bundle_cache_dir is not None
        self.bundle_cache_dir = (
            Path(bundle_cache_dir).expanduser()
            if bundle_cache_dir
            else (_default_bundle_cache_dir())
        )
        self._bundle_endpoint = (
            "" if local_engine is not None else _normalized_inference_endpoint(self.base_url)
        )
        self.tenseal_path = tenseal_path
        inference_url = httpx.URL(self.base_url or "http://127.0.0.1")
        if (
            http_client is None
            and inference_url.scheme != "https"
            and inference_url.host
            not in {
                "127.0.0.1",
                "localhost",
                "::1",
            }
        ):
            raise ValueError("base_url must use HTTPS outside loopback")
        # Validate both origins/credentials before creating either owned client.
        if preparation_http_client is not None or preparation_base_url is not None:
            if not preparation_api_key:
                raise ValueError("preparation_api_key is required for preparation service")
            if preparation_api_key == api_key:
                raise ValueError("inference and preparation credentials must be distinct")
            provider_urls = (
                http_client.base_url if http_client is not None else httpx.URL(self.base_url),
                preparation_http_client.base_url if preparation_http_client is not None
                else httpx.URL(preparation_base_url.rstrip("/")),
            )
            origins = [(url.scheme, url.host, url.port or (443 if url.scheme == "https" else 80))
                       for url in provider_urls]
            if origins[0] == origins[1]:
                raise ValueError("preparation and inference require distinct origins")
            for name, url in zip(("base_url", "preparation_base_url"), provider_urls, strict=True):
                if url.scheme != "https" and url.host not in {"127.0.0.1", "localhost", "::1"}:
                    raise ValueError(f"{name} must use HTTPS outside loopback")
        response_cache_limit = max(1, min(int(os.getenv("PLLM_RESPONSE_CACHE_SIZE", "128")), 1024))
        self._owns_http = http_client is None and local_engine is None
        self.http = (
            _NoProviderHTTP()
            if local_engine is not None
            else (http_client or httpx.Client(base_url=self.base_url, timeout=timeout))
        )
        self.headers = {"Authorization": f"Bearer {api_key}"}
        self._offset_workers: dict[str, tuple[httpx.Client, str]] = {}
        if offset_execution:
            self._offset_workers = {
                "worker_a": (self.http, api_key),
                "worker_b": (
                    httpx.Client(base_url=role_connections["worker_b"][0], timeout=timeout),
                    role_connections["worker_b"][1],
                ),
            }
        self._owns_preparation_http = (
            preparation_http_client is None and preparation_base_url is not None
        )
        self.preparation_http = preparation_http_client
        if self.preparation_http is None and preparation_base_url is not None:
            try:
                self.preparation_http = httpx.Client(
                    base_url=preparation_base_url.rstrip("/"), timeout=timeout
                )
            except BaseException as error:
                _cleanup_calls([self.http.close] if self._owns_http else [], primary=error)
                raise
        self.preparation_headers = {"Authorization": f"Bearer {preparation_api_key}"}
        self._provider_executor = ThreadPoolExecutor(
            max_workers=2, thread_name_prefix="pllm-provider"
        )
        self.cache: dict[str, Response] = {}
        self.histories: dict[str, str] = {}
        self.message_histories: dict[str, list[dict[str, Any]]] = {}
        self._response_cache_limit = response_cache_limit
        self._response_cache_order: deque[str] = deque()
        self._response_cache_lock = threading.Lock()
        self._decode_epoch_responses: dict[str, tuple[threading.Event, str, str]] = {}
        self._pending_response_store: dict[str, bool] = {}
        self._ephemeral_response_ids: set[str] = set()
        self._ephemeral_response_order: deque[str] = deque()
        self.audit = PrivacyAudit()
        if self._private_boundary or self._offset_workers is not None:
            # Establish instrumented zero counters before the startup snapshot.
            # Boundary sessions accumulate into these same owners on retirement;
            # absence would mean unknown coverage, not zero startup traffic.
            audit_roles = ("boundary_a", "boundary_b") if self._private_boundary else ("worker_a", "worker_b")
            self.audit.role_link_bodies = {
                role: {f"{phase}_{direction}_bytes": 0
                       for phase in ("setup", "online", "teardown")
                       for direction in ("upload", "download")}
                for role in audit_roles
            }
        self._crypto_states: dict[str, _ModelCryptoState] = {}
        self._crypto_state_lock = threading.Lock()
        self._transformer_states: dict[str, _TransformerCryptoState] = {}
        self._transformer_state_lock = threading.RLock()
        self._tokenizer_owner: ContextVar[_ScopedTokenizer | None] = ContextVar(
            "pllm_request_tokenizer", default=None
        )
        self._activity_lock = threading.Lock()
        self._active_offset_transports: dict[str, Any] = {}
        self._active_boundary_transports: dict[str, Any] = {}
        self._online_active = 0
        self._preparation_active = 0
        self._transformer_conversations: dict[str, _TransformerConversationState] = {}
        self._transformer_conversation_lock = threading.Lock()
        self._model_manifests: dict[str, dict[str, Any]] = {}
        from .prepared_queue import PreparedExecutionQueue

        cache_options = components.get("cache", {}).get("params", {})
        self._prepared_queue = (PreparedExecutionQueue(
            max_requests=cache_options.get("inflight_max_requests", 8))
            if self.experiment is not None and self.experiment.privacy_mode == "public"
            and not (local_engine is not None or offset_execution) else None)
        self._prepared_attempt_lock = threading.RLock()
        self._prepared_attempts: set[Any] = set()
        self._inflight_prefix_owner = None
        if cache_options.get("inflight"):
            if self._prepared_queue is None:
                raise ValueError("in-flight prefixes require prepared client ownership")
            from .inflight_prefix import InflightPrefixOwner

            self._inflight_prefix_owner = InflightPrefixOwner(self,
                max_requests=cache_options.get("inflight_max_requests", 8),
                max_bytes=cache_options.get("inflight_max_bytes", 64 << 20))
            self.audit._inflight_owner = self._inflight_prefix_owner
        if decode_cache is not None:
            try:
                decode_cache.claim(self)
            except BaseException:
                self.close()
                raise
            self.decode_cache = decode_cache

    def _open_private_session(
        self,
        model_id: str,
        *,
        max_output_tokens: int,
    ) -> tuple[dict[str, Any], MaskedBigramClientModel, _CorrelationSource]:
        # Context creation/registration is serialized per client. The context and
        # one-time-correlation inventory are reused across Responses, while each
        # Response retains an isolated authenticated online session.
        with self._crypto_state_lock:
            existing = self._crypto_states.get(model_id)
            session_body: dict[str, Any] = {
                "model": model_id,
                "max_output_tokens": max_output_tokens,
            }
            if existing is not None and existing.context_id is not None:
                session_body["context_id"] = existing.context_id
            session_response = self.http.post(
                "/v1/runtime/sessions", headers=self.headers, json=session_body
            )
            _raise(session_response)
            session_value = session_response.json()
            runtime = session_value["manifest"]["runtime"]
            model = MaskedBigramClientModel(
                model_id,
                AlphabetTokenizer(str(runtime["alphabet"])),
                int(runtime["modulus"]),
            )
            state = existing
            if state is None:
                state = _ModelCryptoState(
                    model=model,
                    mode=self.correlation_mode,
                    pool=CorrelationPool(),
                    rng=FieldRandom(),
                )
                self._crypto_states[model_id] = state
            elif (
                state.model.tokenizer.vocab_size != model.tokenizer.vocab_size
                or state.model.modulus != model.modulus
                or state.mode != self.correlation_mode
            ):
                raise ModelError("server model manifest changed during client lifetime")
            source = _CorrelationSource(
                client=self,
                session_id=str(session_value["id"]),
                state=state,
                prefetch=self.correlation_prefetch,
            )
            return session_value, model, source

    def _model_manifest(self, model_id: str, *, refresh: bool = False) -> dict[str, Any]:
        if self._local_engine is not None:
            state = self._client_owned_state(model_id)
            return {
                "id": model_id,
                "metadata": state.bundle.manifest["metadata"],
                "context_length": state.bundle.manifest["context_length"],
                "runtime": state.bundle.manifest["metadata"],
            }
        cached = None if refresh else self._model_manifests.get(model_id)
        if cached is not None:
            return cached
        response = self.http.get(f"/v1/runtime/models/{model_id}", headers=self.headers)
        _raise(response)
        value = response.json()
        self._model_manifests[model_id] = value
        return value

    def _client_bundle_descriptor(self, model_id: str) -> dict[str, Any]:
        descriptor = self._model_manifest(model_id, refresh=True).get("client_bundle")
        if not isinstance(descriptor, dict) or set(descriptor) != {
            "schema",
            "sha256",
            "size",
            "etag",
        }:
            raise ProtocolError("provider model descriptor lacks client bundle fingerprint", 409)
        fingerprint = str(descriptor["sha256"])
        if len(fingerprint) != 64 or any(char not in "0123456789abcdef" for char in fingerprint):
            raise ProtocolError("provider client bundle fingerprint is invalid", 409)
        if descriptor["etag"] != f'"{fingerprint}"':
            raise ProtocolError("provider client bundle descriptor is invalid", 409)
        if type(descriptor["schema"]) is not int or type(descriptor["size"]) is not int:
            raise ProtocolError("provider client bundle descriptor is invalid", 409)
        schema, size = descriptor["schema"], descriptor["size"]
        if schema < 1 or size < 1 or size > _MAX_CLIENT_BUNDLE_BYTES:
            raise ProtocolError("provider client bundle descriptor is invalid", 409)
        return descriptor

    @staticmethod
    def _ensure_private_directory(path: Path) -> None:
        existed = path.exists()
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
        if not existed:
            path.chmod(0o700)

    def _bundle_cache_namespace(self, *, create: bool) -> bytes | None:
        key_path = self.bundle_cache_dir / ".identity-key"
        if not create:
            try:
                key = key_path.read_bytes()
            except FileNotFoundError:
                return None
            if len(key) != 32:
                raise OSError(f"invalid bundle cache identity key: {key_path}")
            return key

        self._ensure_private_directory(self.bundle_cache_dir)
        with FileLock(str(key_path) + ".lock"):
            try:
                key = key_path.read_bytes()
            except FileNotFoundError:
                key = secrets.token_bytes(32)
                descriptor = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                try:
                    with os.fdopen(descriptor, "wb") as stream:
                        stream.write(key)
                        stream.flush()
                        os.fsync(stream.fileno())
                except BaseException:
                    try:
                        key_path.unlink()
                    except OSError:
                        pass
                    raise
            if len(key) != 32:
                raise OSError(f"invalid bundle cache identity key: {key_path}")
            return key

    def _bundle_cache_path(
        self,
        model_id: str,
        fingerprint: str | None = None,
        *,
        create_namespace: bool = True,
    ) -> Path | None:
        del fingerprint
        namespace = self._bundle_cache_namespace(create=create_namespace)
        if namespace is None:
            return None
        identity = json.dumps(
            {
                "endpoint": self._bundle_endpoint,
                "model": model_id,
                "credential": self.api_key,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
        key = hmac.new(namespace, identity, hashlib.sha256).hexdigest()
        return self.bundle_cache_dir / key[:2] / f"{key}.msgpack"

    def _bind_native_worker_limit(self, limit: int) -> None:
        """Bind client-local native execution before importing any response bundle."""
        if type(limit) is not int or not 1 <= limit <= 32:
            raise ValueError("client native worker limit must be in [1,32]")
        if self._transformer_states or self._native_worker_limit not in (None, limit):
            raise ValueError("client native worker limit must precede model binding")
        if self._local_engine is not None and self._local_engine.kernel.threads > limit:
            raise ValueError("client-owned model loading exceeds native worker limit")
        self._native_worker_limit = limit

    def _bundle_threads(self, *, artifact=False) -> int:
        # Preserve historical unbounded raw imports when no resource policy is
        # selected. Artifact imports already use the selected kernel's threads.
        limit = self._native_worker_limit
        if not artifact and limit is None:
            return 0
        kernels = (json.loads(self.experiment.canonical_composition)
                   .get("components", {}).get("kernels", {}).get("params", {})
                   if self.experiment is not None else {})
        threads = kernels.get("threads", 0)
        return min(threads or limit, limit) if limit is not None else threads

    @staticmethod
    def _read_cached_bundle(
        path: Path,
        *,
        model_id: str,
        fingerprint: str,
        schema: int,
        size: int,
        threads: int = 0,
    ) -> tuple[ClientBundle | None, str]:
        if not path.is_file():
            return None, "miss"
        try:
            payload = path.read_bytes()
            if len(payload) != size or hashlib.sha256(payload).hexdigest() != fingerprint:
                try:
                    stale = ClientBundle.unpack(payload)
                except (TransformerClientError, ValueError, TypeError):
                    return None, "corrupt"
                if stale.model_id == model_id and stale.schema_version == schema:
                    return None, "miss"
                return None, "corrupt"
            bundle = ClientBundle.unpack(payload, threads=threads)
            if bundle.model_id != model_id or bundle.schema_version != schema:
                return None, "corrupt"
            return bundle, "hit"
        except (OSError, TransformerClientError, ValueError, TypeError):
            return None, "corrupt"

    def _download_client_bundle(
        self,
        model_id: str,
        *,
        fingerprint: str,
        schema: int,
        size: int,
    ) -> tuple[ClientBundle, bytes | bytearray]:
        headers = dict(self.headers)
        if self.bundle_compression == "zlib":
            headers["X-PLLM-Accept-Bundle-Encoding"] = BUNDLE_ENCODING

        def count_wire_bytes(count: int) -> None:
            self.audit.bundle_network_bytes += count

        with self.http.stream(
            "GET", f"/v1/runtime/models/{model_id}/client-bundle", headers=headers
        ) as response, owned_response(response):
            if not response.is_success:
                response.read()
            _raise(response)
            if response.headers.get("Content-Encoding", "identity") != "identity":
                raise _BundleIntegrityError(
                    "provider bundle transport encoding is unsupported", 409
                )
            encoding = response.headers.get("X-PLLM-Bundle-Encoding")
            if encoding is None:
                payload = bytearray()
                chunks = ((response.content[offset:offset + 65536]
                           for offset in range(0, len(response.content), 65536)) if response.is_stream_consumed else
                          response.iter_raw(chunk_size=65536))
                for chunk in chunks:
                    count_wire_bytes(len(chunk))
                    if len(payload) + len(chunk) > size:
                        raise _BundleIntegrityError("provider client bundle fingerprint mismatch (declared size exceeded)", 409)
                    payload.extend(chunk)
            elif self.bundle_compression == "zlib" and encoding == BUNDLE_ENCODING:
                try:
                    payload = decode_bundle_frames(
                        (
                            (response.content,)
                            if response.is_stream_consumed
                            else response.iter_raw(chunk_size=64 * 1024)
                        ),
                        expected_size=size,
                        on_wire_bytes=count_wire_bytes,
                    )
                except BundleFrameError as exc:
                    raise _BundleIntegrityError(
                        "provider client bundle framing is invalid", 409
                    ) from exc
            else:
                raise _BundleIntegrityError("provider client bundle encoding is unsupported", 409)
        if (
            len(payload) != size
            or hashlib.sha256(payload).hexdigest() != fingerprint
            or response.headers.get("X-PLLM-Bundle-SHA256") != fingerprint
        ):
            raise _BundleIntegrityError("provider client bundle fingerprint mismatch", 409)
        try:
            bundle = ClientBundle.unpack(payload, threads=self._bundle_threads())
        except TransformerClientError as exc:
            raise _BundleIntegrityError("provider client bundle is invalid", 409) from exc
        if bundle.model_id != model_id or bundle.schema_version != schema:
            raise _BundleIntegrityError("provider client bundle descriptor mismatch", 409)
        return bundle, payload

    def _load_artifact_bundle(
        self, model_id: str, *, fingerprint: str, schema: int, size: int,
    ) -> ClientBundle:
        if schema != 2 or not 0 < size <= MAX_ARTIFACT_RAW_BYTES:
            raise _BundleIntegrityError("artifact raw admission exceeds schema/4 GiB cap", 409)
        cache = getattr(self, "bundle_artifact_cache", None)
        if cache is None:
            cache = configure_artifact_cache(self)
        stats = cache.stats
        initial_stats = stats.to_dict()
        headers = dict(self.headers)
        headers["X-PLLM-Accept-Bundle-Encoding"] = ARTIFACT_ENCODING
        model_path = quote(model_id, safe="")

        paged = getattr(self, "bundle_weight_storage", "memory") == "paged"
        from .bundle_storage import FilePayload
        from .bundle_artifacts import file_backed_object
        public_files = []

        def download(path: str, maximum: int, *, object_key: str | None = None, file_row=None):
            output = bytearray()
            compressed = object_key is not None and self.bundle_compression == "artifacts-zlib"
            request_headers = dict(headers)
            if compressed:
                request_headers["X-PLLM-Accept-Object-Encoding"] = BUNDLE_ENCODING
            with self.http.stream("GET", path, headers=request_headers, follow_redirects=False) as response, owned_response(response):
                if not response.is_success:
                    response.read()
                _raise(response)
                if response.headers.get("Content-Encoding", "identity") != "identity":
                    raise ArtifactError("artifact transport compression is unsupported")
                if response.headers.get("X-PLLM-Bundle-SHA256") != fingerprint:
                    raise ArtifactError("artifact original raw binding mismatch")
                if object_key is None:
                    if response.headers.get("X-PLLM-Bundle-Encoding") != ARTIFACT_ENCODING:
                        raise ArtifactError("provider does not support explicit artifacts encoding")
                    from .encoded_artifacts import HEADER
                    cache_bytes = getattr(self, "provider_artifact_cache_bytes", 0)
                    if cache_bytes and response.headers.get(HEADER) != str(cache_bytes):
                        raise ArtifactError("provider artifact cache acknowledgement differs from Experiment")
                    stats.manifest_requests += 1
                else:
                    if response.headers.get("X-PLLM-Object-SHA256") != object_key:
                        raise ArtifactError("artifact response object binding mismatch")
                    if compressed and (
                        response.headers.get("X-PLLM-Object-Encoding") != BUNDLE_ENCODING
                        or response.headers.get("X-PLLM-Object-Raw-Size") != str(maximum)
                    ):
                        raise ArtifactError("artifact compression acknowledgement/size mismatch")
                    if not compressed and response.headers.get("X-PLLM-Object-Encoding", "identity") != "identity":
                        raise ArtifactError("unexpected artifact object encoding")
                    stats.object_requests += 1
                chunks = ((response.content[offset:offset + 65536]
                           for offset in range(0, len(response.content), 65536)) if response.is_stream_consumed else
                          response.iter_raw(chunk_size=65536))

                def account(size):
                    self.audit.bundle_network_bytes += size
                    if object_key is None:
                        stats.manifest_download_bytes += size
                    else:
                        stats.object_download_bytes += size

                if file_row is not None:
                    from .bundle_compression import iter_bundle_frames

                    def raw_chunks():
                        for chunk in chunks:
                            account(len(chunk))
                            yield chunk
                    blocks = (iter_bundle_frames(chunks, expected_size=maximum, on_wire_bytes=account)
                              if compressed else raw_chunks())
                    result = FilePayload(blocks, size=maximum, digest=file_row["content_sha256"],
                                         native=file_row["metadata"]["dtype"] == "i1")
                    public_files.append(result)
                    return result
                if compressed:
                    return bytes(decode_bundle_frames(chunks, expected_size=maximum, on_wire_bytes=account))
                for chunk in chunks:
                    account(len(chunk))
                    if len(output) + len(chunk) > maximum:
                        raise ArtifactError("artifact response exceeds its byte bound")
                    output.extend(chunk)
            return bytes(output)

        try:
            document = download(f"/v1/runtime/models/{model_path}/client-bundle", MAX_MANIFEST_BYTES)
            started, cpu_started = time.perf_counter(), time.process_time()
            manifest = parse_manifest(document, fingerprint=fingerprint, size=size)
            stats.manifest_parse_seconds += time.perf_counter() - started
            stats.manifest_parse_cpu_seconds += time.process_time() - cpu_started

            def fetch_one(row):
                # No URLs from the manifest: exact authenticated inference origin.
                return download(
                    f"/v1/runtime/models/{model_path}/client-bundle-objects/{fingerprint}/{row['sha256']}",
                    row["size"], object_key=row["sha256"],
                    file_row=row if file_backed_object(row, paged=paged) else None,
                )

            def fetch_many(rows):
                keys = ".".join(row["sha256"] for row in rows)
                digest = hashlib.sha256(keys.encode("ascii")).hexdigest()
                stats.object_batch_requests += 1
                data = download(
                    f"/v1/runtime/models/{model_path}/client-bundle-object-batch/{fingerprint}?objects={keys}",
                    sum(row["size"] for row in rows), object_key=digest)
                result, position = {}, 0
                for row in rows:
                    result[row["sha256"]] = data[position:position + row["size"]]
                    position += row["size"]
                return result

            group_reader = None
            if self.bundle_batch_objects > 1:
                from .bundle_artifacts import batched_reader
                group_reader = batched_reader(manifest, cache, fetch_one, fetch_many,
                                               maximum=self.bundle_batch_objects, paged=paged)

            def read(row):
                before = stats.to_dict()
                payload = group_reader(row) if group_reader else cache.fetch(
                    row, lambda: fetch_one(row), file_backed=file_backed_object(row, paged=paged))
                self.audit.bundle_cache_corruptions += stats.corruptions - before["corruptions"]
                if isinstance(payload, FilePayload):
                    public_files.append(payload)
                return payload

            started, cpu_started = time.perf_counter(), time.process_time()
            value = reconstruct_document(manifest, read)
            if value.get("model") != model_id or value.get("v") != schema:
                raise ArtifactError("artifact reconstructed bundle descriptor mismatch")
            stats.reconstruction_seconds += time.perf_counter() - started
            stats.reconstruction_cpu_seconds += time.process_time() - cpu_started
            bundle = ClientBundle._from_document(value, storage="paged" if paged else "memory",
                                                  threads=self._bundle_threads(artifact=True))
            if bundle.model_id != model_id or bundle.schema_version != schema:
                raise ArtifactError("artifact reconstructed bundle descriptor mismatch")
            # Existing audit counters retain bundle-level semantics. Detailed
            # per-object/ref counts live in artifact_cache_stats, so duplicate
            # scale references cannot label a cold transfer as a warm bundle.
            if stats.object_requests == initial_stats["object_requests"]:
                self.audit.bundle_cache_hits += 1
            elif stats.corruptions == initial_stats["corruptions"]:
                self.audit.bundle_cache_misses += 1
            return bundle
        except (ArtifactError, TransformerClientError, ValueError, TypeError, KeyError) as exc:
            raise _BundleIntegrityError(f"provider client bundle artifacts invalid: {exc}", 409) from exc
        except OSError as exc:
            raise ProtocolError(f"configured public artifact cache is unavailable: {exc}") from exc
        finally:
            for payload in public_files:
                payload.close()

    @staticmethod
    def _write_cached_bundle(path: Path, payload: bytes | bytearray) -> None:
        temporary: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb", dir=path.parent, prefix=f".{path.name}.", delete=False
            ) as stream:
                temporary = Path(stream.name)
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            temporary.chmod(0o600)
            os.replace(temporary, path)
            try:
                directory = os.open(
                    path.parent,
                    os.O_RDONLY | getattr(os, "O_DIRECTORY", 0),
                )
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
            except OSError:
                # Directory fsync is unsupported on some otherwise safe filesystems.
                pass
        finally:
            if temporary is not None:
                try:
                    temporary.unlink()
                except FileNotFoundError:
                    pass

    def _load_client_bundle_descriptor(
        self,
        model_id: str,
        descriptor: dict[str, Any],
    ) -> ClientBundle:
        fingerprint = str(descriptor["sha256"])
        schema = int(descriptor["schema"])
        size = int(descriptor["size"])
        if self.bundle_compression in {"artifacts", "artifacts-zlib"}:
            return self._load_artifact_bundle(model_id, fingerprint=fingerprint, schema=schema, size=size)
        if self.bundle_cache_mode == "off":
            return self._download_client_bundle(
                model_id, fingerprint=fingerprint, schema=schema, size=size
            )[0]

        path: Path | None = None
        downloaded: tuple[ClientBundle, bytes | bytearray] | None = None
        try:
            path = self._bundle_cache_path(
                model_id,
                fingerprint,
                create_namespace=self.bundle_cache_mode != "read-only",
            )
        except OSError as exc:
            if self._bundle_cache_explicit:
                raise ProtocolError(f"configured bundle cache is unavailable: {exc}") from exc
            return self._download_client_bundle(
                model_id, fingerprint=fingerprint, schema=schema, size=size
            )[0]

        if self.bundle_cache_mode == "read-only":
            try:
                if path is None:
                    bundle, status = None, "miss"
                else:
                    bundle, status = self._read_cached_bundle(
                        path,
                        model_id=model_id,
                        fingerprint=fingerprint,
                        schema=schema,
                        size=size,
                        threads=self._bundle_threads(),
                    )
            except OSError:
                bundle, status = None, "miss"
            if status == "hit":
                self.audit.bundle_cache_hits += 1
                assert bundle is not None
                return bundle
            if status == "corrupt":
                self.audit.bundle_cache_corruptions += 1
            else:
                self.audit.bundle_cache_misses += 1
            return self._download_client_bundle(
                model_id, fingerprint=fingerprint, schema=schema, size=size
            )[0]

        assert path is not None
        try:
            self._ensure_private_directory(path.parent)
            with FileLock(str(path) + ".lock"):
                if self.bundle_cache_mode == "read-write":
                    bundle, status = self._read_cached_bundle(
                        path,
                        model_id=model_id,
                        fingerprint=fingerprint,
                        schema=schema,
                        size=size,
                        threads=self._bundle_threads(),
                    )
                    if status == "hit":
                        self.audit.bundle_cache_hits += 1
                        assert bundle is not None
                        return bundle
                    if status == "corrupt":
                        self.audit.bundle_cache_corruptions += 1
                    else:
                        self.audit.bundle_cache_misses += 1
                downloaded = self._download_client_bundle(
                    model_id, fingerprint=fingerprint, schema=schema, size=size
                )
                self._write_cached_bundle(path, downloaded[1])
                return downloaded[0]
        except OSError as exc:
            if self._bundle_cache_explicit:
                raise ProtocolError(f"configured bundle cache is unavailable: {exc}") from exc
            if downloaded is not None:
                return downloaded[0]
            return self._download_client_bundle(
                model_id, fingerprint=fingerprint, schema=schema, size=size
            )[0]

    def _load_client_bundle_record(
        self,
        model_id: str,
        descriptor: dict[str, Any] | None = None,
    ) -> tuple[ClientBundle, str]:
        descriptor = descriptor or self._client_bundle_descriptor(model_id)
        for attempt in range(2):
            try:
                bundle = self._load_client_bundle_descriptor(model_id, descriptor)
                return bundle, str(descriptor["sha256"])
            except _BundleIntegrityError:
                if attempt:
                    raise
                current = self._client_bundle_descriptor(model_id)
                if current == descriptor:
                    raise
                descriptor = current
        raise AssertionError("unreachable")

    def _load_client_bundle(self, model_id: str) -> ClientBundle:
        return self._load_client_bundle_record(model_id)[0]

    @staticmethod
    def _remote_stages(state: _TransformerCryptoState) -> list[StageMetadata]:
        boundary_stages = (
            {"token_lookup", "lm_head"}
            if "private_boundary" in state.bundle.privacy else set()
        )
        return [
            stage
            for stage in state.bundle.stages.values()
            if stage.client_weight is None
            and stage.id not in boundary_stages | {"embed_tokens"}
        ]

    def _transformer_state(self, model_id: str) -> _TransformerCryptoState:
        if self.experiment is not None and model_id != self.experiment.model:
            raise ValueError("request model conflicts with Experiment model")
        if self._local_engine is not None:
            return self._client_owned_state(model_id)
        with self._transformer_state_lock:
            descriptor = self._client_bundle_descriptor(model_id)
            expected_runtime = None
            expected_protocol = None
            selected_metal_rows = None
            if self.experiment is not None:
                from pllm.configuration import Pipeline

                expected_runtime = self.experiment.client_runtime
                expected_protocol = self.experiment.privacy_protocol
                metadata = descriptor.get("metadata") or {}
                if not metadata:
                    manifest = self._model_manifest(model_id)
                    runtime = manifest.get("runtime") or manifest.get("metadata") or {}
                    metadata = {
                        "client_runtime": runtime.get("client_runtime"),
                        "privacy_mode": runtime.get("privacy_mode"),
                        "privacy_protocol": runtime.get("privacy_protocol"),
                        "verification_component": runtime.get("verification_component", "none"),
                        "verification_target_failure_bits": runtime.get(
                            "verification_target_failure_bits", 0
                        ),
                        "kernel_backend": runtime.get("kernel_backend"),
                        "kernel_min_rows": runtime.get("kernel_min_rows"),
                    }
                composition = Pipeline.from_spec(json.loads(self.experiment.canonical_composition))
                kernels = composition.components.get("kernels")
                selected_metal_rows = (
                    kernels.params["min_rows"]
                    if kernels is not None and kernels.component == "pllm/apple-metal-int8/v1"
                    else None
                )
                if (
                    metadata.get("client_runtime") != expected_runtime
                    or metadata.get("privacy_mode") != self.experiment.privacy_mode
                    or (
                        expected_protocol is not None
                        and metadata.get("privacy_protocol") != expected_protocol
                    )
                    or metadata.get("verification_component", "none")
                    != (self.experiment.verification_component or "none")
                    or int(metadata.get("verification_target_failure_bits", 0))
                    != self.experiment.verification_target_failure_bits
                    or (
                        selected_metal_rows is not None
                        and (
                            metadata.get("kernel_backend") != "mlx-metal+cpu"
                            or metadata.get("kernel_min_rows") != selected_metal_rows
                        )
                    )
                ):
                    raise ProtocolError(
                        "Experiment runtime contract does not match inference metadata", 409
                    )
            bundle_fingerprint = str(descriptor["sha256"])
            state = self._transformer_states.get(model_id)
            if state is None or state.bundle_fingerprint != bundle_fingerprint:
                if state is not None and state.prefill_cache is not None:
                    state.prefill_cache.clear()
                bundle, bundle_fingerprint = self._load_client_bundle_record(model_id, descriptor)
                state = _TransformerCryptoState(
                    bundle=bundle,
                    bundle_fingerprint=bundle_fingerprint,
                    mode="none" if self._offset_workers else self.correlation_mode,
                    privacy_mode=str(bundle.privacy.get("mode", "public")),
                    privacy_protocol=str(bundle.privacy.get("protocol", "masked_w4a4")),
                )
                self._transformer_states[model_id] = state

            if self.experiment is not None and (
                state.privacy_mode != self.experiment.privacy_mode
                or (expected_protocol is not None and state.privacy_protocol != expected_protocol)
                or state.bundle.privacy.get("verification_component", "none")
                != (self.experiment.verification_component or "none")
                or int(state.bundle.privacy.get("verification_target_failure_bits", 0))
                != self.experiment.verification_target_failure_bits
            ):
                raise ProtocolError("Experiment privacy mode does not match the client bundle", 409)

            if state.privacy_mode == "public" and not state.preparation_verified:
                if self.preparation_http is None:
                    raise ProtocolError("public inference requires a preparation service", 400)
                inference_response = self.http.get("/v1/models", headers=self.headers)
                _raise(inference_response)
                inference_models = [
                    item
                    for item in inference_response.json().get("data", [])
                    if item.get("id") == model_id
                ]
                if len(inference_models) != 1:
                    raise ProtocolError("inference service does not serve the requested model", 404)
                inference = inference_models[0].get("runtime") or {}
                if (
                    self.experiment is not None
                    and selected_metal_rows is not None
                    and (
                        inference.get("kernel_backend") != "mlx-metal+cpu"
                        or inference.get("kernel_min_rows") != selected_metal_rows
                    )
                ):
                    raise ProtocolError("Metal inference kernel differs from Experiment", 409)
                if (
                    inference.get("body_fingerprint")
                    != state.bundle.privacy.get("body_fingerprint")
                    or inference.get("stage_commitment")
                    != state.bundle.privacy.get("stage_commitment")
                    or inference.get("architecture") != state.bundle.manifest.get("architecture")
                    or inference.get("stage_count") != len(state.bundle.manifest.get("stages", []))
                ):
                    raise ProtocolError("inference and client model commitments do not match", 409)
                model_response = self.preparation_http.get(
                    "/v1/models",
                    headers=self.preparation_headers,
                )
                _raise(model_response)
                preparation_models = [
                    item
                    for item in model_response.json().get("data", [])
                    if item.get("id") == model_id
                ]
                if len(preparation_models) != 1:
                    raise ProtocolError(
                        "preparation service does not serve the requested model", 404
                    )
                preparation = preparation_models[0].get("preparation") or {}
                if (
                    self.experiment is not None
                    and selected_metal_rows is not None
                    and (
                        preparation.get("kernel_backend") != "mlx-metal+cpu"
                        or preparation.get("kernel_min_rows") != selected_metal_rows
                    )
                ):
                    raise ProtocolError("Metal preparation kernel differs from Experiment", 409)
                remote_stages = self._remote_stages(state)
                if not remote_stages or any(
                    not stage.weight_digest or stage.seeded_profile is None
                    for stage in remote_stages
                ):
                    raise ProtocolError(
                        "provider bundle lacks stage weight or ring commitments", 409
                    )
                if (
                    preparation.get("protocol") != "seeded-inventory/v1"
                    or preparation.get("body_fingerprint")
                    != state.bundle.privacy.get("body_fingerprint")
                    or preparation.get("stage_commitment")
                    != state.bundle.privacy.get("stage_commitment")
                    or preparation.get("weight_bits") != state.bundle.privacy.get("weight_bits")
                    or preparation.get("activation_bits")
                    != state.bundle.privacy.get("activation_bits")
                    or preparation.get("architecture") != state.bundle.manifest.get("architecture")
                    or preparation.get("stage_count")
                    != len(state.bundle.manifest.get("stages", []))
                ):
                    raise ProtocolError(
                        "preparation and inference model commitments do not match", 409
                    )
                state.preparation_verified = True
            if (
                self.experiment is not None
                and self.experiment.requires_preparation
                and not state.preparation_verified
            ):
                raise ProtocolError("Experiment requires seeded-inventory preparation", 409)
            return state

    def _client_owned_state(self, model_id: str) -> _TransformerCryptoState:
        if self._local_engine is None or self.experiment is None:
            raise ModelError("client-owned model is not configured")
        if model_id != self.experiment.model:
            raise ValueError("request model conflicts with Experiment model")
        if model_id not in self._local_engine.models:
            raise ModelError("client-owned model is no longer loaded")
        with self._transformer_state_lock:
            state = self._transformer_states.get(model_id)
            if state is not None:
                return state
            payload = self._local_engine.client_bundle(model_id, placement="client")
            bundle = ClientBundle.unpack(payload, threads=self._bundle_threads())
            metadata = bundle.manifest.get("metadata") or {}
            if (
                metadata.get("client_runtime") != self.experiment.client_runtime
                or metadata.get("privacy_mode") != self.experiment.privacy_mode
                or metadata.get("privacy_protocol") != self.experiment.privacy_protocol
                or bundle.privacy.get("protocol") != self.experiment.privacy_protocol
                or bundle.privacy.get("verification_component", "none") != "none"
            ):
                raise ProtocolError("client-owned bundle differs from Experiment composition", 409)
            state = _TransformerCryptoState(
                bundle=bundle,
                bundle_fingerprint=hashlib.sha256(payload).hexdigest(),
                mode="none",
                privacy_mode="client_only",
                privacy_protocol=str(bundle.privacy["protocol"]),
            )
            self._transformer_states[model_id] = state
            return state

    def _compiled_public_decoder(
        self,
        state: _TransformerCryptoState,
        *,
        max_input_tokens: int,
        max_new_tokens: int,
    ) -> Any | None:
        """Bind supported public execution before claiming any provider material."""
        if state.privacy_mode not in {"public", "client_only", "offset_public"}:
            return None
        from pllm.configuration import Model, Pipeline
        from pllm.modeling import lower_model
        from pllm.profiles import MaskedLinearCpu, VerifiedMaskedLinearCpu
        from pllm.quantization import SymmetricPerRow
        from pllm.verification import FreivaldsVerify
        from .model_binding import compile_runtime_model
        from .semantic_source import semantic_source_config

        if self._experiment_budget is not None and (
            max_input_tokens > self._experiment_budget.max_input_tokens
            or max_new_tokens > self._experiment_budget.max_new_tokens
        ):
            raise ModelError("response exceeds its immutable Experiment workload bounds")
        if self._private_boundary:
            # Head-only workers independently compile this public envelope once.
            # Each response separately admits its actual lookup/head counts.
            max_input_tokens = self._experiment_budget.max_input_tokens
            max_new_tokens = self._experiment_budget.max_new_tokens
        if self.prefill_cache_mode == "prefix" and state.privacy_mode in {"public", "offset_public"}:
            assert self.prefill_cache_bound_tokens is not None
            if max_input_tokens > self.prefill_cache_bound_tokens:
                raise ModelError("response exceeds its fixed prefix-cache input bound")
            max_input_tokens = self.prefill_cache_bound_tokens
        if self.experiment is not None:
            composition = Pipeline.from_spec(json.loads(self.experiment.canonical_composition))
        else:
            numeric = SymmetricPerRow(
                weight_bits=int(state.bundle.privacy["weight_bits"]),
                activation_bits=int(state.bundle.privacy["activation_bits"]),
            )
            if (
                state.bundle.privacy.get("verification_component", "none")
                == "pllm/freivalds-verify/v1"
            ):
                composition = VerifiedMaskedLinearCpu(
                    Model(state.bundle.model_id),
                    quantization=numeric,
                    verification=FreivaldsVerify(
                        target_failure_bits=int(
                            state.bundle.privacy["verification_target_failure_bits"]
                        )
                    ),
                )
            else:
                composition = MaskedLinearCpu(Model(state.bundle.model_id), quantization=numeric)
        try:
            plan = lower_model(
                semantic_source_config(state.bundle.cfg),
                batch=1,
                max_input_tokens=max_input_tokens,
                max_new_tokens=max_new_tokens,
            )
        except ValueError as exc:
            if "has no decoder adapter" not in str(exc):
                raise
            # Existing import-only decoders stay on the already admitted
            # runtime graph until they lower into the shared semantic IR.
            if state.privacy_mode == "client_only" or "state" in composition.components:
                raise ModelError("selected client state requires a semantic decoder adapter") from exc
            return None
        coverage = plan.coverage(composition)
        verified = state.bundle.privacy.get(
            "verification_component"
        ) == "pllm/freivalds-verify/v1" and (
            self.experiment is None
            or self.experiment.verification_component == "pllm/freivalds-verify/v1"
        )
        if not coverage.complete and not verified:
            # Existing runtime-only operators remain on their separately admitted
            # path until their generic compiler capabilities are implemented.
            if state.privacy_mode == "client_only" or "state" in composition.components:
                raise ModelError("selected client state has incomplete compiler coverage")
            return None
        return compile_runtime_model(plan, state.bundle, composition=composition)

    def _prefill_cache_candidate(
        self,
        state: _TransformerCryptoState,
        compiled: CompiledRuntimeModel | None,
        ids: list[int],
        *,
        store: bool,
        previous_id: str | None = None,
    ) -> tuple[ExactPrefillCache, str] | None:
        if (
            self.prefill_cache_bytes == 0
            or not store
            or previous_id is not None
            or state.privacy_mode not in {"public", "offset_public"}
            or compiled is None
        ):
            return None
        graphs = compiled._plan.to_dict()
        selected_state = json.loads(compiled._canonical_composition)["components"].get("state", {})
        if selected_state.get("params", {}).get("retention") is not None:
            raise ModelError("retained response-owned state cannot use a full-KV cache")
        for phase in ("prefill", "decode"):
            graph = graphs[phase]
            if any(
                row["kind"] not in {"key", "value"}
                for row in (*graph["state_inputs"], *graph["state_outputs"])
            ) or any(
                operation["attributes"].get("attention_domain", {}).get("layout")
                == "batch_kv_heads_query_window_feature"
                for operation in graph["operations"]
            ):
                return None
        if self.prefill_cache_mode == "prefix":
            self._decoder_continuation(compiled).admit(1, max(1, len(ids) - 1))
        from pllm.profiles import resolve_runtime_composition
        from pllm.configuration import Pipeline
        composition = Pipeline.from_spec(json.loads(compiled._canonical_composition))
        numeric = resolve_runtime_composition(composition)
        cache_component = composition.components.get("cache")
        generated_prefixes = bool(cache_component is not None and cache_component.params.get("generated_prefixes"))
        if numeric is not None and numeric.verification_component and not numeric.prefix_cache_bytes:
            # A bare cache override did not reserve a composed failure budget.
            return None
        reduction = None if numeric is None else numeric.causal_reduction
        verification_bits = 0 if numeric is None else numeric.verification_target_failure_bits
        with self._transformer_state_lock:
            cache = state.prefill_cache
            if cache is None:
                cache = ExactPrefillCache(self.prefill_cache_bytes, causal_reduction=reduction,
                                         verification_failure_bits=verification_bits,
                                         generated_prefixes=generated_prefixes)
            capsule = composition.components.get("public_prefix")
            if capsule is not None and state.public_prefix_binding != compiled.digest:
                from .public_prefix import import_capsule
                self.audit.public_prefix_artifact_local_bytes += import_capsule(
                    compiled, capsule, cache, state.bundle_fingerprint)
                state.public_prefix_binding = compiled.digest
            state.prefill_cache = cache
        return cache, prefill_key(compiled.digest, state.bundle_fingerprint, ids, causal_reduction=reduction)

    @staticmethod
    def _decoder_continuation(compiled: CompiledRuntimeModel):
        from pllm.configuration import Pipeline

        return compiled._plan.continuation_schedule(
            Pipeline.from_spec(json.loads(compiled._canonical_composition))
        )

    def _admitted_decoder_continuation(
        self, session_value: dict[str, Any], compiled: CompiledRuntimeModel
    ):
        """Require an independently bound provider extension; never downgrade."""
        contract = self._decoder_continuation(compiled)
        if session_value.get("decoder_continuation") != contract.handshake_spec():
            raise ModelError("provider did not admit the native decoder continuation extension")
        return contract

    @staticmethod
    def _render_cached_decoder_prompt(state: _TransformerCryptoState, messages: list[Any], **kwargs: Any) -> str:
        # Strict templates may inspect tool_calls even for ordinary assistant
        # text. Supply its generic empty value rather than changing token cohort
        # through the bundle renderer's deterministic fallback.
        rows = [dict(row.to_prompt_dict() if hasattr(row, "to_prompt_dict") else row) for row in messages]
        for row in rows:
            if row.get("role") == "assistant":
                row.setdefault("tool_calls", [])
        return state.bundle.render_prompt(rows, **kwargs)

    @staticmethod
    def _profitable_cached_prefix(
        position: int,
        total: int,
        state: _TransformerCryptoState,
    ) -> bool:
        # Both candidates pack one query block per stage. This compares covered
        # stage-body estimates; measured counters, not this estimate, prove gain.
        if not 0 < position < total:
            return False
        stages = tuple(
            stage for stage in state.bundle.stages.values() if stage.client_weight is None
        )
        if not stages:
            return False
        per_row = sum(
            (stage.in_features + stage.out_features) * stage.wire_bits // 8 for stage in stages
        )
        overhead = 1024 * len(stages)
        return (total - position) * per_row + overhead < total * per_row + overhead

    def _prepare_inventory_locked(
        self,
        model_id: str,
        state: _TransformerCryptoState,
        rows: int,
        stage_rows: dict[str, int] | None = None,
        phase_rows: dict[str, dict[str, int]] | None = None,
    ) -> PreparedInventory:
        self._begin_preparation()
        try:
            return self._prepare_inventory(model_id, state, rows, stage_rows, phase_rows)
        finally:
            self._end_preparation()

    def _prepare_inventory(
        self,
        model_id: str,
        state: _TransformerCryptoState,
        rows: int,
        stage_rows: dict[str, int] | None = None,
        phase_rows: dict[str, dict[str, int]] | None = None,
    ) -> PreparedInventory:
        if self.preparation_http is None:
            raise ProtocolError("public inference requires a preparation service", 400)
        remote_stages = self._remote_stages(state)
        response = self._control_post(self.http,
            "/v1/runtime/inventories",
            headers=self.headers,
            json={
                "model": model_id,
                "rows": rows,
                **({"stage_rows": stage_rows} if stage_rows is not None else {}),
            },
        )
        _raise(response)
        value = response.json()
        inventory_id = str(value["id"])
        prepared_stages: dict[str, PreparedStageRows] = {}
        def cancel_remote():
            for client, path, headers in (
                (self.http, f"/v1/runtime/inventories/{inventory_id}/cancel", self.headers),
                (self.preparation_http, f"/v1/preparation/inventories/{inventory_id}/cancel", self.preparation_headers),
            ):
                try:
                    self._control_post(client, path, headers=headers)
                except Exception:
                    pass
        try:
            descriptor = value.get("preparation_authorization") or {}
            expected_verification = (
                self.experiment.verification_component
                if self.experiment is not None
                else state.bundle.privacy.get("verification_component", "none")
            )
            expected_failure_bits = (
                self.experiment.verification_target_failure_bits
                if self.experiment is not None
                else int(state.bundle.privacy.get("verification_target_failure_bits", 0))
            )
            expected = {
                "body_fingerprint": state.bundle.privacy.get("body_fingerprint"),
                "stage_commitment": state.bundle.privacy.get("stage_commitment"),
                "weight_bits": state.bundle.privacy.get("weight_bits"),
                "activation_bits": state.bundle.privacy.get("activation_bits"),
                "verification_component": expected_verification or "none",
                "verification_target_failure_bits": expected_failure_bits,
            }
            if any(descriptor.get(name) != item for name, item in expected.items()):
                raise ProtocolError("inventory authorization commitments do not match", 409)
            weight_bits = expected["weight_bits"]
            activation_bits = expected["activation_bits"]
            if not isinstance(weight_bits, int) or not isinstance(activation_bits, int):
                raise ProtocolError("inventory authorization precision is invalid", 409)
            authorization = SessionAuthorization(
                session_id=inventory_id,
                model=model_id,
                body_fingerprint=str(expected["body_fingerprint"]),
                stage_commitment=str(expected["stage_commitment"]),
                weight_bits=weight_bits,
                activation_bits=activation_bits,
                max_attempts=int(descriptor["max_attempts"]),
                rows=int(descriptor["rows"]),
                stage_ids=tuple(str(stage_id) for stage_id in descriptor["stage_ids"]),
                verification_component=str(expected["verification_component"]),
                verification_target_failure_bits=int(expected["verification_target_failure_bits"]),
                stage_rows=tuple(descriptor.get("stage_rows", ())),
            )
            if authorization.rows != rows or authorization.stage_ids != tuple(
                stage.id for stage in remote_stages
            ):
                raise ModelError("preparation inventory authorization mismatch")
            if authorization.stage_rows != (tuple(stage_rows[s.id] for s in remote_stages) if stage_rows else ()):
                raise ModelError("provider did not acknowledge exact preparation demand")
            authorization_payload = authorization.pack()
            self.audit.session_authorization_upload_bytes += len(authorization_payload)
            authorized = self.preparation_http.post(
                f"/v1/preparation/inventories/{inventory_id}/authorize",
                headers={
                    **self.preparation_headers,
                    "Content-Type": "application/octet-stream",
                },
                content=authorization_payload,
            )
            self.audit.session_authorization_download_bytes += len(authorized.content)
            _raise(authorized)
            if SessionAuthorizationAck.unpack(authorized.content).session_id != inventory_id:
                raise ModelError("preparation inventory authorization mismatch")

            verification_policy = _client_freivalds_policy(authorization, remote_stages)
            audit_lock = threading.Lock()
            def prepare_stage(stage):
                if self._closing:
                    raise ProtocolError("client closed before stage preparation")
                profile = stage.seeded_profile
                assert profile is not None
                request = PreparationRequest(
                    attempt_id=secrets.token_hex(16),
                    session_id=inventory_id,
                    model=model_id,
                    body_fingerprint=str(state.bundle.privacy["body_fingerprint"]),
                    stage_id=stage.id,
                    weight_digest=stage.weight_digest,
                    rows=authorization.rows_for(stage.id),
                    in_features=stage.in_features,
                    out_features=stage.out_features,
                    seed=secrets.token_bytes(32),
                    weight_bits=int(state.bundle.privacy["weight_bits"]),
                    activation_bits=int(state.bundle.privacy["activation_bits"]),
                    signed_output_bound=profile.signed_output_bound,
                    ring=profile.ring,
                    modulus=profile.modulus,
                    wire_bits=profile.wire_bits,
                )
                payload = request.pack()
                with audit_lock:
                    self.audit.preparation_upload_bytes += len(payload)
                from .telemetry import record_protocol_bytes, start_protocol_span

                protocol_span = start_protocol_span(
                    stage.id,
                    len(payload),
                    0,
                    phase="offline",
                )
                prepared = None
                try:
                    max_prepared_bytes = 4_096
                    if verification_policy is not None:
                        max_prepared_bytes += (
                            request.rows * verification_policy.checks * request.in_features * 4
                        )
                    prepared = self.preparation_http.send(
                        self.preparation_http.build_request(
                            "POST",
                            f"/v1/preparation/inventories/{inventory_id}/stages/{stage.id}",
                            headers={
                                **self.preparation_headers,
                                "Content-Type": "application/octet-stream",
                                PREPARATION_ACCOUNTING_HEADER: PREPARATION_ACCOUNTING_CAPABILITY,
                            },
                            content=payload,
                        ),
                        stream=True,
                    )
                    prepared_content = bytearray()
                    for chunk in prepared.iter_bytes():
                        with audit_lock:
                            self.audit.preparation_download_bytes += len(chunk)
                        if len(prepared_content) + len(chunk) > max_prepared_bytes:
                            raise ProtocolError("preparation response exceeds its bound", 413)
                        prepared_content.extend(chunk)
                    _raise(prepared)
                    prepared.close()
                except Exception as exc:
                    if prepared is not None:
                        prepared.close()
                    protocol_span.record_exception(exc)
                    protocol_span.end()
                    raise
                with audit_lock:
                    self.audit.preparation_attempts += 1
                    self.audit.preparation_rows += request.rows
                try:
                    ack = PreparationAck.unpack(bytes(prepared_content))
                except Exception as exc:
                    protocol_span.record_exception(exc)
                    protocol_span.end()
                    raise
                if ack.attempt_id != request.attempt_id or ack.stage_id != stage.id:
                    error = ModelError("preparation inventory acknowledgement mismatch")
                    protocol_span.record_exception(error)
                    protocol_span.end()
                    raise error
                with audit_lock:
                    self.audit.correction_push_bytes += ack.correction_bytes
                    if ack.correction_ack_bytes is not None:
                        self.audit.correction_ack_bytes += ack.correction_ack_bytes
                        self.audit.correction_ack_accounted_push_bytes += ack.correction_bytes
                    if phase_rows is not None and ack.correction_rows == request.rows:
                        prefill_rows = phase_rows["prefill"].get(stage.id, 0)
                        decode_rows = phase_rows["decode"].get(stage.id, 0)
                        padding_rows = request.rows - prefill_rows - decode_rows
                        verification_bytes = len(ack.verification_payload)
                        if (padding_rows >= 0 and verification_bytes % request.rows == 0
                                and ack.correction_row_payload_bytes is not None):
                            # The serializer certifies bitstream layout and actual
                            # length. Shared phase-boundary bytes stay residual;
                            # never estimate from matrix dimensions.
                            prefill_bytes, decode_bytes = ack.material_body_bytes_by_phase(prefill_rows, decode_rows)
                            self.audit.preparation_attributed_body_bytes += (
                                len(payload) + len(prepared_content) + ack.correction_bytes)
                            self.audit.preparation_decode_material_body_bytes += decode_bytes
                            self.audit.preparation_prefill_material_body_bytes += prefill_bytes
                            self.audit.preparation_decode_rows_issued += decode_rows
                            self.audit.preparation_prefill_rows_issued += prefill_rows
                            self.audit.preparation_padding_rows_issued += padding_rows
                    self.audit.preparation_server_ns += ack.server_ns
                    self.audit.correction_push_ns += ack.push_ns
                record_protocol_bytes("client", "preparation", len(payload), stage.id)
                record_protocol_bytes("preparation", "client", len(prepared_content), stage.id)
                protocol_span.set_attribute(
                    "pllm.preparation_inference.bytes", ack.correction_bytes
                )
                protocol_span.set_attribute("pllm.preparation_client.bytes", len(prepared_content))
                protocol_span.end()
                verification = None
                verification_binding = b""
                if verification_policy is not None:
                    verification_binding = freivalds_binding(authorization, request)
                    if (
                        ack.verification_component != authorization.verification_component
                        or ack.verification_checks != verification_policy.checks
                        or ack.verification_material_id
                        != freivalds_material_id(authorization, request)
                    ):
                        raise ModelError("preparation verification acknowledgement mismatch")
                    verification = _native.import_freivalds(
                        ack.verification_payload,
                        ack.verification_tag,
                        request.seed,
                        request.rows,
                        request.in_features,
                        request.out_features,
                        verification_binding,
                        ack.verification_material_id,
                        signed_qmax(request.activation_bits),
                        request.signed_output_bound,
                        ack.verification_max_row_l1,
                        verification_policy,
                    )
                return stage.id, PreparedStageRows(
                    request=request,
                    verification=verification,
                    verification_binding=verification_binding,
                )

            from .preparation_window import preparation_job_work_bytes, run_preparation_window
            def work_bytes(stage):
                return preparation_job_work_bytes(
                    rows=authorization.rows_for(stage.id), in_features=stage.in_features,
                    out_features=stage.out_features, verification_rows=rows,
                    verification_checks=0 if verification_policy is None else verification_policy.checks,
                )
            def accept(item):
                prepared_stages[item[0]] = item[1]
            run_preparation_window(remote_stages, width=self.preparation_stage_window,
                max_bytes=self.preparation_stage_window_bytes,
                cost=work_bytes, prepare=prepare_stage, accept=accept, abort=cancel_remote,
                discard=lambda item: item[1].cancel(), cancelled=lambda: self._closing)
            sealed = self._control_post(self.http,
                f"/v1/runtime/inventories/{inventory_id}/ready",
                headers=self.headers,
            )
            _raise(sealed)
            if sealed.json().get("status") != "ready":
                raise ModelError("inference did not commit prepared inventory")
            return PreparedInventory(inventory_id, rows, prepared_stages, demand=stage_rows is not None,
                                     _audit=self.audit.record_inventory)
        except BaseException:
            self.audit.preparation_failures += 1
            cancel_remote()
            for prepared_stage in prepared_stages.values():
                prepared_stage.cancel()
            raise

    def _cancel_prepared_inventory(self, inventory: PreparedInventory) -> None:
        inventory.cancel()
        try:
            self._control_post(self.http, f"/v1/runtime/inventories/{inventory.id}/cancel", headers=self.headers)
        except Exception:
            pass
        if self.preparation_http is not None:
            try:
                self._control_post(self.preparation_http,
                    f"/v1/preparation/inventories/{inventory.id}/cancel",
                    headers=self.preparation_headers,
                )
            except Exception:
                pass

    def _control_post(self, client, path: str, **kwargs):
        """Charge directed control bodies, including rejected lifecycle controls."""
        role = "preparation" if client is self.preparation_http else "inference"
        try:
            response = client.post(path, **kwargs)
        except httpx.HTTPError as error:
            request = getattr(error, "request", None)
            if request is not None:
                name = f"{role}_control_upload_bytes"
                setattr(self.audit, name, getattr(self.audit, name) + len(request.content))
            raise
        for direction, count in (("upload", len(response.request.content)),
                                 ("download", len(response.content))):
            name = f"{role}_control_{direction}_bytes"
            setattr(self.audit, name, getattr(self.audit, name) + count)
        return response

    def _fresh_decode_epoch_inventory(self, model_id, state, rows, stage_rows, *, initial=False) -> None:
        """Only idle, fully retired material may precede a fresh epoch."""
        with self._transformer_state_lock:
            if self._closing or state.active_prepared_responses or state.refill_in_progress:
                raise ModelError("decode epoch preparation requires an idle live client")
            inventory = state.prepared_inventory
            if (initial and inventory is not None and inventory.claimed == 0
                    and inventory.capacity == rows and not inventory.status()["reserved"]
                    and stage_rows is not None and set(inventory.stages) == set(stage_rows)
                    and all(inventory.stages[sid].request.rows == count
                            for sid, count in stage_rows.items())
                    and self._prepared_inventory_is_live(inventory)):
                # Explicit SDK/benchmark preparation may already have issued this
                # exact first epoch. It has never been reserved or consumed.
                return
            for inventory in (state.prepared_inventory, state.prepared_inventory_spare):
                if inventory is not None:
                    if inventory.status()["reserved"]:
                        raise ModelError("decode epoch previous reservation remains active")
                    self._cancel_prepared_inventory(inventory)
            state.prepared_inventory = state.prepared_inventory_spare = None
            state.prepared_inventory = self._prepare_inventory_locked(model_id, state, rows, stage_rows)

    def _open_decode_epoch(self, model_id, state, rows, stage_rows, *, max_output_tokens,
                           compiled, cancelled=lambda: None, initial=False):
        # Preparation and reservation are one model-local admission transaction.
        # Otherwise another request could replace fresh, not-yet-leased material.
        with self._transformer_state_lock:
            try:
                cancelled()
                self._fresh_decode_epoch_inventory(model_id, state, rows, stage_rows, initial=initial)
                cancelled()
                result = self._open_transformer_session(model_id,
                    max_output_tokens=max_output_tokens, required_rows=rows, compiled=compiled,
                    semantic_input_tokens=self.prefill_cache_bound_tokens)
                self.audit.decode_epochs_started += 1
                return result
            except BaseException as error:
                inventory = state.prepared_inventory
                if inventory is not None and not inventory.status()["reserved"]:
                    _cleanup_calls([lambda: self._cancel_prepared_inventory(inventory)], primary=error)
                    state.prepared_inventory = None
                raise

    def _prepared_inventory_is_live(self, inventory: PreparedInventory) -> bool:
        try:
            response = self.http.get(
                f"/v1/runtime/inventories/{inventory.id}", headers=self.headers
            )
            self.audit.inference_control_download_bytes += len(response.content)
        except httpx.HTTPError:
            raise
        if response.status_code in {404, 409, 410}:
            return False
        _raise(response)
        value = response.json()
        return (
            value.get("status") == "ready" and int(value.get("next_row", -1)) == inventory.claimed
        )

    def _install_prepared_inventory_locked(
        self,
        state: _TransformerCryptoState,
        inventory: PreparedInventory,
    ) -> None:
        previous = state.prepared_inventory
        state.prepared_inventory = inventory
        if previous is None or previous is inventory:
            return
        if previous.status()["reserved"] == 0:
            self._cancel_prepared_inventory(previous)
        else:
            state.retired_inventories.append(previous)

    def _background_refill(
        self,
        model_id: str,
        state: _TransformerCryptoState,
    ) -> None:
        with self._transformer_state_lock:
            inventory = state.prepared_inventory
            if (
                self._closing
                or state.active_prepared_responses != 0
                or inventory is None
                or state.prepared_inventory_spare is not None
                or state.refill_in_progress
            ):
                return
            state.refill_in_progress = True
            capacity = max(self.prepared_inventory_rows, inventory.capacity)
        try:
            spare = self._prepare_inventory_locked(model_id, state, capacity)
        except Exception:
            spare = None
        with self._transformer_state_lock:
            state.refill_in_progress = False
            if (
                spare is not None
                and not self._closing
                and state.active_prepared_responses == 0
                and state.prepared_inventory is inventory
                and state.prepared_inventory_spare is None
            ):
                state.prepared_inventory_spare = spare
            elif spare is not None:
                self._cancel_prepared_inventory(spare)

    def _finish_prepared_response(
        self,
        model_id: str,
        state: _TransformerCryptoState,
        inventory: PreparedInventoryLease,
    ) -> None:
        try:
            inventory.close()
        except BaseException as error:
            _cleanup_calls([self._stop_prepared_admission], primary=error)
            raise
        finally:
            self._end_online()
            with self._transformer_state_lock:
                state.active_prepared_responses = max(0, state.active_prepared_responses - 1)
        with self._transformer_state_lock:
            retained: list[PreparedInventory] = []
            for retired in state.retired_inventories:
                if retired.status()["reserved"] == 0:
                    self._cancel_prepared_inventory(retired)
                else:
                    retained.append(retired)
            state.retired_inventories = retained
            if (
                self.background_inventory_refill
                and not self._closing
                and state.active_prepared_responses == 0
                and state.prepared_inventory_spare is None
            ):
                state.refill_future = self._provider_executor.submit(self._background_refill, model_id, state)

    def _begin_online(self) -> None:
        with self._activity_lock:
            if self._closing:
                raise ModelError("prepared client admission is closed")
            if self._preparation_active:
                raise ModelError("prepared inventory refill is in progress; retry when ready")
            self._online_active += 1

    def _end_online(self) -> None:
        with self._activity_lock:
            self._online_active = max(0, self._online_active - 1)

    def _begin_preparation(self) -> None:
        with self._activity_lock:
            if self._closing:
                raise ModelError("prepared client admission is closed")
            if self._online_active:
                self.audit.preparation_requests_during_online += 1
                raise ModelError("preparation cannot run while inference is online")
            self._preparation_active += 1

    def _end_preparation(self) -> None:
        with self._activity_lock:
            self._preparation_active = max(0, self._preparation_active - 1)

    def _stop_prepared_admission(self) -> None:
        with self._activity_lock:
            self._closing = True
        if self._prepared_queue is not None:
            self._prepared_queue.close()

    def _cancel_transformer_session(self, session_id: str) -> bool:
        try:
            canceled = self._control_post(self.http,
                f"/v1/runtime/sessions/{session_id}/cancel", headers=self.headers)
            if canceled.status_code not in {404, 410}:
                _raise(canceled)
            return True
        except Exception:
            # No later queued or explicitly prepared request may treat an
            # unacknowledged online owner as idle.
            self._stop_prepared_admission()
            return False

    def _open_transformer_session(
        self,
        model_id: str,
        *,
        max_output_tokens: int,
        required_rows: int | None = None,
        compiled: CompiledRuntimeModel | None = None,
        semantic_input_tokens: int | None = None,
    ) -> tuple[dict[str, Any], _TransformerCryptoState, Any | None]:
        if compiled is not None and (
            type(semantic_input_tokens) is not int or semantic_input_tokens < 1
        ):
            raise ModelError("compiled session is missing its input bound")
        state = self._transformer_state(model_id)
        prepared_public = state.privacy_mode == "public"
        provider: Any | None
        with self._transformer_state_lock:
            if prepared_public:
                if state.refill_in_progress:
                    raise ModelError("prepared inventory refill is in progress; retry when ready")
                needed = max(1, int(required_rows or max_output_tokens + 1))
                inventory = state.prepared_inventory
                if inventory is not None and not self._prepared_inventory_is_live(inventory):
                    self._cancel_prepared_inventory(inventory)
                    state.prepared_inventory = None
                    inventory = None
                if (
                    (inventory is None or inventory.available < needed)
                    and state.prepared_inventory_spare is not None
                    and state.prepared_inventory_spare.available >= needed
                ):
                    spare = state.prepared_inventory_spare
                    state.prepared_inventory_spare = None
                    if self._prepared_inventory_is_live(spare):
                        inventory = spare
                        self._install_prepared_inventory_locked(state, inventory)
                    else:
                        self._cancel_prepared_inventory(spare)
                if inventory is None or inventory.available < needed:
                    raise ModelError(
                        "prepared inventory became unavailable before reservation; "
                        "retry the request"
                    )
                provider = inventory.reserve(needed)
            else:
                provider = None

            online_started = False
            session_id = None
            try:
                session_body: dict[str, Any] = {
                    "model": model_id,
                    "max_output_tokens": max_output_tokens,
                }
                if prepared_public:
                    assert provider is not None
                    session_body["execution"] = "seeded-preparation"
                    session_body["inventory_id"] = provider.inventory_id
                    session_body["inventory_start"] = provider.reservation_start
                    session_body["inventory_rows"] = provider.reservation_rows
                    if self.prepared_request_encoding != "raw":
                        session_body["prepared_request_encoding"] = self.prepared_request_encoding
                    if compiled is not None:
                        session_body["decoder_plan"] = {
                            "schema": "pllm.decoder_session.v1",
                            "digest": compiled.model_plan_digest,
                            "max_input_tokens": semantic_input_tokens,
                            "body_fingerprint": compiled.to_spec()["body_fingerprint"],
                            "stage_commitment": compiled.to_spec()["stage_commitment"],
                            "runtime_config_digest": compiled.runtime_config_digest,
                        }
                        if self.prefill_cache_mode == "prefix":
                            session_body["decoder_continuation"] = {
                                "composition": json.loads(compiled._canonical_composition),
                                "contract": self._decoder_continuation(compiled).handshake_spec(),
                            }
                if state.context_ids:
                    session_body["context_ids"] = list(state.context_ids.values())
                if prepared_public:
                    self._begin_online()
                    online_started = True
                session_response = self._control_post(self.http,
                    "/v1/runtime/sessions",
                    headers=self.headers,
                    json=session_body,
                )
                _raise(session_response)
                session_value = session_response.json()
                session_id = session_value.get("id")
                if not isinstance(session_id, str) or not 1 <= len(session_id) <= 256:
                    session_id = None
                    raise ModelError("provider session identifier is invalid")
                if (not isinstance(session_value.get("response_id"), str)
                        or not 1 <= len(session_value["response_id"]) <= 256):
                    raise ModelError("provider response identifier is invalid")
                if prepared_public and session_value.get("prepared_request_encoding", "raw") != self.prepared_request_encoding:
                    raise ModelError("provider did not admit the prepared request encoding")
            except BaseException as error:
                if prepared_public and provider is not None:
                    calls = []
                    if online_started:
                        if session_id is not None:
                            calls.append(lambda: self._cancel_transformer_session(session_id))
                        else:
                            calls.append(self._stop_prepared_admission)
                    def close_reservation():
                        try:
                            provider.close()
                        except BaseException as error:
                            _cleanup_calls([self._stop_prepared_admission], primary=error)
                            raise
                    calls.append(close_reservation)
                    if online_started:
                        calls.append(self._end_online)
                    _cleanup_calls(calls, primary=error)
                raise
            if prepared_public:
                state.active_prepared_responses += 1

            if state.privacy_mode == "proprietary":
                if state.privacy_protocol in {"blinded_ole_w4a4", "guarded_blinded_w4a4"}:
                    if state.mode not in {"bfv", "local-test"}:
                        raise ValueError(f"unsupported proprietary correlation mode {state.mode!r}")
                    provider = _BlindedCorrelationProvider(
                        client=self,
                        session_id=session_id,
                        state=state,
                        prefetch=self.correlation_prefetch,
                    )
                elif state.privacy_protocol == "direct_bfv_w4a4":
                    provider = None
                else:
                    raise ModelError(f"unsupported proprietary protocol {state.privacy_protocol!r}")
            elif state.privacy_mode != "public":
                raise ModelError(f"unsupported server privacy mode {state.privacy_mode!r}")
            return session_value, state, provider

    def preprocess(
        self,
        model_id: str,
        count: int,
        *,
        stages: list[str] | None = None,
        stage_rows: dict[str, int] | None = None,
        _phase_rows: dict[str, dict[str, int]] | None = None,
    ) -> dict[str, Any]:
        if self._local_engine is not None:
            raise ModelError("client-only topology does not use a preparation inventory")
        descriptor = self._model_manifest(model_id, refresh=True)
        target = max(0, int(count))
        if descriptor.get("metadata", {}).get("client_runtime") in {
            "masked_transformer_v1",
            "direct_fhe_transformer_v1",
            "blinded_ole_transformer_v1",
            "guarded_blinded_transformer_v1",
        }:
            if descriptor.get("metadata", {}).get("privacy_mode") == "public":
                state = self._transformer_state(model_id)
                selected = set(stages or (stage.id for stage in self._remote_stages(state)))
                expected = {stage.id for stage in self._remote_stages(state)}
                if stage_rows is not None and (self.preparation_allocation != "demand"
                    or set(stage_rows) != expected or any(type(n) is not int or not 1 <= n <= target for n in stage_rows.values())):
                    raise ModelError("invalid preparation stage demand")
                if selected != expected:
                    raise ValueError("prepared inventories require every remote stage")
                with self._transformer_state_lock:
                    if state.active_prepared_responses:
                        raise ModelError("prepared inventory refill requires an idle model")
                    prepared_inventory = state.prepared_inventory
                    if prepared_inventory is not None and not self._prepared_inventory_is_live(
                        prepared_inventory
                    ):
                        self._cancel_prepared_inventory(prepared_inventory)
                        state.prepared_inventory = None
                        prepared_inventory = None
                    if prepared_inventory is not None and stage_rows is not None and any(
                        prepared_inventory.stages[sid].request.rows < count for sid, count in stage_rows.items()
                    ):
                        self._cancel_prepared_inventory(prepared_inventory)
                        state.prepared_inventory = None
                        prepared_inventory = None
                    if (
                        (prepared_inventory is None or prepared_inventory.available < target)
                        and state.prepared_inventory_spare is not None
                        and state.prepared_inventory_spare.available >= target
                    ):
                        spare = state.prepared_inventory_spare
                        state.prepared_inventory_spare = None
                        if self._prepared_inventory_is_live(spare):
                            prepared_inventory = spare
                            self._install_prepared_inventory_locked(state, prepared_inventory)
                        else:
                            self._cancel_prepared_inventory(spare)
                    if prepared_inventory is None or prepared_inventory.available < target:
                        if state.prepared_inventory_spare is not None:
                            self._cancel_prepared_inventory(state.prepared_inventory_spare)
                            state.prepared_inventory_spare = None
                        prepared_inventory = self._prepare_inventory_locked(
                            model_id,
                            state,
                            max(self.prepared_inventory_rows, target),
                            stage_rows,
                            _phase_rows,
                        )
                        self._install_prepared_inventory_locked(state, prepared_inventory)
                        generated = prepared_inventory.capacity
                    else:
                        generated = 0
                    if self.background_inventory_refill:
                        spare = state.prepared_inventory_spare
                        if spare is not None and spare.available < target:
                            self._cancel_prepared_inventory(spare)
                            state.prepared_inventory_spare = None
                            spare = None
                        if spare is None:
                            state.prepared_inventory_spare = self._prepare_inventory_locked(
                                model_id,
                                state,
                                max(self.prepared_inventory_rows, target),
                            )
                            generated += state.prepared_inventory_spare.capacity
                    available = prepared_inventory.available
                return {
                    "object": "runtime.preprocessing_result",
                    "model": model_id,
                    "privacy_mode": "public",
                    "protocol": "seeded-inventory/v1",
                    "status": "ready",
                    "generated": generated,
                    "available_per_stage": {sid: (prepared_inventory.stages[sid].request.rows if prepared_inventory.demand and available
                                                  else available) for sid in expected},
                }
            session, state, provider = self._open_transformer_session(model_id, max_output_tokens=1)
            if state.privacy_mode == "proprietary" and state.privacy_protocol == "direct_bfv_w4a4":
                complete = self.http.post(
                    f"/v1/runtime/sessions/{session['id']}/complete",
                    headers=self.headers,
                    json={"usage": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}},
                )
                _raise(complete)
                return {
                    "object": "runtime.preprocessing_result",
                    "model": model_id,
                    "privacy_mode": "proprietary",
                    "protocol": "direct_bfv_w4a4",
                    "generated": 0,
                    "available_per_stage": {},
                    "message": "direct BFV reference mode does not use preprocessing",
                }
            assert provider is not None
            selected = set(stages or state.bundle.stages)
            unknown = selected.difference(state.bundle.stages)
            if unknown:
                raise ValueError(f"unknown transformer stages: {sorted(unknown)}")
            generated = 0
            inventory: dict[str, int] = {}
            for stage_id, stage in state.bundle.stages.items():
                if (
                    stage_id not in selected
                    or stage_id == "embed_tokens"
                    or stage.client_weight is not None
                ):
                    continue
                with state.locks[stage_id]:
                    queue = state.queues[stage_id]
                    missing = max(0, target - len(queue))
                    if missing:
                        queue.extend(provider._create(stage, missing))
                        generated += missing
                    inventory[stage_id] = len(queue)
            complete = self.http.post(
                f"/v1/runtime/sessions/{session['id']}/complete",
                headers=self.headers,
                json={"usage": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}},
            )
            _raise(complete)
            return {
                "object": "runtime.preprocessing_result",
                "model": model_id,
                "generated": generated,
                "available_per_stage": inventory,
                "contexts": len(state.context_ids),
                "context_reused": bool(state.context_ids),
            }

        session, _, source = self._open_private_session(model_id, max_output_tokens=1)
        before = len(source.state.pool)
        available = source.replenish(target)
        complete = self.http.post(
            f"/v1/runtime/sessions/{session['id']}/complete",
            headers=self.headers,
            json={"usage": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}},
        )
        _raise(complete)
        return {
            "object": "runtime.preprocessing_result",
            "model": model_id,
            "generated": available - before,
            "available": available,
            "context_reused": self.audit.public_context_bytes > 0,
        }

    def prepared_inventory_status(self, model: str) -> dict[str, Any]:
        if self._local_engine is not None:
            return {
                "status": "not-applicable",
                "capacity": 0,
                "available": 0,
                "reserved": 0,
                "burned": 0,
            }
        with self._transformer_state_lock:
            state = self._transformer_states.get(model)
            if state is None or state.prepared_inventory is None:
                return {
                    "status": "not-loaded",
                    "capacity": 0,
                    "available": 0,
                    "reserved": 0,
                    "burned": 0,
                }
            return state.prepared_inventory.status()

    @contextmanager
    def tokenizer_scope(self) -> Iterator[None]:
        """Reuse public tokenizer setup across one request's sizing and execution."""
        if self._tokenizer_owner.get() is not None:
            yield
            return
        owner = _ScopedTokenizer()
        token = self._tokenizer_owner.set(owner)
        try:
            yield
        finally:
            owner.close()
            self._tokenizer_owner.reset(token)

    def _response_tokenizer(self, bundle: ClientBundle) -> Tokenizer:
        owner = self._tokenizer_owner.get()
        return self._make_tokenizer(bundle) if owner is None else owner.get(bundle, self._make_tokenizer)

    def _make_tokenizer(self, bundle: ClientBundle) -> Tokenizer:
        selection = None
        if self.experiment is not None:
            from pllm.configuration import Pipeline
            selection = Pipeline.from_spec(json.loads(self.experiment.canonical_composition)).components.get("tokenizer")
        if selection is None:
            return bundle.tokenizer()
        from .indexed_tokenizer import IndexedClientTokenizer
        tokenizer = IndexedClientTokenizer(bundle, selection)
        self.audit.tokenizer_artifact_local_bytes += tokenizer.artifact_bytes
        return tokenizer

    def _response_input_tokens(self, model: str, input: str | list[Any]) -> int:
        """Count the complete rendered input, independent of cached-row reuse."""
        with self.tokenizer_scope():
            return self._count_response_input_tokens(model, input)

    def _count_response_input_tokens(self, model, input):
        state = self._transformer_state(model)
        messages = normalize_input(input)
        rendered = self._render_cached_decoder_prompt(state, messages, add_generation_prompt=True)
        return max(1, len(self._response_tokenizer(state.bundle).encode(
            rendered, add_bos=bool(state.bundle.tokenizer_descriptor.get("add_bos_token", True)))))

    def prepared_rows_for_response(
        self,
        model: str,
        input: str | list[Any],
        max_output_tokens: int,
        *,
        instructions: str | None = None,
        store: bool = True,
        _stage_demand: bool = False,
    ) -> int | tuple[int, dict[str, int] | None]:
        with self.tokenizer_scope():
            return self._prepared_rows_for_response(model, input, max_output_tokens,
                instructions=instructions, store=store, _stage_demand=_stage_demand)

    def _prepared_rows_for_response(self, model, input, max_output_tokens, *, instructions=None, store=True, _stage_demand=False, _phase_demand=False):
        if self._local_engine is not None:
            raise ModelError("client-only topology does not use a preparation inventory")
        state = self._transformer_state(model)
        messages = normalize_input(input, instructions=instructions)
        rendered = self._render_cached_decoder_prompt(state, messages, add_generation_prompt=True)
        tokenizer = self._response_tokenizer(state.bundle)
        add_bos = bool(state.bundle.tokenizer_descriptor.get("add_bos_token", True))
        ids = tokenizer.encode(rendered, add_bos=add_bos)
        full_ids = ids or [int(state.bundle.config["bos_token_id"])]
        cached = None
        if self.prefill_cache_bytes and store:
            compiled = self._compiled_public_decoder(
                state,
                max_input_tokens=len(full_ids),
                max_new_tokens=max_output_tokens,
            )
            candidate = self._prefill_cache_candidate(state, compiled, full_ids, store=store)
            if candidate is not None:
                cache, key = candidate
                cached = cache.get(
                    key,
                    position=len(full_ids),
                    layers=int(state.bundle.cfg["num_hidden_layers"]),
                )
                if cached is None and self.prefill_cache_mode == "prefix":
                    assert compiled is not None
                    prefix = cache.longest_prefix(
                        compiled.digest,
                        state.bundle_fingerprint,
                        full_ids,
                        layers=int(state.bundle.cfg["num_hidden_layers"]),
                    )
                    if prefix is not None and self._profitable_cached_prefix(
                        prefix[0], len(full_ids), state
                    ):
                        cached = prefix
        prefix_rows = (
            0 if cached is None else (cached[0] if type(cached[0]) is int else len(full_ids))
        )
        allowance = self._decode_epoch_allowance(0, max_output_tokens)
        required = max(1, len(full_ids) - prefix_rows + max(0, allowance - 1))
        if not _stage_demand:
            return required
        demand = None
        if self.preparation_allocation == "demand":
            compiled = self._compiled_public_decoder(state, max_input_tokens=len(full_ids), max_new_tokens=max_output_tokens)
            if compiled is None:
                raise ModelError("demand preparation requires a complete compiled schedule")
            if self._decode_epochs_enabled():
                contract = self._decoder_continuation(compiled)
                if len(full_ids) + max_output_tokens - 1 > contract.to_dict()["token_bound"]:
                    raise ModelError("decode epoch response exceeds fixed continuation token bound")
                if max_output_tokens > 1:
                    contract.admit(len(full_ids), max_output_tokens - 1)
            demand = compiled.prepared_stage_rows(len(full_ids) - prefix_rows, max(0, allowance - 1),
                                                  continuation=prefix_rows > 0)
        if _phase_demand:
            phases = (compiled.prepared_stage_phase_rows(len(full_ids) - prefix_rows, max(0, allowance - 1),
                continuation=prefix_rows > 0) if demand is not None and not self._decode_epochs_enabled()
                and self._inflight_prefix_owner is None and not self.background_inventory_refill else None)
            return required, demand, phases
        return required, demand

    def _decode_epochs_enabled(self) -> bool:
        return (self.preparation_decode_epoch_tokens is not None
                or self.preparation_decode_epoch_schedule is not None)

    def _decode_epoch_allowance(self, index: int, remaining: int) -> int:
        """Public epoch index only. Repeat final declared size; clip at cap only."""
        schedule = self.preparation_decode_epoch_schedule
        size = (schedule[min(index, len(schedule) - 1)] if schedule is not None
                else self.preparation_decode_epoch_tokens)
        return min(size, remaining) if size is not None else remaining

    def prepare_response(self, model: str, input, max_output_tokens: int, *, instructions=None, store=True):
        """Issue exactly the admitted response demand before online execution."""
        with self.tokenizer_scope():
            rows, demand, phases = self._prepared_rows_for_response(model, input, max_output_tokens,
                instructions=instructions, store=store, _stage_demand=True, _phase_demand=True)
            return self.preprocess(model, rows, stage_rows=demand, _phase_rows=phases)

    def _ensure_prepared_inventory(
        self,
        model_id: str,
        state: _TransformerCryptoState,
        required_rows: int,
        stage_rows: dict[str, int] | None = None,
        phase_rows: dict[str, dict[str, int]] | None = None,
    ) -> None:
        with self._transformer_state_lock:
            candidates = (state.prepared_inventory, state.prepared_inventory_spare)
            if any(
                inventory is not None
                and inventory.available >= required_rows
                and (stage_rows is None or all(inventory.stages[sid].request.rows >= count for sid, count in stage_rows.items()))
                and self._prepared_inventory_is_live(inventory)
                for inventory in candidates
            ):
                return
        self.preprocess(model_id, count=required_rows, stage_rows=stage_rows, _phase_rows=phase_rows)

    def close(self) -> None:
        primary = sys.exception()
        errors = []

        def retire(function, *args, **kwargs):
            try:
                function(*args, **kwargs)
            except BaseException as error:
                errors.append(error)

        with self._activity_lock:
            self._closing = True
            offset_transports = tuple(self._active_offset_transports.values())
            self._active_offset_transports.clear()
            boundary_transports = tuple(self._active_boundary_transports.values())
            self._active_boundary_transports.clear()
        for transport in boundary_transports:
            retire(transport.abort)
        if self._prepared_queue is not None:
            retire(self._prepared_queue.close)
            if self._inflight_prefix_owner is not None:
                retire(self._inflight_prefix_owner.close, wait=False)
            with self._prepared_attempt_lock:
                attempts = tuple(self._prepared_attempts)
            for attempt in attempts:
                retire(attempt.cancel)
            for attempt in attempts:
                retire(attempt.close)
            if self._inflight_prefix_owner is not None:
                retire(self._inflight_prefix_owner.close)
        for transport in offset_transports:
            retire(transport.abort)
        retire(self._provider_executor.shutdown, wait=True, cancel_futures=True)
        if self.decode_cache is not None:
            for response_id in tuple(self._decode_publications):
                retire(self._rollback_decode_response, response_id)
            retire(self.decode_cache.close)
        self._decode_publications.clear()
        self._decode_pending_responses.clear()
        self._decode_terminal_responses.clear()
        with self._transformer_state_lock:
            inventories: list[PreparedInventory] = []
            for state in self._transformer_states.values():
                retire(state.bundle.close)
                if state.prefill_cache is not None:
                    retire(state.prefill_cache.clear)
                if state.prepared_inventory is not None:
                    inventories.append(state.prepared_inventory)
                if state.prepared_inventory_spare is not None:
                    inventories.append(state.prepared_inventory_spare)
                inventories.extend(state.retired_inventories)
                state.prepared_inventory = None
                state.prepared_inventory_spare = None
                state.retired_inventories.clear()
            self._transformer_states.clear()
            self._model_manifests.clear()
        with self._transformer_conversation_lock:
            self._transformer_conversations.clear()
        self.cache.clear()
        self.histories.clear()
        self.message_histories.clear()
        self._pending_response_store.clear()
        for inventory in inventories:
            retire(self._cancel_prepared_inventory, inventory)
        if self._owns_preparation_http and self.preparation_http is not None:
            retire(self.preparation_http.close)
        if self._offset_workers:
            retire(self._offset_workers["worker_b"][0].close)
        if self._owns_http:
            retire(self.http.close)
        _raise_cleanup_errors(errors, primary)

    def list_models(self) -> dict[str, Any]:
        if self._local_engine is not None or self._offset_workers:
            model_id = self.default_model
            if model_id is None:
                raise ModelError("topology model is not configured")
            descriptor = self._model_manifest(model_id)
            return {
                "object": "list",
                "data": [
                    {
                        "id": model_id,
                        "object": "model",
                        "owned_by": (
                            "client" if self._local_engine is not None else "offset-workers"
                        ),
                        "runtime": descriptor["runtime"],
                        "context_length": descriptor["context_length"],
                    }
                ],
            }
        response = self.http.get("/v1/models", headers=self.headers)
        _raise(response)
        return response.json()

    def retrieve(self, response_id: str) -> Response:
        if response_id in self._ephemeral_response_ids:
            raise KeyError(response_id)
        if response_id in self.cache:
            response = self.cache[response_id]
            if not response.store:
                raise KeyError(response_id)
            return response
        if self._pending_response_store.get(response_id) is not True:
            raise KeyError(response_id)
        if getattr(self, "_local_engine", None) is not None or self._offset_workers:
            raise KeyError(response_id)
        response = self.http.get(f"/v1/responses/{response_id}", headers=self.headers)
        _raise(response)
        value = Response.from_dict(response.json())
        self.cache[response_id] = value
        self._pending_response_store.pop(response_id, None)
        return value

    def continuation_response(self, response_id: str) -> Response:
        if response_id not in self.cache:
            raise KeyError(response_id)
        return self.cache[response_id]

    def evict_response(self, response_id: str) -> None:
        self.cache.pop(response_id, None)
        self.histories.pop(response_id, None)
        self.message_histories.pop(response_id, None)
        with self._response_cache_lock:
            self._decode_pending_responses.discard(response_id)
            self._decode_terminal_responses.discard(response_id)
            try:
                self._response_cache_order.remove(response_id)
            except ValueError:
                pass
        with self._transformer_conversation_lock:
            self._transformer_conversations.pop(response_id, None)

    def _remember_response(self, response_id: str) -> None:
        response = self.cache.get(response_id)
        self._pending_response_store.pop(response_id, None)
        if response is None or response.store:
            return
        evicted: list[str] = []
        with self._response_cache_lock:
            self._response_cache_order.append(response_id)
            while len(self._response_cache_order) > self._response_cache_limit:
                evicted.append(self._response_cache_order.popleft())
        for stale_id in evicted:
            self.evict_response(stale_id)

    def _track_response(self, response_id: str, store: bool) -> None:
        if store:
            self._pending_response_store[response_id] = True
            return
        self._ephemeral_response_ids.add(response_id)
        self._ephemeral_response_order.append(response_id)
        while len(self._ephemeral_response_order) > self._response_cache_limit * 8:
            self._ephemeral_response_ids.discard(self._ephemeral_response_order.popleft())

    def _accept_decode_response(self, response_id: str) -> None:
        with self._response_cache_lock:
            self._decode_publications.pop(response_id, None)
            self._decode_pending_responses.discard(response_id)

    def _rollback_decode_response(self, response_id: str) -> None:
        publication = self._decode_publications.pop(response_id, None)
        if publication is not None and self.decode_cache is not None:
            prior, current = publication
            if self.decode_cache.head != current:
                raise ModelError("decode publication changed before response delivery")
            try:
                self.decode_cache._restore_head(prior)
            except BaseException as error:
                _cleanup_calls([self.decode_cache.close], primary=error)
                raise

    def _abort_decode_response(self, response_id: str, *, primary=None) -> None:
        _cleanup_calls([
            lambda: self._rollback_decode_response(response_id),
            lambda: self.evict_response(response_id),
            lambda: self._pending_response_store.pop(response_id, None),
        ], primary=primary)

    def cancel(self, response_id: str) -> Response:
        with self._response_cache_lock:
            # Linearize explicit cancel against terminal readiness, not physical
            # delivery. Once ready, return terminal status; never claim cancelled.
            if response_id in self._decode_terminal_responses:
                return self.cache[response_id]
            epoch_response = self._decode_epoch_responses.get(response_id)
            if epoch_response is not None:
                epoch_response[0].set()
        with self._prepared_attempt_lock:
            attempts = tuple(self._prepared_attempts)
        for attempt in attempts:
            if getattr(attempt, "response_id", None) == response_id:
                attempt.cancel()
                if not attempt.is_set():
                    # Surviving joiners still own this original prefill. Its
                    # producer stops before private decode, then retires the
                    # remote session. Do not cancel shared material mid-prefill.
                    return Response(id=response_id, model=attempt.model_id,
                                    output=[], status="cancelled")
        with self._activity_lock:
            boundary_transport = self._active_boundary_transports.get(response_id)
        if boundary_transport is not None:
            boundary_transport.abort()
        with self._response_cache_lock:
            epoch_response = self._decode_epoch_responses.get(response_id)
            if epoch_response is not None:
                epoch_response[0].set()
        if epoch_response is not None:
            if epoch_response[1]:
                canceled = self._control_post(self.http,
                    f"/v1/runtime/sessions/{epoch_response[1]}/cancel", headers=self.headers)
                # Completed epochs may already have been retired by the provider.
                if canceled.status_code not in {404, 410}:
                    _raise(canceled)
            self._pending_response_store.pop(response_id, None)
            return Response(id=response_id, model=epoch_response[2], output=[], status="cancelled")
        if self._local_engine is not None or self._offset_workers:
            response = self.cache.get(response_id)
            if response is None:
                raise KeyError(response_id)
            response.status = "cancelled"
            return response
        response = self.http.post(f"/v1/responses/{response_id}/cancel", headers=self.headers)
        _raise(response)
        self._pending_response_store.pop(response_id, None)
        if response_id in self.cache:
            self.cache[response_id].status = "cancelled"
            return self.cache[response_id]
        return Response.from_dict(response.json())

    def create(self, body: dict[str, Any]) -> Response | ResponseStream[ResponseEvent]:
        from .prepared_queue import prepared_cancellation
        synchronous = prepared_cancellation.get() is None
        if body.get("stream"):
            return ResponseStream(self.events(body), terminal=(self._accept_decode_response
                if synchronous and self.decode_cache is not None else None))
        final: Response | None = None
        response_id = None
        events = self.events(body)
        try:
            try:
                for event in events:
                    if event.type in {"response.completed", "response.incomplete"}:
                        response_id = event.response["id"]
                        final = Response.from_dict(event.response)
            finally:
                close = getattr(events, "close", None)
                if close is not None:
                    _cleanup_calls([close], primary=sys.exception())
            if final is None:
                raise ProtocolError("response stream ended without a terminal response")
            if synchronous and self.decode_cache is not None:
                self._accept_decode_response(final.id)
            return final
        except BaseException as error:
            if self.decode_cache is not None and response_id is not None:
                self._abort_decode_response(response_id, primary=error)
            raise

    def events(self, body: dict[str, Any]) -> Iterator[ResponseEvent]:
        if self._prepared_queue is not None:
            from .prepared_queue import OwnedPreparedAttempt

            return OwnedPreparedAttempt(self, body)
        return self._scoped_events(body)

    def _scoped_events(self, body: dict[str, Any]) -> Iterator[ResponseEvent]:
        with self.tokenizer_scope():
            yield from self._events(body)

    def _events(self, body: dict[str, Any]) -> Iterator[ResponseEvent]:
        requested_model = body.get("model")
        if self.experiment is not None:
            model_id = self.experiment.model
            if requested_model is not None and str(requested_model) != model_id:
                raise ValueError("request model conflicts with Experiment model")
            body["model"] = model_id
        else:
            model_id = str(body.get("model") or self.default_model or "")
        if not model_id:
            models = self.list_models().get("data", [])
            private = [
                item.get("id")
                for item in models
                if item.get("runtime", {}).get("privacy_mode")
                not in {"manifest_only", "trusted_backend"}
            ]
            private = [str(item) for item in private if item]
            if len(private) == 1:
                model_id = private[0]
            elif not private:
                raise ValueError("the server exposes no private model")
            else:
                raise ValueError(
                    "model is required when the server exposes more than one private model"
                )
        body = {**body, "model": model_id}
        from .http_gateway import validate_response_body

        body = validate_response_body(body)
        messages = normalize_input(body.get("input", ""))
        rendered = prompt_text(
            normalize_input(body.get("input", ""), instructions=body.get("instructions"))
        )
        stored_rendered = prompt_text(messages)
        previous_id = body.get("previous_response_id")
        if self._private_boundary and previous_id:
            raise ModelError("private boundary requires a fresh complete prompt per response")
        previous_history: str | None = None
        if previous_id:
            if str(previous_id) not in self.histories:
                raise ProtocolError("unknown previous_response_id in client-private cache", 404)
            previous_history = self.histories[str(previous_id)]
        descriptor = self._model_manifest(model_id, refresh=True)
        policy = tool_policy(body)
        if self.experiment is not None:
            self._transformer_state(model_id)
        if descriptor.get("metadata", {}).get("client_runtime") in {
            "masked_transformer_v1",
            "compiled_client_local_v1",
            "compiled_offset_v1",
            "direct_fhe_transformer_v1",
            "blinded_ole_transformer_v1",
            "guarded_blinded_transformer_v1",
        }:
            yield from self._transformer_events(
                body,
                messages,
                descriptor,
                previous_history=previous_history,
            )
            return
        if policy.enabled:
            raise ResponsesError(
                "tools are unsupported by this model runtime", code="unsupported_feature"
            )
        if previous_history is not None:
            rendered = previous_history + "\n" + rendered
            stored_rendered = previous_history + "\n" + stored_rendered
        # rendered remains local; only usage counts and opaque masked vectors cross the wire.
        session_value, model, correlations = self._open_private_session(
            model_id,
            max_output_tokens=int(body.get("max_output_tokens") or 64),
        )
        session_id = str(session_value["id"])
        response_id = str(session_value["response_id"])
        self._track_response(response_id, bool(body.get("store", True)))
        runtime = session_value["manifest"]["runtime"]
        channel = _Channel(
            self.http, self.base_url, self.api_key, session_id, self.session_transport
        )
        max_tokens = max(
            1,
            min(
                int(body.get("max_output_tokens") or 64),
                int(runtime.get("max_output_tokens", 4096)),
            ),
        )
        message_id = new_id("msg")
        seq = 0
        created = Response(
            id=response_id,
            model=model_id,
            output=[],
            status="in_progress",
            **_response_contract_fields(body, max_output_tokens=max_tokens),
        ).to_dict()
        output_ids: list[int] = []
        output_chunks: list[str] = []
        key = derive_session_key(self.api_key, session_id)
        current = model.tokenizer.bos_token_id
        try:
            yield ResponseEvent.from_dict(
                {"type": "response.created", "sequence_number": seq, "response": created}
            )
            seq += 1
            yield ResponseEvent.from_dict(
                {"type": "response.in_progress", "sequence_number": seq, "response": created}
            )
            seq += 1
            yield ResponseEvent.from_dict(
                {
                    "type": "response.output_item.added",
                    "sequence_number": seq,
                    "output_index": 0,
                    "item": {
                        "id": message_id,
                        "type": "message",
                        "status": "in_progress",
                        "role": "assistant",
                        "phase": "final_answer",
                        "content": [],
                    },
                }
            )
            seq += 1
            yield ResponseEvent.from_dict(
                {
                    "type": "response.content_part.added",
                    "sequence_number": seq,
                    "item_id": message_id,
                    "output_index": 0,
                    "content_index": 0,
                    "part": {"type": "output_text", "text": "", "annotations": [], "logprobs": []},
                }
            )
            seq += 1

            hit_token_limit = True
            for step in range(max_tokens):
                correlation = correlations.take()
                one_hot = np.zeros(model.tokenizer.vocab_size, dtype=np.int64)
                one_hot[current] = 1
                masked = centered_mod(one_hot + correlation.mask, model.modulus)
                request = MaskedLinearRequest(model.model_id, correlation.id, masked)
                envelope = ProtocolEnvelope.create(
                    request_id=f"{response_id}:{step}",
                    session_id=session_id,
                    model=model_id,
                    kind="masked.linear",
                    sequence=step,
                    payload=request.pack(),
                    metadata={},
                    key=key,
                )
                upload = pack_envelope(envelope)
                self.audit.masked_online_upload_bytes += len(upload)
                result_bytes = channel.exchange(upload)
                self.audit.masked_online_download_bytes += len(result_bytes)
                result = unpack_envelope(result_bytes)
                result.verify(key)
                if result.kind != "masked.linear.result" or result.sequence != step:
                    raise ModelError("mismatched runtime result frame")
                decoded = MaskedLinearResponse.unpack(result.payload)
                if decoded.correlation_id != correlation.id:
                    raise ModelError("correlation response mismatch")
                logits = centered_mod(
                    decoded.masked_output - correlation.transformed_mask, model.modulus
                ).astype(np.float64)
                temperature = _sampling_temperature(body)
                if temperature <= 0:
                    current = int(np.argmax(logits))
                else:
                    logits = logits / temperature
                    logits -= logits.max()
                    probabilities = np.exp(logits)
                    probabilities /= probabilities.sum()
                    current = int(
                        np.random.default_rng(42 + step).choice(len(probabilities), p=probabilities)
                    )
                self.audit.online_steps += 1
                if current == model.tokenizer.eos_token_id:
                    hit_token_limit = False
                    break
                output_ids.append(current)
                delta = model.tokenizer.decode([current])
                output_chunks.append(delta)
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.output_text.delta",
                        "sequence_number": seq,
                        "item_id": message_id,
                        "output_index": 0,
                        "content_index": 0,
                        "delta": delta,
                        "logprobs": [],
                    }
                )
                seq += 1

            text = "".join(output_chunks)
            content = {"type": "output_text", "text": text, "annotations": [], "logprobs": []}
            response_status = "incomplete" if hit_token_limit else "completed"
            item = {
                "id": message_id,
                "type": "message",
                "status": response_status,
                "role": "assistant",
                "phase": "final_answer",
                "content": [content],
            }
            yield ResponseEvent.from_dict(
                {
                    "type": "response.output_text.done",
                    "sequence_number": seq,
                    "item_id": message_id,
                    "output_index": 0,
                    "content_index": 0,
                    "text": text,
                    "logprobs": [],
                }
            )
            seq += 1
            yield ResponseEvent.from_dict(
                {
                    "type": "response.content_part.done",
                    "sequence_number": seq,
                    "item_id": message_id,
                    "output_index": 0,
                    "content_index": 0,
                    "part": content,
                }
            )
            seq += 1
            yield ResponseEvent.from_dict(
                {
                    "type": "response.output_item.done",
                    "sequence_number": seq,
                    "output_index": 0,
                    "item": item,
                }
            )
            seq += 1
            input_tokens = len(rendered.encode("utf-8"))
            usage = ResponseUsage(input_tokens, len(output_ids), input_tokens + len(output_ids))
            final = Response(
                id=response_id,
                model=model_id,
                output=[item],
                status=response_status,
                incomplete_details={"reason": "max_output_tokens"} if hit_token_limit else None,
                usage=usage,
                **_response_contract_fields(body, max_output_tokens=max_tokens),
            )
            self.cache[response_id] = final
            self.histories[response_id] = stored_rendered + "\nassistant: " + text
            self._remember_response(response_id)
            complete = self.http.post(
                f"/v1/runtime/sessions/{session_id}/complete",
                headers=self.headers,
                json={"usage": usage.to_dict()},
            )
            _raise(complete)
            yield ResponseEvent.from_dict(
                {
                    "type": f"response.{response_status}",
                    "sequence_number": seq,
                    "response": final.to_dict(),
                }
            )
        finally:
            channel.close()

    def _transformer_events(
        self, body: dict[str, Any], messages: list[Any], descriptor: dict[str, Any],
        *, previous_history: str | None = None,
    ) -> Iterator[ResponseEvent]:
        from contextlib import ExitStack

        with ExitStack() as cleanup:
            if self.decode_cache is not None:
                if not self._decode_cache_lock.acquire(blocking=False):
                    raise ModelError("one DecodeCache admits only one active response")
                cleanup.callback(self._decode_cache_lock.release)
                if self._decode_pending_responses:
                    raise ModelError("decode response delivery is still pending")
            yield from self._owned_transformer_events(body, messages, descriptor,
                previous_history=previous_history, cleanup=cleanup)

    def _owned_transformer_events(
        self,
        body: dict[str, Any],
        messages: list[Any],
        descriptor: dict[str, Any],
        *,
        previous_history: str | None = None,
        cleanup,
    ) -> Iterator[ResponseEvent]:
        from .prepared_queue import prepared_attempt

        attempt = prepared_attempt.get()
        if attempt is not None and attempt.client is not self:
            attempt = None
        model_id = str(body["model"])
        state = self._transformer_state(model_id)
        max_tokens = max(
            1,
            min(
                int(body.get("max_output_tokens") or 64),
                int(descriptor.get("context_length", 4096)),
            ),
        )
        temperature = _sampling_temperature(body)
        raw_top_p = body.get("top_p")
        top_p = None if raw_top_p is None else float(raw_top_p)
        prompt_messages = normalize_input(
            body.get("input", ""), instructions=body.get("instructions")
        )
        previous_id = body.get("previous_response_id")
        policy = tool_policy(body)
        structured: list[dict[str, Any]] = []
        if previous_id:
            structured.extend(self.message_histories.get(str(previous_id), []))
        render_messages = [*structured, *(row.to_prompt_dict() for row in prompt_messages)]
        structured.extend(row.to_prompt_dict() for row in messages)
        policy_instruction = policy.prompt_instruction()
        if policy_instruction:
            render_messages.insert(0, {"role": "system", "content": policy_instruction})
        rendered = self._render_cached_decoder_prompt(
            state,
            render_messages,
            add_generation_prompt=True,
            tools=policy.prompt_tools() if policy.enabled else None,
        )
        add_bos = bool(state.bundle.tokenizer_descriptor.get("add_bos_token", True))
        tokenizer = self._response_tokenizer(state.bundle)
        input_ids = tokenizer.encode(rendered, add_bos=add_bos)
        if not input_ids and state.bundle.config.get("bos_token_policy") == "nonempty_only":
            raise ModelError("model without a BOS token requires nonempty input")
        required_input_rows = len(input_ids or [int(state.bundle.config["bos_token_id"])])
        response_input_extent = required_input_rows
        if previous_id:
            with self._transformer_conversation_lock:
                candidate = self._transformer_conversations.get(str(previous_id))
            if (
                candidate is not None
                and candidate.model_id == model_id
                and candidate.bundle_fingerprint == state.bundle_fingerprint
                and rendered.startswith(candidate.rendered_context)
            ):
                required_input_rows = len(
                    tokenizer.encode(rendered[len(candidate.rendered_context) :], add_bos=False)
                ) + len(candidate.pending_token_ids)
                response_input_extent = candidate.snapshot.position + required_input_rows
        compiled = self._compiled_public_decoder(
            state,
            max_input_tokens=len(input_ids or [int(state.bundle.config["bos_token_id"])]),
            max_new_tokens=max_tokens,
        )
        full_prefill_ids = input_ids or [int(state.bundle.config["bos_token_id"])]
        prefill_candidate = self._prefill_cache_candidate(
            state,
            compiled,
            full_prefill_ids,
            store=bool(body.get("store", True)),
            previous_id=str(previous_id) if previous_id else None,
        )
        cached_prefill = None
        if prefill_candidate is not None:
            cache, cache_key = prefill_candidate
            cached_prefill = cache.get(
                cache_key,
                position=len(full_prefill_ids),
                layers=int(state.bundle.cfg["num_hidden_layers"]),
            )
            if cached_prefill is not None:
                required_input_rows = 0
            elif self.prefill_cache_mode == "prefix":
                assert compiled is not None
                cached_prefix = cache.longest_prefix(
                    compiled.digest,
                    state.bundle_fingerprint,
                    full_prefill_ids,
                    layers=int(state.bundle.cfg["num_hidden_layers"]),
                )
                if cached_prefix is not None and self._profitable_cached_prefix(
                    cached_prefix[0],
                    len(full_prefill_ids),
                    state,
                ):
                    required_input_rows -= cached_prefix[0]
                    cached_prefill = (cached_prefix[1], None)
        inflight_joined = False
        if self._inflight_prefix_owner is not None and prefill_candidate is not None:
            from .inflight_prefix import InflightBinding, InflightResources

            if attempt is None or compiled is None:
                raise ModelError("in-flight prefixes require a bounded compiled request owner")
            binding = InflightBinding.from_compiled(compiled)
            resources = InflightResources.from_compiled(compiled)

            def admit_prefix(prefix, suffix):
                if len(full_prefill_ids) + max_tokens - 1 > resources.capacity_tokens:
                    raise ModelError("in-flight request exceeds compiled state capacity")
                if suffix:
                    self._decoder_continuation(compiled).admit(prefix, suffix)

            request = self._inflight_prefix_owner.lookup_or_register(self, binding,
                full_prefill_ids, resources, admit=admit_prefix,
                completed_cache_hit=cached_prefill is not None)
            attempt.bind_prefix(request)
            if request is not None and not request.is_producer:
                lease = request.wait()
                cached_prefill = (lease.snapshot,
                    lease.logits if lease.prefix_tokens == len(full_prefill_ids) else None)
                required_input_rows = len(full_prefill_ids) - lease.prefix_tokens
                inflight_joined = True
        client_owned = self._local_engine is not None
        offset_execution = bool(self._offset_workers)
        if (client_owned or offset_execution) and compiled is None:
            raise ModelError("selected topology requires complete compiled execution")
        epochs_enabled = self._decode_epochs_enabled()
        decode_reuse = (self.decode_cache is not None and bool(body.get("store", True))
                        and not previous_id)
        if decode_reuse and (not epochs_enabled or self.preparation_decode_epoch_tokens != 1):
            raise ModelError("decode reuse requires one-selection epochs")
        if decode_reuse and max_tokens > self.decode_cache._limits["max_staged"]:
            raise ModelError("decode response exceeds the cache's bounded staging capacity")
        epoch_index = 0
        epoch_allowance = self._decode_epoch_allowance(epoch_index, max_tokens)
        epoch_boundary = epoch_allowance
        if epochs_enabled:
            if (compiled is None or state.privacy_mode != "public"
                    or state.bundle.privacy.get("verification_component", "none") != "none"):
                raise ModelError("decode epochs require a compiled public unverified decoder")
            # Native continuation validates source, composition, arithmetic and
            # exclusive full-KV state before any new material can be published.
            epoch_contract = self._decoder_continuation(compiled)
            bound = epoch_contract.to_dict()["token_bound"]
            initial_extent = response_input_extent
            if initial_extent + max_tokens - 1 > bound:
                raise ModelError("decode epoch response exceeds fixed continuation token bound")
            if max_tokens > 1:
                epoch_contract.admit(initial_extent, max_tokens - 1)
        # Joining precedes this queue. One response owns all online work and
        # idle epoch pauses, so another request cannot prepare during execution.
        if attempt is not None:
            attempt.enter()
        required_rows = max(1, required_input_rows + max(0, epoch_allowance - 1))
        if state.privacy_mode == "public":
            demand = None
            if self.preparation_allocation == "demand":
                if compiled is None:
                    raise ModelError("demand preparation requires a complete compiled schedule")
                demand = compiled.prepared_stage_rows(required_input_rows, max(0, epoch_allowance - 1),
                    continuation=bool(previous_id) or required_input_rows != len(full_prefill_ids))
            if not epochs_enabled:
                phases = (compiled.prepared_stage_phase_rows(required_input_rows, max(0, epoch_allowance - 1),
                    continuation=bool(previous_id) or required_input_rows != len(full_prefill_ids))
                    if demand is not None and self._inflight_prefix_owner is None
                    and not self.background_inventory_refill else None)
                self._ensure_prepared_inventory(model_id, state, required_rows, demand, phases)
        offset_transport = None
        if offset_execution:
            assert compiled is not None
            from .offset_reference import TwoOnlineOffsetTransport

            worker_a, key_a = self._offset_workers["worker_a"]
            worker_b, key_b = self._offset_workers["worker_b"]
            offset_transport = TwoOnlineOffsetTransport(
                compiled,
                model_id=model_id,
                worker_a=worker_a,
                worker_b=worker_b,
                api_key_a=key_a,
                api_key_b=key_b,
                continuation=(self._decoder_continuation(compiled)
                              if self.prefill_cache_mode == "prefix" else None),
            )
            session_value = {"id": new_id("offset_session"), "response_id": new_id("resp")}
            if offset_transport.continuation is not None:
                session_value["decoder_continuation"] = offset_transport.continuation
            provider = None
            with self._activity_lock:
                already_closing = self._closing
                if not already_closing:
                    self._active_offset_transports[session_value["id"]] = offset_transport
            if already_closing:
                offset_transport.abort()
                raise ProtocolError("client closed while opening worker sessions", 409)
        elif client_owned:
            session_value = {"id": new_id("client_session"), "response_id": new_id("resp")}
            provider = None
        elif decode_reuse:
            # Source and full-response admission are already complete. No row is
            # issued until the exact root/next-child lookup below misses.
            session_value = {"id": "", "response_id": new_id("resp")}
            provider = None
        elif epochs_enabled:
            session_value, state, provider = self._open_decode_epoch(model_id, state,
                required_rows, demand, max_output_tokens=max_tokens, compiled=compiled,
                initial=True, cancelled=attempt.check_cancelled if attempt is not None else lambda: None)
        else:
            session_value, state, provider = self._open_transformer_session(
                model_id,
                max_output_tokens=(self._experiment_budget.max_new_tokens
                                   if self._private_boundary else max_tokens),
                required_rows=required_rows,
                compiled=compiled,
                semantic_input_tokens=(
                    self._experiment_budget.max_input_tokens if self._private_boundary else
                    self.prefill_cache_bound_tokens
                    if compiled is not None and self.prefill_cache_mode == "prefix"
                    else len(input_ids or [int(state.bundle.config["bos_token_id"])])
                ),
            )
        session_id = str(session_value["id"])
        response_id = str(session_value["response_id"])
        if attempt is not None:
            attempt.response_id = response_id
            attempt.model_id = model_id
        self._track_response(response_id, bool(body.get("store", True)))
        channel: _Channel | None = None
        boundary_transport = None
        boundary_retired = False
        runtime = None
        initializing = True
        abandoned = False
        session_completed = False

        def evict_failed_turn(exc_type, error, traceback):
            if not session_completed or (exc_type is not None and exc_type is not GeneratorExit):
                _cleanup_calls([
                    lambda: self.evict_response(response_id),
                    lambda: self._pending_response_store.pop(response_id, None),
                ], primary=error)
            return False

        cleanup.push(evict_failed_turn)

        def retire_boundary() -> None:
            nonlocal boundary_retired
            if boundary_transport is None or boundary_retired:
                return
            boundary_retired = True
            with self._activity_lock:
                self._active_boundary_transports.pop(response_id, None)
            try:
                boundary_transport.close()
            finally:
                for role, values in boundary_transport.role_link_bodies.items():
                    tracked = self.audit.role_link_bodies.setdefault(role, {})
                    for metric, count in values.items():
                        tracked[metric] = tracked.get(metric, 0) + count
                for operation, values in boundary_transport.operation_counters.items():
                    for direction in ("upload", "download"):
                        name = f"private_boundary_{operation}_{direction}_bytes"
                        setattr(self.audit, name, getattr(self.audit, name) + values[f"{direction}_bytes"])
                self.audit.private_boundary_lookup_rows += boundary_transport.operation_counters["lookup"]["rows"]
                self.audit.private_boundary_head_calls += boundary_transport.operation_counters["head"]["rows"]
                self.audit.private_boundary_body_coverage_failures += int(not boundary_transport.body_coverage_complete)

        cleanup.callback(retire_boundary)

        def abandon_transformer_session() -> None:
            nonlocal abandoned
            if abandoned:
                return
            abandoned = True
            calls = []
            if channel is not None:
                calls.append(channel.close)
            if not (client_owned or offset_execution or decode_reuse):
                calls.append(lambda: self._cancel_transformer_session(session_id))
            if isinstance(provider, PreparedInventoryLease):
                calls.append(lambda: self._finish_prepared_response(model_id, state, provider))
            if runtime is not None:
                calls.append(runtime.reset)
            calls.append(lambda: self._pending_response_store.pop(response_id, None))
            if epochs_enabled:
                def cancel_inventory():
                    with self._transformer_state_lock:
                        if state.prepared_inventory is not None:
                            self._cancel_prepared_inventory(state.prepared_inventory)
                            state.prepared_inventory = None
                calls.append(cancel_inventory)
            elif offset_transport is not None:
                calls.append(offset_transport.abort)
            _cleanup_calls(calls, primary=sys.exception())

        cleanup.callback(lambda: abandon_transformer_session() if initializing else None)

        if not (client_owned or offset_execution or decode_reuse):
            try:
                channel = _Channel(
                    self.http, self.base_url, self.api_key, session_id,
                    "websocket" if self.prefill_chunk_rows else self.session_transport,
                    frame_limit=(16 << 20) if self.prefill_chunk_rows else None,
                    # Prepared words already use the negotiated arithmetic codec.
                    compression=None if state.privacy_mode == "public" else "deflate",
                )
            except BaseException:
                abandon_transformer_session()
                raise
        key = (
            derive_session_key(self.api_key, session_id)
            if not (client_owned or offset_execution or decode_reuse)
            else b""
        )
        sequence = 0

        def exchange(stage_id: str, payloads: list[bytes]) -> list[bytes]:
            nonlocal sequence
            if attempt is not None:
                attempt.check_cancelled()
            if client_owned or offset_execution:
                raise ModelError("topology linear stage cannot use a legacy provider channel")
            assert channel is not None
            self.audit.inference_stage_calls += 1
            compact_rows = prepared_stage_batch_rows(payloads[0]) if len(payloads) == 1 else None
            if self.prefill_chunk_rows and (len(payloads) > 1 or compact_rows is not None):
                if state.privacy_mode != "public":
                    raise ModelError("duplex prefill requires the admitted public prepared contract")
                first = sequence
                uploads = [pack_envelope(ProtocolEnvelope.create(
                    request_id=f"{response_id}:{first + index}", session_id=session_id, model=model_id,
                    kind="masked.transformer.stage", sequence=first + index, payload=payload,
                    metadata={"stage_id": stage_id}, key=key)) for index, payload in enumerate(payloads)]
                sequence += len(uploads)
                self.audit.masked_online_upload_bytes += sum(map(len, uploads))
                replies = channel.exchange_many(uploads)
                self.audit.masked_online_download_bytes += sum(map(len, replies))
                results = []
                for index, raw in enumerate(replies):
                    result = unpack_envelope(raw)
                    result.verify(key)
                    if (result.kind != "masked.transformer.stage.result" or result.session_id != session_id
                            or result.model != model_id or result.sequence != first + index
                            or result.request_id != f"{response_id}:{first + index}"):
                        raise ModelError("duplex reply differs from its ordered session frame")
                    results.append(result.payload)
                self.audit.online_steps += sum(prepared_stage_batch_rows(payload) or 1 for payload in payloads)
                return results
            if len(payloads) > 1 or (compact_rows is not None and compact_rows > 1):
                upload = encode_length_prefixed(payloads)
                if state.privacy_protocol != "direct_bfv_w4a4":
                    self.audit.masked_online_upload_bytes += len(upload)
                with owned_response(self.http.post(
                    f"/v1/runtime/sessions/{session_id}/stages/{stage_id}",
                    headers={**self.headers, "Content-Type": "application/octet-stream"},
                    content=upload,
                )) as response:
                    _raise(response)
                    if state.privacy_protocol != "direct_bfv_w4a4":
                        self.audit.masked_online_download_bytes += len(response.content)
                    results = list(iter_length_prefixed(response.content))
                self.audit.online_steps += compact_rows or len(payloads)
                return results
            envelope = ProtocolEnvelope.create(
                request_id=f"{response_id}:{sequence}",
                session_id=session_id,
                model=model_id,
                kind="masked.transformer.stage",
                sequence=sequence,
                payload=payloads[0],
                metadata={"stage_id": stage_id},
                key=key,
            )
            sequence += 1
            upload = pack_envelope(envelope)
            if state.privacy_protocol != "direct_bfv_w4a4":
                self.audit.masked_online_upload_bytes += len(upload)
            raw = channel.exchange(upload)
            if state.privacy_protocol != "direct_bfv_w4a4":
                self.audit.masked_online_download_bytes += len(raw)
            result = unpack_envelope(raw)
            result.verify(key)
            if result.kind != "masked.transformer.stage.result":
                raise ModelError("unexpected transformer stage result")
            self.audit.online_steps += 1
            return [result.payload]

        if offset_execution:
            assert offset_transport is not None
            remote = offset_transport
        elif client_owned:
            assert compiled is not None and self._local_engine is not None
            remote = compiled.client_linear_executor(self._local_engine)
        elif decode_reuse:
            remote = None
        elif state.privacy_mode == "public":
            if not isinstance(provider, PreparedInventoryLease):
                abandon_transformer_session()
                raise ModelError("public mode requires a prepared inventory lease")
            remote = PreparedRemoteLinear(
                model_id=model_id,
                body_fingerprint=str(state.bundle.privacy["body_fingerprint"]),
                stages=state.bundle.stages,
                inference=exchange,
                inventory=provider,
                prefill_chunk_rows=self.prefill_chunk_rows,
                request_encoding=self.prepared_request_encoding,
                verification_component=str(
                    state.bundle.privacy.get("verification_component", "none")
                ),
            )
        elif state.privacy_protocol == "direct_bfv_w4a4":
            remote = _DirectFHERemoteLinear(
                stages=state.bundle.stages,
                owner=self,
                session_id=session_id,
                state=state,
                exchange=exchange,
            )
        elif state.privacy_protocol in {"blinded_ole_w4a4", "guarded_blinded_w4a4"}:
            if not isinstance(provider, _BlindedCorrelationProvider):
                raise ModelError("blinded proprietary mode requires its correlation provider")
            remote = _BlindedRemoteLinear(
                stages=state.bundle.stages,
                correlations=provider,
                session_id=session_id,
                state=state,
                exchange=exchange,
            )
        else:
            if provider is None:
                raise ModelError("public mode requires a correlation provider")
            remote = RemoteLinear(state.bundle.stages, provider, exchange)
        def admitted_remote(stage, values):
            if remote is None:
                raise ModelError("decode execution has no freshly admitted material")
            return remote(stage, values)

        try:
            if self._private_boundary:
                from pllm.configuration import Pipeline
                from .private_boundary_transport import PrivateBoundaryTransport

                if compiled is None or self._boundary_connections is None:
                    raise ModelError("private boundary requires complete compiled execution")
                (url_a, key_a), (url_b, key_b) = self._boundary_connections
                boundary_transport = PrivateBoundaryTransport(
                    worker_a=url_a, worker_b=url_b, api_key_a=key_a, api_key_b=key_b,
                    descriptor=compiled.private_boundary_descriptor(),
                    head_certificate=Pipeline.from_spec(json.loads(compiled._canonical_composition)).components["boundary"].params.get("head_certificate"),
                    head_scales=state.bundle.stages["lm_head"].weight_scales,
                    timeout=self._boundary_timeout,
                )
                with self._activity_lock:
                    if self._closing:
                        raise ProtocolError("client closed while opening boundary sessions", 409)
                    self._active_boundary_transports[response_id] = boundary_transport
                boundary_transport.open(compiled.private_boundary_admission(
                    len(full_prefill_ids), max_tokens - 1))
            runtime = (
                compiled.runtime(
                    admitted_remote if decode_reuse else remote,
                    token_cache=None if self._private_boundary else state.token_cache,
                    token_cache_size=self.token_cache_size,
                    token_cache_lock=state.token_cache_lock,
                    **({"private_boundary": boundary_transport} if self._private_boundary else {}),
                )
                if compiled is not None
                else MaskedTransformerClientRuntime(
                    state.bundle,
                    remote,
                    token_cache=state.token_cache,
                    token_cache_size=self.token_cache_size,
                    token_cache_lock=state.token_cache_lock,
                )
            )
        except BaseException:
            abandon_transformer_session()
            raise
        message_id = new_id("msg")
        event_sequence = 0
        output_ids: list[int] = []
        output_chunks: list[str] = []
        previous_text = ""
        session_completed = False
        first_output_online_bytes: int | None = None
        epoch_session_active = not decode_reuse
        decode_tickets = []
        decode_remote_used = False
        if decode_reuse:
            self.decode_cache.bind(compiled, runtime)
            self._decode_pending_responses.add(response_id)

            def retire_decode_turn(exc_type, error, traceback):
                errors = []
                try:
                    self.decode_cache.discard()
                except BaseException as failure:
                    errors.append(failure)
                if (not session_completed or exc_type is not None or errors) and response_id in self._decode_pending_responses:
                    try:
                        self._abort_decode_response(response_id)
                    except BaseException as failure:
                        errors.append(failure)
                _raise_cleanup_errors(errors, error)
                return False

            cleanup.push(retire_decode_turn)
            root_hit = self.decode_cache.lookup(full_prefill_ids)
            if root_hit is not None:
                cached_prefill = (root_hit.snapshot, root_hit.logits)
                self.audit.decode_cache_root_hits += 1
            required_input_rows = (len(full_prefill_ids) if cached_prefill is None else
                len(full_prefill_ids) - cached_prefill[0].position if cached_prefill[1] is None else 0)
        epoch_cancelled = threading.Event()
        if epochs_enabled:
            with self._response_cache_lock:
                self._decode_epoch_responses[response_id] = (
                    epoch_cancelled, session_id if epoch_session_active else "", model_id)

        def retire_decode_material(emitted: int):
            nonlocal epoch_session_active, channel
            if not epoch_session_active:
                return
            complete = self._control_post(self.http,
                f"/v1/runtime/sessions/{session_id}/complete", headers=self.headers,
                json={"usage": ResponseUsage(len(full_prefill_ids), emitted,
                                             len(full_prefill_ids) + emitted).to_dict()})
            _raise(complete)
            if channel is not None:
                channel.close()
                channel = None
            self._finish_prepared_response(model_id, state, remote.inventory)
            epoch_session_active = False
            with self._response_cache_lock:
                self._decode_epoch_responses[response_id] = (epoch_cancelled, "", model_id)

        def admit_decode_material(rows: int, *, continuation: bool, initial: bool = False):
            nonlocal session_id, session_value, provider, channel, key, sequence, remote
            nonlocal epoch_session_active, decode_remote_used
            if epoch_session_active:
                raise ModelError("decode miss cannot prepare during an active session")
            check_epoch_cancelled()
            session_value, _, provider = self._open_decode_epoch(model_id, state, max(1, rows),
                compiled.prepared_stage_rows(rows, 0, continuation=continuation),
                max_output_tokens=max_tokens, compiled=compiled, cancelled=check_epoch_cancelled,
                initial=initial)
            session_id = str(session_value["id"])
            epoch_session_active = True
            decode_remote_used = True
            try:
                if remote is None:
                    remote = PreparedRemoteLinear(model_id=model_id,
                        body_fingerprint=str(state.bundle.privacy["body_fingerprint"]),
                        stages=state.bundle.stages, inference=exchange, inventory=provider,
                        prefill_chunk_rows=self.prefill_chunk_rows,
                        request_encoding=self.prepared_request_encoding,
                        verification_component="none")
                else:
                    remote.inventory = provider
                with self._response_cache_lock:
                    self._decode_epoch_responses[response_id] = (epoch_cancelled, session_id, model_id)
                check_epoch_cancelled()
                key = derive_session_key(self.api_key, session_id)
                sequence = 0
                channel = _Channel(self.http, self.base_url, self.api_key, session_id,
                    "websocket" if self.prefill_chunk_rows else self.session_transport,
                    frame_limit=(16 << 20) if self.prefill_chunk_rows else None, compression=None)
                runtime.install_continuation(self._admitted_decoder_continuation(session_value, compiled))
            except BaseException as error:
                calls = [lambda: self._cancel_transformer_session(session_id),
                         lambda: self._finish_prepared_response(model_id, state, provider)]
                if channel is not None:
                    calls.insert(0, channel.close)
                _cleanup_calls(calls, primary=error)
                channel = None
                epoch_session_active = False
                with self._response_cache_lock:
                    self._decode_epoch_responses[response_id] = (epoch_cancelled, "", model_id)
                raise

        def stage_decode_state(executed_ids, logits):
            snapshot = (runtime.canonical_generated_snapshot()
                        if runtime._snapshot_basis.phase == "incremental" else runtime.snapshot())
            ticket = self.decode_cache.stage(executed_ids, snapshot, np.asarray(logits))
            if ticket is not None:
                decode_tickets.append(ticket)

        def next_decode_state(token: int, emitted: int):
            parent_ids = [*input_ids, *output_ids[:-1]]
            retire_decode_material(emitted)
            check_epoch_cancelled()
            hit = self.decode_cache.lookup_child(parent_ids, token)
            if hit is not None:
                runtime.restore(hit.snapshot)
                self.audit.decode_cache_branch_hits += 1
                self.audit.decode_cache_skipped_decode_steps += 1
                self.audit.decode_cache_skipped_remote_rows += sum(
                    compiled.prepared_stage_rows(1, 0, continuation=True).values())
                return hit.logits, runtime.caches
            self.audit.decode_cache_misses += 1
            started = time.perf_counter_ns()
            self.audit.decode_epoch_pauses += 1
            try:
                admit_decode_material(1, continuation=True)
                next_logits = runtime.continue_ids([token])[-1]
                self.audit.generation_remote_decode_steps += 1
                stage_decode_state([*parent_ids, token], next_logits)
                return next_logits, runtime.caches
            finally:
                self.audit.decode_epoch_pause_ns += time.perf_counter_ns() - started

        def check_epoch_cancelled():
            if attempt is not None:
                attempt.check_cancelled()
            if epochs_enabled and (epoch_cancelled.is_set() or self._closing):
                raise ProtocolError("decode epoch response cancelled", 409)

        def rotate_decode_epoch(token: int, emitted: int):
            nonlocal session_id, session_value, provider, channel, key, sequence, epoch_session_active
            nonlocal epoch_index, epoch_boundary
            assert compiled is not None and isinstance(remote, PreparedRemoteLinear)
            check_epoch_cancelled()
            # Complete the old authenticated execution, drain its transport, burn
            # its lease, and only then publish fresh masks/corrections while idle.
            complete = self._control_post(self.http,
                f"/v1/runtime/sessions/{session_id}/complete", headers=self.headers,
                json={"usage": ResponseUsage(len(input_ids), emitted, len(input_ids) + emitted).to_dict()})
            _raise(complete)
            if channel is not None:
                channel.close()
                channel = None
            self._finish_prepared_response(model_id, state, remote.inventory)
            epoch_session_active = False
            with self._response_cache_lock:
                self._decode_epoch_responses[response_id] = (epoch_cancelled, "", model_id)
            snapshot = runtime.snapshot_for_response(response_id)
            epoch_index += 1
            allowance = self._decode_epoch_allowance(epoch_index, max_tokens - emitted)
            epoch_boundary = emitted + allowance
            epoch_contract.admit(runtime.position, allowance)
            session_value, _, provider = self._open_decode_epoch(model_id, state, allowance,
                compiled.prepared_stage_rows(1, allowance - 1, continuation=True),
                max_output_tokens=max_tokens, compiled=compiled, cancelled=check_epoch_cancelled)
            session_id = str(session_value["id"])
            epoch_session_active = True
            remote.inventory = provider
            with self._response_cache_lock:
                self._decode_epoch_responses[response_id] = (epoch_cancelled, session_id, model_id)
            check_epoch_cancelled()
            key = derive_session_key(self.api_key, session_id)
            sequence = 0  # Provider nonce scope is fresh; application events are not.
            channel = _Channel(self.http, self.base_url, self.api_key, session_id,
                "websocket" if self.prefill_chunk_rows else self.session_transport,
                frame_limit=(16 << 20) if self.prefill_chunk_rows else None, compression=None)
            runtime.install_continuation(self._admitted_decoder_continuation(session_value, compiled))
            runtime.restore_for_response(snapshot, response_id)
            resumed_logits = runtime.continue_ids([token])[-1]
            return resumed_logits, runtime.caches

        def resume_decode_epoch(token: int, emitted: int):
            check_epoch_cancelled()
            started = time.perf_counter_ns()
            self.audit.decode_epoch_pauses += 1
            try:
                return rotate_decode_epoch(token, emitted)
            finally:
                # Include completion/drain, fresh admission and pending-token
                # execution; failed/cancelled pauses are charged too.
                self.audit.decode_epoch_pause_ns += time.perf_counter_ns() - started

        def response_online_bytes() -> int | None:
            # Per-response transport counters are authoritative before the audit
            # is merged at close. Sampling the cumulative public audit here
            # would incorrectly classify prefill as decode.
            if isinstance(remote, PreparedRemoteLinear):
                boundary_bytes = (sum(
                    values.get("online_upload_bytes", 0) + values.get("online_download_bytes", 0)
                    for values in boundary_transport.role_link_bodies.values()
                ) if boundary_transport is not None else 0)
                return (remote.stats.inference_upload_bytes + remote.stats.inference_download_bytes
                        + boundary_bytes)
            if offset_transport is not None:
                return sum(
                    values.get("online_upload_bytes", 0) + values.get("online_download_bytes", 0)
                    for values in offset_transport.http_body_costs.values()
                )
            return 0 if client_owned or decode_reuse else None

        created = Response(
            id=response_id,
            model=model_id,
            output=[],
            status="in_progress",
            **_response_contract_fields(body, max_output_tokens=max_tokens),
        ).to_dict()
        initializing = False
        try:
            if epochs_enabled:
                runtime.install_continuation(epoch_contract if decode_reuse else
                    self._admitted_decoder_continuation(session_value, compiled))
            yield ResponseEvent.from_dict(
                {"type": "response.created", "sequence_number": event_sequence, "response": created}
            )
            event_sequence += 1
            yield ResponseEvent.from_dict(
                {
                    "type": "response.in_progress",
                    "sequence_number": event_sequence,
                    "response": created,
                }
            )
            event_sequence += 1
            if not policy.enabled:
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.output_item.added",
                        "sequence_number": event_sequence,
                        "output_index": 0,
                        "item": {
                            "id": message_id,
                            "type": "message",
                            "status": "in_progress",
                            "role": "assistant",
                            "phase": "final_answer",
                            "content": [],
                        },
                    }
                )
                event_sequence += 1
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.content_part.added",
                        "sequence_number": event_sequence,
                        "item_id": message_id,
                        "output_index": 0,
                        "content_index": 0,
                        "part": {
                            "type": "output_text",
                            "text": "",
                            "annotations": [],
                            "logprobs": [],
                        },
                    }
                )
                event_sequence += 1

            check_epoch_cancelled()
            continuation_used = False
            if decode_reuse and required_input_rows:
                admit_decode_material(required_input_rows,
                    continuation=cached_prefill is not None, initial=True)
            self.audit.generation_requested_prefill_tokens += len(full_prefill_ids)
            if not client_owned:
                self.audit.generation_remote_prefill_tokens += required_input_rows
                self.audit.generation_remote_terminal_prefill_rows += (
                    required_input_rows if cached_prefill is not None else min(required_input_rows, 1))
            if decode_reuse and not required_input_rows:
                self.audit.decode_cache_skipped_prefill_tokens += len(full_prefill_ids)
                self.audit.decode_cache_skipped_remote_rows += sum(
                    compiled.prepared_stage_rows(len(full_prefill_ids), 0).values())
            prior: _TransformerConversationState | None = None
            if previous_id:
                with self._transformer_conversation_lock:
                    candidate = self._transformer_conversations.get(str(previous_id))
                    if (
                        candidate is not None
                        and candidate.model_id == model_id
                        and candidate.bundle_fingerprint == state.bundle_fingerprint
                    ):
                        prior = candidate

            suffix: list[int] | None = None
            if prior is not None and rendered.startswith(prior.rendered_context):
                # Preserve the exact previously sampled token IDs. Re-encoding
                # decoded assistant text is not guaranteed to round-trip for
                # byte fallback tokens, normalising tokenizers or special tokens.
                suffix_text = rendered[len(prior.rendered_context) :]
                suffix = tokenizer.encode(suffix_text, add_bos=False)
                full_input_ids = [*prior.token_ids, *suffix]
            else:
                # Admission and inventory sizing already encoded this exact
                # rendered request. Reuse it instead of loading a second
                # decoder-owned vocabulary and tokenizing the prompt again.
                full_input_ids = list(full_prefill_ids)
                if (
                    prior is not None
                    and len(full_input_ids) >= len(prior.token_ids)
                    and full_input_ids[: len(prior.token_ids)] == prior.token_ids
                ):
                    suffix = full_input_ids[len(prior.token_ids) :]

            if prior is not None and suffix is not None:
                pending_input_ids = [*prior.pending_token_ids, *suffix]
                if prior.snapshot.position != len(prior.token_ids) - len(prior.pending_token_ids):
                    raise ModelError("prior response state differs from its evaluated tokens")
                if self.prefill_cache_mode == "prefix":
                    if compiled is None:
                        raise ModelError("prefix conversation requires native continuation")
                    contract = self._admitted_decoder_continuation(session_value, compiled)
                    if pending_input_ids:
                        contract.admit(prior.snapshot.position, len(pending_input_ids))
                    elif prior.snapshot.position > contract.to_dict()["token_bound"]:
                        raise ModelError("prior response exceeds fixed continuation token bound")
                    runtime.install_continuation(contract)
                runtime.restore_for_response(prior.snapshot, previous_id)
                continuation_used = True
                logits = (
                    (runtime.continue_ids(pending_input_ids)[-1]
                     if self.prefill_cache_mode == "prefix"
                     else runtime.forward_ids(pending_input_ids)[-1])
                    if pending_input_ids
                    else prior.next_logits.copy()
                )
                input_ids = full_input_ids
                caches = runtime.caches
            elif cached_prefill is not None:
                if full_input_ids != full_prefill_ids:
                    raise ModelError("cached prefill differs from the bound token cohort")
                snapshot, saved_logits = cached_prefill
                runtime.restore(snapshot)
                if (
                    runtime.position < 1
                    or runtime.position > len(full_input_ids)
                    or len(runtime.caches) != runtime.layers
                ):
                    raise ModelError("cached prefill state differs from the bound decoder")
                input_ids = full_input_ids
                if saved_logits is None:
                    # The cached state is a proper prefix: consume only the
                    # suffix on freshly reserved one-use rows. Never reuse
                    # another response's masked correction or token selection.
                    assert runtime.position < len(full_input_ids)
                    reused = runtime.position
                    assert compiled is not None
                    runtime.install_continuation(
                        self._admitted_decoder_continuation(session_value, compiled)
                    )
                    logits = runtime.continue_ids(full_input_ids[reused:])[-1]
                    if not inflight_joined:
                        self.audit.prefill_prefix_tokens_reused += reused
                else:
                    if runtime.position != len(full_input_ids):
                        raise ModelError("cached logits do not match prefill state")
                    logits = saved_logits
                caches = runtime.caches
                if inflight_joined:
                    self.audit.inflight_prefill_tokens_reused += snapshot.position
                else:
                    self.audit.prefill_cache_hits += 1
            else:
                input_ids, logits, caches = runtime.prepare_ids(full_input_ids)
                if attempt is not None and attempt.prefix is not None and attempt.prefix.is_producer:
                    from .inflight_prefix import _erase

                    snapshot = runtime.snapshot()
                    shared_logits = np.array(logits, dtype=np.float32, copy=True)
                    try:
                        attempt.prefix.publish(snapshot, shared_logits,
                            validate_snapshot=runtime._validate_full_snapshot)
                        attempt.published = True
                    finally:
                        _erase(snapshot, shared_logits)
                    check_epoch_cancelled()
                if prefill_candidate is not None:
                    self.audit.prefill_cache_misses += 1
                    cache, cache_key = prefill_candidate
                    if self.prefill_cache_mode == "prefix":
                        assert compiled is not None
                        cache.put_prefixes(
                            compiled.digest,
                            state.bundle_fingerprint,
                            full_prefill_ids,
                            runtime.snapshot(),
                        )
                    cache.put(cache_key, runtime.snapshot(), np.asarray(logits))
            if (
                cached_prefill is not None
                and cached_prefill[1] is None
                and prefill_candidate is not None
            ):
                assert compiled is not None
                cache, cache_key = prefill_candidate
                cache.put_prefixes(
                    compiled.digest,
                    state.bundle_fingerprint,
                    full_prefill_ids,
                    runtime.snapshot(),
                )
                cache.put(cache_key, runtime.snapshot(), np.asarray(logits))
            pending_token_ids: list[int] = []
            if decode_reuse and root_hit is None:
                stage_decode_state(input_ids, logits)
            executed_decode_steps = 0
            hit_token_limit = True
            for step in range(max_tokens):
                check_epoch_cancelled()
                token = runtime.sample(logits, temperature=temperature, top_p=top_p)
                if token == int(runtime.cfg["eos_token_id"]):
                    hit_token_limit = False
                    break
                if step == 0:
                    first_output_online_bytes = response_online_bytes()
                output_ids.append(token)
                text_so_far = tokenizer.decode(output_ids)
                delta = (
                    text_so_far[len(previous_text) :]
                    if text_so_far.startswith(previous_text)
                    else text_so_far
                )
                previous_text = text_so_far
                output_chunks.append(delta)
                if not policy.enabled:
                    yield ResponseEvent.from_dict(
                        {
                            "type": "response.output_text.delta",
                            "sequence_number": event_sequence,
                            "item_id": message_id,
                            "output_index": 0,
                            "content_index": 0,
                            "delta": delta,
                            "logprobs": [],
                        }
                    )
                    event_sequence += 1
                # A paused stream can be cancelled after delivering this token.
                # Check before its private feedback lookup or any decode work.
                check_epoch_cancelled()
                if step + 1 >= max_tokens:
                    pending_token_ids = [token]
                    break
                if decode_reuse:
                    logits, caches = next_decode_state(token, step + 1)
                elif epochs_enabled and step + 1 == epoch_boundary:
                    logits, caches = resume_decode_epoch(token, step + 1)
                else:
                    logits, caches = runtime.decode_step(token, caches, len(input_ids) + step)
                if not (decode_reuse or client_owned):
                    self.audit.generation_remote_decode_steps += 1
                executed_decode_steps += 1

            self.audit.token_lookup_cache_hits += runtime.token_cache_hits
            self.audit.token_lookup_cache_misses += runtime.token_cache_misses
            if previous_id:
                if continuation_used:
                    self.audit.kv_continuation_hits += 1
                    if self.prefill_cache_mode == "prefix":
                        self.audit.kv_continuation_batched_hits += 1
                    else:
                        self.audit.kv_continuation_legacy_sequential_hits += 1
                else:
                    self.audit.kv_continuation_misses += 1

            response_status = "incomplete" if hit_token_limit else "completed"
            raw_text = "".join(output_chunks)
            try:
                parsed = parse_model_output(raw_text, policy)
            except ResponsesError:
                if not hit_token_limit:
                    raise
                parsed = ParsedModelOutput("", ())
            output_items: list[dict[str, Any]] = []
            output_index = 0
            if parsed.text or not parsed.calls:
                text = parsed.text
                content = {
                    "type": "output_text",
                    "text": text,
                    "annotations": [],
                    "logprobs": [],
                }
                item = {
                    "id": message_id,
                    "type": "message",
                    "status": response_status,
                    "role": "assistant",
                    "phase": "final_answer",
                    "content": [content],
                }
                if policy.enabled:
                    yield ResponseEvent.from_dict(
                        {
                            "type": "response.output_item.added",
                            "sequence_number": event_sequence,
                            "output_index": output_index,
                            "item": {**item, "status": "in_progress", "content": []},
                        }
                    )
                    event_sequence += 1
                    yield ResponseEvent.from_dict(
                        {
                            "type": "response.content_part.added",
                            "sequence_number": event_sequence,
                            "item_id": message_id,
                            "output_index": output_index,
                            "content_index": 0,
                            "part": {**content, "text": ""},
                        }
                    )
                    event_sequence += 1
                    if text:
                        yield ResponseEvent.from_dict(
                            {
                                "type": "response.output_text.delta",
                                "sequence_number": event_sequence,
                                "item_id": message_id,
                                "output_index": output_index,
                                "content_index": 0,
                                "delta": text,
                                "logprobs": [],
                            }
                        )
                        event_sequence += 1
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.output_text.done",
                        "sequence_number": event_sequence,
                        "item_id": message_id,
                        "output_index": output_index,
                        "content_index": 0,
                        "text": text,
                        "logprobs": [],
                    }
                )
                event_sequence += 1
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.content_part.done",
                        "sequence_number": event_sequence,
                        "item_id": message_id,
                        "output_index": output_index,
                        "content_index": 0,
                        "part": content,
                    }
                )
                event_sequence += 1
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.output_item.done",
                        "sequence_number": event_sequence,
                        "output_index": output_index,
                        "item": item,
                    }
                )
                event_sequence += 1
                output_items.append(item)
                output_index += 1

            history_calls: list[dict[str, Any]] = []
            for call in parsed.calls:
                item_id = new_id("fc")
                call_id = new_id("call")
                item = {
                    "id": item_id,
                    "type": "function_call",
                    "status": "completed",
                    "call_id": call_id,
                    "name": call.name,
                    "arguments": call.arguments,
                }
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.output_item.added",
                        "sequence_number": event_sequence,
                        "output_index": output_index,
                        "item": {**item, "status": "in_progress", "arguments": ""},
                    }
                )
                event_sequence += 1
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.function_call_arguments.delta",
                        "sequence_number": event_sequence,
                        "item_id": item_id,
                        "output_index": output_index,
                        "delta": call.arguments,
                    }
                )
                event_sequence += 1
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.function_call_arguments.done",
                        "sequence_number": event_sequence,
                        "item_id": item_id,
                        "output_index": output_index,
                        "arguments": call.arguments,
                    }
                )
                event_sequence += 1
                yield ResponseEvent.from_dict(
                    {
                        "type": "response.output_item.done",
                        "sequence_number": event_sequence,
                        "output_index": output_index,
                        "item": item,
                    }
                )
                event_sequence += 1
                output_items.append(item)
                history_calls.append(
                    {
                        "id": call_id,
                        "type": "function",
                        "function": {
                            "name": call.name,
                            "arguments": json.loads(call.arguments),
                        },
                    }
                )
                output_index += 1
            usage = ResponseUsage(len(input_ids), len(output_ids), len(input_ids) + len(output_ids))
            check_epoch_cancelled()
            final = Response(
                id=response_id,
                model=model_id,
                output=output_items,
                status=response_status,
                incomplete_details={"reason": "max_output_tokens"} if hit_token_limit else None,
                usage=usage,
                **_response_contract_fields(body, max_output_tokens=max_tokens),
            )
            if offset_execution:
                assert offset_transport is not None
                offset_transport.complete()
            elif decode_reuse:
                retire_decode_material(len(output_ids))
            elif not client_owned:
                complete = self._control_post(self.http,
                    f"/v1/runtime/sessions/{session_id}/complete",
                    headers=self.headers,
                    json={"usage": usage.to_dict()},
                )
                _raise(complete)
            if boundary_transport is not None:
                boundary_transport.complete()
            evaluated_ids = [*input_ids, *output_ids]
            if (runtime.position != len(evaluated_ids) - len(pending_token_ids)
                    or (pending_token_ids and evaluated_ids[runtime.position:] != pending_token_ids)):
                raise ModelError("generated state differs from the exact evaluated token cohort")
            if prefill_candidate is not None and compiled is not None:
                cache = prefill_candidate[0]
                if (cache.generated_prefixes and runtime.position > len(input_ids)
                        and runtime.position <= compiled._plan.to_dict()["prefill"]["query_sequence"]):
                    # Completion has been acknowledged. A selected but unexecuted
                    # final token never enters this independent canonical key.
                    canonical = (runtime.canonical_generated_snapshot()
                                 if runtime._snapshot_basis.phase == "incremental"
                                 else runtime.snapshot())
                    executed_ids = evaluated_ids[:runtime.position]
                    cache.put_prefixes(compiled.digest, state.bundle_fingerprint, executed_ids, canonical)
                    cache.put(prefill_key(compiled.digest, state.bundle_fingerprint, executed_ids,
                        causal_reduction=cache.causal_reduction), canonical, np.asarray(logits))
            self.cache[response_id] = final
            self.histories[response_id] = rendered + raw_text
            assistant_history: dict[str, Any] = {"role": "assistant", "content": parsed.text}
            if history_calls:
                assistant_history["tool_calls"] = history_calls
            self.message_histories[response_id] = [*structured, assistant_history]
            if bool(body.get("store", True)) and getattr(runtime, "_retained", None) is None:
                with self._transformer_conversation_lock:
                    self._transformer_conversations[response_id] = _TransformerConversationState(
                        model_id=model_id,
                        bundle_fingerprint=state.bundle_fingerprint,
                        token_ids=[*input_ids, *output_ids],
                        rendered_context=rendered + raw_text,
                        snapshot=runtime.snapshot_for_response(response_id),
                        next_logits=np.asarray(logits, dtype=np.float32).copy(),
                        pending_token_ids=pending_token_ids,
                    )
            self._remember_response(response_id)
            if decode_reuse:
                check_epoch_cancelled()
                if decode_tickets:
                    prior_head = self.decode_cache.head
                    current_head = self.decode_cache.commit(decode_tickets, acknowledged=True)
                    self._decode_publications[response_id] = (prior_head, current_head)
                check_epoch_cancelled()
                if not decode_remote_used:
                    self.audit.decode_cache_fully_warm_responses += 1
            terminal_event = ResponseEvent.from_dict(
                {
                    "type": f"response.{response_status}",
                    "sequence_number": event_sequence,
                    "response": final.to_dict(),
                }
            )
            # Construct before success; explicit cancel shares this readiness
            # boundary. This is not an atomic promise of physical delivery.
            with self._response_cache_lock:
                check_epoch_cancelled()
                if epochs_enabled:
                    self._decode_terminal_responses.add(response_id)
                session_completed = True
            yield terminal_event
        finally:
            cleanup_primary = sys.exception()
            retirement_errors = []

            def retire(function, *args):
                try:
                    function(*args)
                except BaseException as error:
                    retirement_errors.append(error)

            if getattr(runtime, "_retained", None) is not None:
                retire(runtime._retained.burn, runtime)
            completed_online_bytes = response_online_bytes()
            if boundary_transport is not None:
                retire(retire_boundary)
            if (
                session_completed and first_output_online_bytes is not None
                and completed_online_bytes is not None and output_ids
                and completed_online_bytes >= first_output_online_bytes
            ):
                self.audit.generation_completed_responses += 1
                self.audit.generation_output_tokens += len(output_ids)
                self.audit.generation_decode_output_tokens += len(output_ids) - 1
                self.audit.generation_prefill_online_body_bytes += first_output_online_bytes
                self.audit.generation_decode_online_body_bytes += (
                    completed_online_bytes - first_output_online_bytes
                )
                self.audit.generation_requested_output_tokens += max_tokens
                self.audit.generation_executed_decode_steps += executed_decode_steps
                self.audit.generation_requested_decode_steps += executed_decode_steps
                if (isinstance(remote, PreparedRemoteLinear) and compiled is not None
                        and self.preparation_allocation == "demand" and not epochs_enabled
                        and not previous_id and self._inflight_prefix_owner is None
                        and not self.background_inventory_refill and state.public_prefix_binding is None):
                    self.audit.generation_attribution_supported_responses += 1
            if offset_transport is not None:
                with self._activity_lock:
                    if self._active_offset_transports.get(session_id) is offset_transport:
                        self._active_offset_transports.pop(session_id, None)
                if not session_completed:
                    retire(offset_transport.abort)
                for role, values in offset_transport.http_body_costs.items():
                    tracked = self.audit.role_link_bodies.setdefault(role, {})
                    for metric, count in values.items():
                        tracked[metric] = tracked.get(metric, 0) + count
                self.audit.inference_stage_calls += offset_transport.costs.stages
                self.audit.online_steps += offset_transport.costs.rows
                for metric, count in offset_transport.nonlinear_costs.items():
                    name = f"nonlinear_{metric}"
                    setattr(self.audit, name, getattr(self.audit, name) + count)
            if isinstance(remote, PreparedRemoteLinear):
                self.audit.preparation_upload_bytes += remote.stats.preparation_upload_bytes
                self.audit.preparation_download_bytes += remote.stats.preparation_download_bytes
                self.audit.inference_upload_bytes += remote.stats.inference_upload_bytes
                self.audit.inference_download_bytes += remote.stats.inference_download_bytes
                self.audit.preparation_server_ns += remote.stats.preparation_server_ns
                self.audit.inference_server_ns += remote.stats.inference_server_ns
                self.audit.correction_push_bytes += remote.stats.correction_push_bytes
                self.audit.correction_push_ns += remote.stats.correction_push_ns
                if not session_completed and (not epochs_enabled or epoch_session_active):
                    # Cancel/drain the current provider before releasing its online
                    # exclusion. No fresh epoch may be issued after cancellation.
                    if channel is not None:
                        retire(channel.close)
                        channel = None
                    retire(self._cancel_transformer_session, session_id)
                if not epochs_enabled or epoch_session_active:
                    retire(self._finish_prepared_response, model_id, state, remote.inventory)
            if epochs_enabled:
                with self._response_cache_lock:
                    self._decode_epoch_responses.pop(response_id, None)
                with self._transformer_state_lock:
                    if state.prepared_inventory is not None:
                        retire(self._cancel_prepared_inventory, state.prepared_inventory)
                        state.prepared_inventory = None
                if not session_completed:
                    retire(runtime.reset)
            if channel is not None:
                retire(channel.close)
            if attempt is not None:
                retire(runtime.reset)
            try:
                _raise_cleanup_errors(retirement_errors, cleanup_primary)
            finally:
                # GeneratorExit includes this frame. Do not retain that cycle
                # after close and keep request-owned tokenizer/tensors alive.
                cleanup_primary = None
                retirement_errors.clear()


class ResponsesResource:
    def __init__(self, core: RuntimeClient) -> None:
        self.core = core

    def create(self, **kwargs: Any) -> Response | ResponseStream[ResponseEvent]:
        return self.core.create(kwargs)

    def retrieve(self, response_id: str) -> Response:
        return self.core.retrieve(response_id)

    def cancel(self, response_id: str) -> Response:
        return self.core.cancel(response_id)


class ModelsResource:
    def __init__(self, core: RuntimeClient) -> None:
        self.core = core

    def list(self) -> dict[str, Any]:
        return self.core.list_models()


class RuntimeResource:
    """Runtime control plane and native stage-extension surface.

    The methods under ``client.runtime`` are intentionally outside the OpenAI API
    schema. They let runtime plugins import weights and execute opaque encrypted
    stage frames while ordinary application code continues to use
    ``client.responses.create(...)``.
    """

    def __init__(self, core: RuntimeClient) -> None:
        self.core = core

    def preprocess(
        self,
        *,
        model: str,
        correlations: int = 64,
        stages: list[str] | None = None,
    ) -> dict[str, Any]:
        return self.core.preprocess(model, correlations, stages=stages)

    def capabilities(self) -> dict[str, Any]:
        response = self.core.http.get("/v1/runtime/capabilities", headers=self.core.headers)
        _raise(response)
        return response.json()

    def engines(self) -> dict[str, Any]:
        response = self.core.http.get("/v1/runtime/engines", headers=self.core.headers)
        _raise(response)
        return response.json()

    @staticmethod
    def _model_body(model: "Model | str | None", source: dict[str, Any]) -> dict[str, Any]:
        if model is None:
            return source
        unknown = set(source) - {"token", "cache_dir", "api_key"}
        if unknown:
            raise ValueError(f"model cannot be combined with source fields: {sorted(unknown)}")
        from pllm.model_loader import coerce_model

        return {**coerce_model(model).to_runtime_spec(), **source}

    def inspect_model(
        self,
        model: "Model | str | None" = None,
        **source: Any,
    ) -> dict[str, Any]:
        response = self.core.http.post(
            "/v1/runtime/models/inspect",
            headers=self.core.headers,
            json=self._model_body(model, source),
        )
        _raise(response)
        return response.json()

    def load_model(
        self,
        model: "Model | str | None" = None,
        *,
        engine: str,
        **source: Any,
    ) -> dict[str, Any]:
        response = self.core.http.post(
            "/v1/runtime/models/load",
            headers=self.core.headers,
            json={"engine": engine, **self._model_body(model, source)},
        )
        _raise(response)
        return response.json()

    def unload_model(self, model: str) -> dict[str, Any]:
        response = self.core.http.delete(f"/v1/runtime/models/{model}", headers=self.core.headers)
        _raise(response)
        return response.json()

    def execute_stage(
        self,
        *,
        engine: str,
        model: str,
        stage: str,
        payloads: list[bytes],
    ) -> list[bytes]:
        if not payloads:
            raise ValueError("payloads cannot be empty")
        response = self.core.http.post(
            f"/v1/runtime/engines/{engine}/models/{model}/stages/{stage}",
            headers={**self.core.headers, "Content-Type": "application/octet-stream"},
            content=encode_length_prefixed(payloads),
        )
        _raise(response)
        results = list(iter_length_prefixed(response.content))
        if len(results) != len(payloads):
            raise ModelError("Runtime engine returned the wrong result count")
        return results

    @property
    def privacy_audit(self) -> PrivacyAudit:
        return self.core.audit


class OpenAI:
    def conversation(self, *, max_state_bytes: int = 32 << 20, **defaults: Any) -> Conversation:
        """Own a bounded exact multi-turn chain; use as a context manager."""
        from .conversation import Conversation

        return Conversation(self, max_state_bytes=max_state_bytes, **defaults)

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        default_model: str | None = None,
        model: str | None = None,
        session_transport: str | None = None,
        correlation_mode: str | None = None,
        preparation_base_url: str | None = None,
        preparation_api_key: str | None = None,
        correlation_prefetch: int | None = None,
        prepared_inventory_rows: int | None = None,
        preparation_decode_epoch_tokens: int | None = None,
        background_inventory_refill: bool | None = None,
        token_cache_size: int | None = None,
        prefill_cache_bytes: int = 0,
        prefill_cache_mode: str = "exact",
        prefill_cache_bound_tokens: int | None = None,
        decode_cache: DecodeCache | None = None,
        bundle_cache_mode: str | None = None,
        bundle_cache_dir: str | Path | None = None,
        bundle_compression: str | None = None,
        tenseal_path: str | None = None,
        timeout: float | None = None,
        http_client: httpx.Client | None = None,
        preparation_http_client: httpx.Client | None = None,
        experiment: Experiment | ExperimentProfile | None = None,
        local_engine: MaskedTransformerEngine | None = None,
        role_connections: Mapping[str, tuple[str, str]] | None = None,
        execution: Any | None = None,
        boundary_urls: tuple[str, str] | None = None,
        boundary_api_keys: tuple[str, str] | None = None,
        network: Any | None = None,
        planning: Any | None = None,
        performance_prior: Any | None = None,
        max_client_memory: str | None = None,
        _automatic: bool = True,
    ) -> None:
        from pllm.configuration import Experiment, ExperimentProfile
        from pllm.settings import ClientSettings

        if execution is not None:
            from pllm.deployment.execution import ExecutionLease

            if not isinstance(execution, ExecutionLease):
                raise TypeError("execution must be an ExecutionLease")
            overrides = (
                api_key,
                base_url,
                default_model,
                model,
                session_transport,
                correlation_mode,
                preparation_base_url,
                preparation_api_key,
                correlation_prefetch,
                prepared_inventory_rows,
                preparation_decode_epoch_tokens,
                token_cache_size,
                prefill_cache_bound_tokens,
                decode_cache,
                bundle_cache_mode,
                bundle_cache_dir,
                bundle_compression,
                tenseal_path,
                timeout,
                http_client,
                preparation_http_client,
                experiment,
                local_engine,
                role_connections,
                boundary_urls,
                boundary_api_keys,
                network,
                planning,
                performance_prior,
                max_client_memory,
            )
            if (
                any(value is not None for value in overrides)
                or prefill_cache_bytes != 0
                or prefill_cache_mode != "exact"
                or background_inventory_refill not in (None, True)
            ):
                raise ValueError("execution conflicts with manual client overrides")
            leased = execution._construct_client()
            self._core = leased._core
            self._owned_topology = None
            self.responses = leased.responses
            self.models = leased.models
            self.runtime = leased.runtime
            return

        settings_base = ClientSettings.load()
        if _automatic:
            network = network if network is not None else settings_base.network
            if performance_prior is None:
                performance_prior = settings_base.performance_prior
            if planning is None and settings_base.planning is not None:
                from pllm.deployment.selection import SelectedClientFactory

                planning = SelectedClientFactory.default_policy(**settings_base.planning)
            if experiment is None and settings_base.experiment is not None:
                from pllm.deployment.network import strict_load

                experiment = Experiment.from_spec(strict_load(
                    Path(settings_base.experiment).read_bytes()))
        if network is not None:
            from pllm.deployment import NetworkSpec
            from pllm.deployment.network import strict_load
            from pllm.deployment.selection import SelectedClientFactory
            from .planned_client import PlannedClient

            manual = (api_key, base_url, session_transport, correlation_mode,
                      preparation_base_url, preparation_api_key, correlation_prefetch,
                       prepared_inventory_rows, preparation_decode_epoch_tokens, token_cache_size, prefill_cache_bound_tokens,
                      bundle_cache_mode, bundle_cache_dir, bundle_compression, tenseal_path,
                       timeout, http_client, preparation_http_client, local_engine, role_connections,
                        decode_cache, boundary_urls, boundary_api_keys)
            if (any(value is not None for value in manual) or prefill_cache_bytes
                    or prefill_cache_mode != "exact" or background_inventory_refill is not None):
                raise ValueError("automatic network planning conflicts with manual runtime overrides")
            if isinstance(network, (str, Path)):
                network = NetworkSpec.from_spec(strict_load(Path(network).expanduser().read_bytes()))
            if not isinstance(experiment, Experiment):
                raise ValueError("automatic network planning requires a configured Experiment")
            if max_client_memory is not None:
                from dataclasses import replace
                from pllm.search import PlanningPolicy

                if planning is not None and not isinstance(planning, PlanningPolicy):
                    raise TypeError("planning must be a PlanningPolicy")
                planning = replace(planning or SelectedClientFactory.default_policy(),
                                   max_client_memory=max_client_memory)
            factory = SelectedClientFactory(network, experiment=experiment, policy=planning,
                                            performance_prior=performance_prior)
            requested_model = default_model or model or settings_base.model
            if requested_model is not None and requested_model not in factory.model_ids:
                raise ValueError("client model conflicts with configured deployment")
            self._core = PlannedClient(factory)
            self._owned_topology = None
            self.responses = ResponsesResource(self._core)
            self.models = ModelsResource(self._core)
            self.runtime = RuntimeResource(self._core)
            return
        if planning is not None or performance_prior is not None or max_client_memory is not None:
            raise ValueError("resource planning requires a configured network")

        profile = experiment.resolve() if isinstance(experiment, Experiment) else experiment
        if profile is not None and "inventory" in json.loads(profile.canonical_composition).get(
            "components", {}
        ):
            if (
                prepared_inventory_rows is not None
                and prepared_inventory_rows != profile.prepared_inventory_rows
            ):
                raise ValueError("inventory rows conflict with immutable Experiment")
            prepared_inventory_rows = profile.prepared_inventory_rows
        expected_epoch = (json.loads(profile.canonical_composition).get("components", {})
                          .get("inventory", {}).get("params", {}).get("decode_epoch_tokens")
                          if profile is not None else None)
        if preparation_decode_epoch_tokens is not None and (
                type(preparation_decode_epoch_tokens) is not int or not 1 <= preparation_decode_epoch_tokens <= 64):
            raise ValueError("preparation_decode_epoch_tokens must be in [1, 64]")
        if preparation_decode_epoch_tokens is not None and preparation_decode_epoch_tokens != expected_epoch:
            raise ValueError("decode epoch override differs from immutable Experiment")
        preparation_decode_epoch_tokens = expected_epoch
        client_owned = profile is not None and profile.client_runtime == "compiled_client_local_v1"
        offset_execution = profile is not None and profile.client_runtime == "compiled_offset_v1"
        self._owned_topology: Any | None = None
        if client_owned and (
            base_url is not None
            or api_key is not None
            or http_client is not None
            or preparation_base_url is not None
            or preparation_api_key is not None
            or preparation_http_client is not None
            or session_transport is not None
            or correlation_mode is not None
            or prepared_inventory_rows is not None
            or background_inventory_refill not in (None, True)
            or tenseal_path is not None
        ):
            raise ValueError("client-only Experiment requires only client-owned model weights")
        if local_engine is not None and not client_owned:
            raise ValueError("client-owned model requires a client-only Experiment")
        if client_owned and local_engine is None and not isinstance(experiment, Experiment):
            raise ValueError("client-only model loading requires an Experiment source")
        if offset_execution and (
            base_url is not None
            or api_key is not None
            or http_client is not None
            or preparation_base_url is not None
            or preparation_api_key is not None
            or preparation_http_client is not None
            or local_engine is not None
            or session_transport is not None
            or correlation_mode is not None
            or prepared_inventory_rows is not None
            or background_inventory_refill not in (None, True)
            or tenseal_path is not None
        ):
            raise ValueError("offset Experiment requires only role-specific worker connections")
        if role_connections is not None and not offset_execution:
            raise ValueError("worker connections require an offset Experiment")
        if offset_execution and role_connections is None and not isinstance(experiment, Experiment):
            raise ValueError("offset worker loading requires an Experiment source")
        settings = settings_base.merged(
            api_key=api_key,
            base_url=base_url,
            model=default_model or model,
            transport=session_transport,
            correlation_mode=correlation_mode,
            preparation_base_url=preparation_base_url,
            preparation_api_key=preparation_api_key,
            correlation_prefetch=correlation_prefetch,
            prepared_inventory_rows=prepared_inventory_rows,
            token_cache_size=token_cache_size,
            bundle_cache_mode=bundle_cache_mode,
            bundle_cache_dir=bundle_cache_dir,
            timeout=timeout,
        )
        if isinstance(experiment, (Experiment, ExperimentProfile)):
            if not profile.requires_preparation:
                if (
                    preparation_base_url is not None
                    or preparation_api_key is not None
                    or preparation_http_client is not None
                ):
                    raise ValueError(
                        "preparation settings conflict with an Experiment that has no preparation role"
                    )
                settings.preparation_base_url = None
                settings.preparation_api_key = None
        if client_owned or offset_execution:
            # Provider settings inherited from the environment cannot change a
            # client-only role graph into an accidental network dependency.
            if (default_model or model) is not None and (default_model or model) != profile.model:
                raise ValueError("request model conflicts with Experiment model")
            if client_owned:
                settings.base_url = ""
                settings.api_key = ""
            settings.model = profile.model
        if (client_owned and local_engine is None) or (
            offset_execution and role_connections is None
        ):
            from pllm.runtime.servers import build_roles

            self._owned_topology = build_roles(experiment).start()
            if client_owned:
                local_engine = self._owned_topology._local_engine
            else:
                role_connections = self._owned_topology.worker_connections()
        if offset_execution:
            if role_connections is None or set(role_connections) != {"worker_a", "worker_b"}:
                raise ValueError("offset Experiment requires both worker connections")
            settings.base_url, settings.api_key = role_connections["worker_a"]
        try:
            self._core = RuntimeClient(
                base_url=settings.base_url,
                api_key=settings.api_key,
                default_model=settings.model,
                session_transport=settings.transport,
                correlation_mode=settings.correlation_mode,
                preparation_base_url=settings.preparation_base_url,
                preparation_api_key=settings.preparation_api_key,
                correlation_prefetch=settings.correlation_prefetch,
                prepared_inventory_rows=settings.prepared_inventory_rows,
                preparation_decode_epoch_tokens=preparation_decode_epoch_tokens,
                background_inventory_refill=background_inventory_refill,
                token_cache_size=settings.token_cache_size,
                prefill_cache_bytes=prefill_cache_bytes,
                prefill_cache_mode=prefill_cache_mode,
                prefill_cache_bound_tokens=prefill_cache_bound_tokens,
                decode_cache=decode_cache,
                bundle_cache_mode=settings.bundle_cache_mode,
                bundle_cache_dir=settings.bundle_cache_dir,
                bundle_compression=bundle_compression,
                tenseal_path=tenseal_path,
                timeout=settings.timeout,
                http_client=http_client,
                preparation_http_client=preparation_http_client,
                experiment=experiment,
                local_engine=local_engine,
                role_connections=role_connections,
                boundary_urls=boundary_urls,
                boundary_api_keys=boundary_api_keys,
            )
        except BaseException:
            if self._owned_topology is not None:
                self._owned_topology.close()
            raise
        self.responses = ResponsesResource(self._core)
        self.models = ModelsResource(self._core)
        self.runtime = RuntimeResource(self._core)

    @property
    def privacy_audit(self) -> PrivacyAudit:
        return self._core.audit

    def planning(self, response_id: str):
        """Inspect the bounded immutable planning explanation for a response."""
        inspect = getattr(self._core, "planning", None)
        return inspect(response_id) if inspect is not None else None

    def preprocess(
        self,
        model: str | None = None,
        *,
        count: int | None = None,
        stages: list[str] | None = None,
    ) -> dict[str, Any]:
        model_id = model or self._core.default_model
        if model_id is None:
            raise ValueError("model is required")
        target = count if count is not None else self._core.prepared_inventory_rows
        return self._core.preprocess(model_id, count=target, stages=stages)

    def prepared_inventory_status(self, model: str | None = None) -> dict[str, Any]:
        model_id = model or self._core.default_model
        if model_id is None:
            raise ValueError("model is required")
        return self._core.prepared_inventory_status(model_id)

    def prepare_response(self, input, max_output_tokens: int, *, model: str | None = None,
                         instructions: str | None = None, store: bool = True) -> dict[str, Any]:
        """Prepare a response's public shape demand while the client is idle."""
        model_id = model or self._core.default_model
        if model_id is None:
            raise ValueError("model is required")
        return self._core.prepare_response(model_id, input, max_output_tokens, instructions=instructions, store=store)

    def tokenizer_scope(self) -> AbstractContextManager[None]:
        """Share one source-bound tokenizer across request sizing and execution.

        Use ``with client.tokenizer_scope():`` around preparation sizing and a
        fully consumed response. Setup remains local. The scope holds no prompt
        or token IDs, retains at most one bundle's tokenizer, and releases its
        ownership on normal exit or failure. Nested scopes reuse the outer owner.
        """
        return self._core.tokenizer_scope()

    def prepared_rows_for_response(
        self,
        input: str,
        max_output_tokens: int,
        *,
        model: str | None = None,
        instructions: str | None = None,
        store: bool = True,
    ) -> int:
        model_id = model or self._core.default_model
        if model_id is None:
            raise ValueError("model is required")
        return self._core.prepared_rows_for_response(
            model_id,
            input,
            max_output_tokens,
            instructions=instructions,
            store=store,
        )

    def close(self) -> None:
        try:
            self._core.close()
        finally:
            if self._owned_topology is not None:
                self._owned_topology.close()

    def __enter__(self) -> "OpenAI":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


class AsyncResponsesResource:
    def __init__(self, resource: ResponsesResource) -> None:
        self.resource = resource

    async def create(self, **kwargs: Any):
        from .planned_client import PlannedClient, _owned_thread
        from .prepared_queue import PreparedCancellation, prepared_cancellation

        core = getattr(self.resource, "core", None)
        if isinstance(core, PlannedClient):
            return await core.async_create(kwargs)
        context = copy_context()
        cancellation = PreparedCancellation()
        context.run(prepared_cancellation.set, cancellation)
        lock = threading.Lock()

        def owned_call(function, *args, **options):
            # Resume/close share one context; cancellation reaches queue/prefix
            # waiters before a provider has minted a response identifier.
            with lock:
                return context.run(function, *args, **options)

        if kwargs.get("stream"):
            stream = await _owned_thread(lambda: owned_call(self.resource.create, **kwargs),
                                         cancel=cancellation.cancel)
            assert isinstance(stream, ResponseStream)

            async def iterate() -> AsyncIterator[ResponseEvent]:
                sentinel = object()
                response_id = None

                def advance():
                    nonlocal response_id
                    event = _next_or(stream, sentinel)
                    response = getattr(event, "response", None) if event is not sentinel else None
                    if response is not None:
                        response_id = response.get("id", response_id)
                    return event

                try:
                    while True:
                        event = await _owned_thread(owned_call, advance, cancel=cancellation.cancel)
                        if event is sentinel:
                            break
                        if event.type in {"response.completed", "response.incomplete"}:
                            core._accept_decode_response(response_id)
                        yield event
                finally:
                    primary = sys.exception()
                    close_error = None
                    try:
                        await _owned_thread(owned_call, stream.close, cancel=cancellation.cancel)
                    except BaseException as error:
                        close_error = error
                    finally:
                        if cancellation.event.is_set() and response_id is not None:
                            core._abort_decode_response(response_id, primary=primary or close_error)
                    if close_error is not None:
                        _raise_cleanup_errors([close_error], primary)

            return iterate()
        completed = []

        def create():
            response = owned_call(self.resource.create, **kwargs)
            completed.append(response)
            return response

        try:
            response = await _owned_thread(create, cancel=cancellation.cancel)
            core._accept_decode_response(response.id)
            return response
        except asyncio.CancelledError as error:
            # Cancellation can race the final commit. The drained worker's
            # otherwise-unobservable completed response remains ours to retire.
            for response in completed:
                core._abort_decode_response(response.id, primary=error)
            raise

    async def retrieve(self, response_id: str) -> Response:
        return await asyncio.to_thread(self.resource.retrieve, response_id)

    async def cancel(self, response_id: str) -> Response:
        return await asyncio.to_thread(self.resource.cancel, response_id)


class AsyncModelsResource:
    def __init__(self, resource: ModelsResource) -> None:
        self.resource = resource

    async def list(self) -> dict[str, Any]:
        return await asyncio.to_thread(self.resource.list)


class AsyncRuntimeResource:
    def __init__(self, resource: RuntimeResource) -> None:
        self.resource = resource

    async def preprocess(
        self,
        *,
        model: str,
        correlations: int = 64,
        stages: list[str] | None = None,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            self.resource.preprocess,
            model=model,
            correlations=correlations,
            stages=stages,
        )

    async def capabilities(self) -> dict[str, Any]:
        return await asyncio.to_thread(self.resource.capabilities)

    async def engines(self) -> dict[str, Any]:
        return await asyncio.to_thread(self.resource.engines)

    async def inspect_model(
        self,
        model: "Model | str | None" = None,
        **source: Any,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(self.resource.inspect_model, model, **source)

    async def load_model(
        self,
        model: "Model | str | None" = None,
        *,
        engine: str,
        **source: Any,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            self.resource.load_model,
            model,
            engine=engine,
            **source,
        )

    async def unload_model(self, model: str) -> dict[str, Any]:
        return await asyncio.to_thread(self.resource.unload_model, model)

    async def execute_stage(
        self,
        *,
        engine: str,
        model: str,
        stage: str,
        payloads: list[bytes],
    ) -> list[bytes]:
        return await asyncio.to_thread(
            self.resource.execute_stage,
            engine=engine,
            model=model,
            stage=stage,
            payloads=payloads,
        )

    @property
    def privacy_audit(self) -> PrivacyAudit:
        return self.resource.privacy_audit


class AsyncOpenAI:
    def conversation(self, *, max_state_bytes: int = 32 << 20, **defaults: Any) -> AsyncConversation:
        """Own an async exact multi-turn chain with drained cancellation."""
        from .conversation import AsyncConversation

        return AsyncConversation(self, max_state_bytes=max_state_bytes, **defaults)

    def __init__(self, **kwargs: Any) -> None:
        self.sync = OpenAI(**kwargs)
        self.responses = AsyncResponsesResource(self.sync.responses)
        self.models = AsyncModelsResource(self.sync.models)
        self.runtime = AsyncRuntimeResource(self.sync.runtime)

    @property
    def privacy_audit(self) -> PrivacyAudit:
        return self.sync.privacy_audit

    async def planning(self, response_id: str):
        return await asyncio.to_thread(self.sync.planning, response_id)

    def tokenizer_scope(self) -> AbstractContextManager[None]:
        """Use a regular ``with`` block around awaited sizing and response calls."""
        return self.sync.tokenizer_scope()

    async def preprocess(
        self,
        model: str | None = None,
        *,
        count: int | None = None,
        stages: list[str] | None = None,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(
            self.sync.preprocess,
            model,
            count=count,
            stages=stages,
        )

    async def prepared_rows_for_response(
        self,
        input: str,
        max_output_tokens: int,
        *,
        model: str | None = None,
        instructions: str | None = None,
        store: bool = True,
    ) -> int:
        return await asyncio.to_thread(
            self.sync.prepared_rows_for_response,
            input,
            max_output_tokens,
            model=model,
            instructions=instructions,
            store=store,
        )

    async def prepare_response(
        self, input: str | list[Any], max_output_tokens: int, *, model: str | None = None,
        instructions: str | None = None, store: bool = True,
    ) -> dict[str, Any]:
        """Prepare exact stage demand while preserving request-scoped ownership."""
        return await asyncio.to_thread(
            self.sync.prepare_response, input, max_output_tokens, model=model,
            instructions=instructions, store=store,
        )

    async def close(self) -> None:
        from .planned_client import _owned_thread

        await _owned_thread(self.sync.close, cancel=lambda: None)

    async def __aenter__(self) -> "AsyncOpenAI":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()


def _next_or(iterator: Iterator[Any], sentinel: Any) -> Any:
    try:
        return next(iterator)
    except StopIteration:
        return sentinel


def _raise(response: httpx.Response) -> None:
    if response.is_success:
        return
    try:
        body = response.json()
        detail = body.get("detail", body)
        if isinstance(detail, dict) and "error" in detail:
            message = str(detail["error"].get("message", detail))
        else:
            message = str(detail)
    except httpx.ResponseNotRead:
        # A streaming rejection must retain its HTTP error, without an unbounded
        # read or a secondary ResponseNotRead hiding the admission failure.
        body = None
        message = f"provider returned HTTP {response.status_code}: {response.reason_phrase}"
    except Exception:
        body = response.text
        message = response.text
    raise ProtocolError(message, response.status_code, body)
