from __future__ import annotations

import argparse
import ipaddress
import os
import socket
from pathlib import Path
from typing import Any

import uvicorn

from pllm.configuration import Model
from pllm.model_loader import resolve_model
from pllm.sources import TinyModel
from pllm.settings import ClientSettings

from .blinded_engine import BlindedTransformerEngine
from .config import GatewayConfig
from .guarded_engine import GuardPolicy, GuardedBlindedTransformerEngine
from .preparation_server import create_preparation_app
from .privacy import PrivacyMode, ProprietaryProtocol
from .proprietary_engine import DirectFHETransformerEngine
from .server import create_app
from .servers import build_roles
from .sidecar import create_sidecar_app
from .transformer_engine import MaskedTransformerEngine


class RuntimeCLIError(ValueError):
    """Configuration error suitable for either runtime or public CLI rendering."""


def _env(name: str, default: Any = None) -> Any:
    value = os.getenv(name)
    return default if value is None else value


def _apply_server_defaults(args: argparse.Namespace) -> None:
    defaults: dict[str, Any] = {
        "config": None,
        "privacy_mode": _env("PLLM_PRIVACY_MODE"),
        "proprietary_protocol": _env("PLLM_PROPRIETARY_PROTOCOL"),
        "guard_max_rows_per_request": int(_env("PLLM_GUARD_MAX_ROWS", "4096")),
        "guard_max_rows_per_stage": int(_env("PLLM_GUARD_STAGE_BUDGET", "16384")),
        "guard_max_requests_per_minute": int(_env("PLLM_GUARD_RATE", "4096")),
        "guard_output_dither": int(_env("PLLM_GUARD_DITHER", "0")),
        "host": "127.0.0.1",
        "port": 8000,
        "api_key": _env("PLLM_API_KEY"),
        "provider_push_api_key": _env("PLLM_PROVIDER_PUSH_API_KEY"),
        "rendezvous_timeout": (
            float(value) if (value := _env("PLLM_RENDEZVOUS_TIMEOUT")) else None
        ),
        "rendezvous_capacity": (
            int(value) if (value := _env("PLLM_RENDEZVOUS_CAPACITY")) else None
        ),
        "rendezvous_max_bytes": (
            int(value) if (value := _env("PLLM_RENDEZVOUS_MAX_BYTES")) else None
        ),
        "prepared_session_capacity": (
            int(value) if (value := _env("PLLM_PREPARED_SESSION_CAPACITY")) else None
        ),
        "prepared_session_idle": (
            float(value) if (value := _env("PLLM_PREPARED_SESSION_IDLE")) else None
        ),
        "inference_url": _env("PLLM_INFERENCE_URL"),
        "push_api_key": _env("PLLM_PUSH_API_KEY"),
        "push_timeout": float(value) if (value := _env("PLLM_PUSH_TIMEOUT")) else None,
        "tenseal_path": _env("PLLM_PYDEPS"),
        "max_batch_size": None,
        "max_wait_ms": None,
        "fixed_batch_wait": False,
        "allow_insecure_local_correlations": False,
        "engine_threads": int(_env("PLLM_ENGINE_THREADS", "0") or 0),
        "metal_min_rows": None,
        "native_library": _env("PLLM_NATIVE_LIBRARY"),
        "compiled_cache_dir": _env("PLLM_COMPILED_CACHE"),
        "streaming_threshold_elements": 50_000_000,
        "quantization_chunk_rows": 64,
        "verification_component": _env("PLLM_VERIFICATION_COMPONENT", "none"),
        "verification_target_failure_bits": int(_env("PLLM_VERIFICATION_TARGET_FAILURE_BITS", "0")),
        "public_equalization_digest": None,
        "remote_output_head": False,
        "private_boundary": False,
        "client_prefix_layers": 0,
        "client_linear_layer_roles": "[]",
        "client_linear_roles": "",
        "prepared_output_encoding": "raw",
        "weight_bits": 8,
        "activation_bits": 8,
        "model": [],
        "model_id": [],
        "model_kind": "huggingface",
        "revision": _env("PLLM_HF_REVISION"),
        "hf_token": _env("HF_TOKEN"),
        "hf_cache_dir": _env("HF_HUB_CACHE"),
        "local_files_only": False,
    }
    for name, value in defaults.items():
        if not hasattr(args, name) or getattr(args, name) is None:
            setattr(args, name, value)


def run_server(args: argparse.Namespace, *, preparation: bool = False) -> None:
    """Run one role from already-parsed options."""
    _apply_server_defaults(args)
    if args.private_boundary:
        import json

        from pllm.configuration import Experiment
        from pllm.profiles import resolve_runtime_composition

        experiment = getattr(args, "resolved_experiment", None)
        if experiment is None:
            raw = os.environ.get("PLLM_ROLE_EXPERIMENT_JSON")
            if raw is None:
                raise RuntimeCLIError("private boundary requires a bound Experiment")
            try:
                experiment = Experiment.from_spec(json.loads(raw))
                experiment.resolve()
            except (TypeError, ValueError) as exc:
                raise RuntimeCLIError("private boundary Experiment is invalid") from exc
        selected = resolve_runtime_composition(experiment.pipeline)
        if selected is None or not getattr(selected, "private_boundary", False):
            raise RuntimeCLIError("private boundary differs from its Experiment")
    config = GatewayConfig.load(Path(args.config).expanduser()) if args.config else GatewayConfig()
    mode = PrivacyMode.parse(getattr(args, "privacy_mode", None) or config.privacy_mode)
    proprietary_protocol = ProprietaryProtocol.parse(
        getattr(args, "proprietary_protocol", None) or config.proprietary_protocol
    )
    if config.engine_models and not getattr(args, "model", None):
        requested_mode = getattr(args, "privacy_mode", None)
        if (
            requested_mode is not None
            and PrivacyMode.parse(requested_mode) is not config.privacy_mode
        ):
            raise RuntimeCLIError(
                "--privacy-mode cannot override configured models; update the role config or pass --model"
            )
        requested_protocol = getattr(args, "proprietary_protocol", None)
        if (
            requested_protocol is not None
            and ProprietaryProtocol.parse(requested_protocol) is not config.proprietary_protocol
        ):
            raise RuntimeCLIError(
                "--proprietary-protocol cannot override configured models; update the role config or pass --model"
            )
    if preparation and mode is not PrivacyMode.PUBLIC:
        raise RuntimeCLIError("the preparation service supports public-weight models only")
    if (
        not preparation
        and mode is PrivacyMode.PUBLIC
        and not (getattr(args, "provider_push_api_key", None) or config.provider_push_api_key)
    ):
        raise RuntimeCLIError("public serving requires --provider-push-api-key")
    if proprietary_protocol is ProprietaryProtocol.SECURE:
        raise RuntimeCLIError(
            "secure mode currently runs the complete protocol preview through `pllm secure`. "
            "Arbitrary Hugging Face Transformer serving fails closed until the secure graph "
            "compiler is complete"
        )
    metal_min_rows = args.metal_min_rows
    if metal_min_rows is not None:
        import json

        from pllm.configuration import Experiment
        from pllm.profiles import resolve_runtime_composition

        experiment = getattr(args, "resolved_experiment", None)
        if experiment is None:
            raw = os.environ.get("PLLM_ROLE_EXPERIMENT_JSON")
            if raw is not None:
                try:
                    experiment = Experiment.from_spec(json.loads(raw))
                    experiment.resolve()
                except (TypeError, ValueError, json.JSONDecodeError) as exc:
                    raise RuntimeCLIError("role Metal Experiment is invalid") from exc
        if experiment is None:
            raise RuntimeCLIError("Metal provider kernel requires a bound Experiment")
        kernels = experiment.pipeline.components.get("kernels")
        options = resolve_runtime_composition(experiment.pipeline)
        if (
            options is None
            or options.client_runtime not in {"masked_transformer_v1", "compiled_offset_v1"}
            or options.privacy_mode not in {"public", "offset_public"}
            or kernels is None
            or kernels.component != "pllm/apple-metal-int8/v1"
            or kernels.params.get("min_rows") != metal_min_rows
            or (preparation and not options.requires_preparation)
            or options.weight_bits != args.weight_bits
            or options.activation_bits != args.activation_bits
            or (not preparation and mode is not PrivacyMode.PUBLIC)
        ):
            raise RuntimeCLIError("role Metal kernel differs from its Experiment")

    value = config.to_dict()
    value["privacy_mode"] = mode.value
    value["proprietary_protocol"] = proprietary_protocol.value
    if getattr(args, "api_key", None):
        value["api_keys"] = [args.api_key]
    if getattr(args, "provider_push_api_key", None):
        value["provider_push_api_key"] = args.provider_push_api_key
    for argument, field in (
        ("rendezvous_timeout", "rendezvous_timeout_seconds"),
        ("rendezvous_capacity", "rendezvous_capacity"),
        ("rendezvous_max_bytes", "rendezvous_max_bytes"),
        ("prepared_session_capacity", "prepared_session_capacity"),
        ("prepared_session_idle", "prepared_session_idle_seconds"),
    ):
        option = getattr(args, argument, None)
        if option is not None:
            value[field] = option
    if preparation:
        for argument, field in (
            ("inference_url", "preparation_inference_url"),
            ("push_api_key", "preparation_push_api_key"),
            ("push_timeout", "preparation_push_timeout_seconds"),
        ):
            option = getattr(args, argument, None)
            if option is not None:
                value[field] = option
    if args.tenseal_path:
        value["tenseal_path"] = args.tenseal_path
    if args.max_batch_size is not None:
        value["max_batch_size"] = args.max_batch_size
    if args.max_wait_ms is not None:
        value["max_batch_wait_ms"] = args.max_wait_ms
    if args.fixed_batch_wait:
        value["adaptive_batching"] = False
    if args.allow_insecure_local_correlations:
        value["allow_insecure_local_correlations"] = True

    host = str(args.host).strip("[]").lower()
    loopback = host in {"127.0.0.1", "::1", "localhost"}
    if not loopback and value.get("api_keys") == ["pllm-local"]:
        raise RuntimeCLIError(
            "Refusing non-loopback bind with the default API key; configure explicit non-default credentials"
        )

    if args.model:
        if args.model_id and len(args.model_id) != len(args.model):
            raise RuntimeCLIError("--model-id must be supplied once per --model")
        ids = args.model_id or [None] * len(args.model)
        resolved_models = []
        for source, requested_id in zip(args.model, ids, strict=True):
            model = Model(
                source,
                kind=args.model_kind,
                model_id=requested_id,
                revision=args.revision,
                local_files_only=args.local_files_only,
            )
            resolved = resolve_model(
                model,
                token=args.hf_token,
                cache_dir=args.hf_cache_dir,
            )
            if resolved.path is None:
                raise RuntimeCLIError(f"model kind {model.kind!r} has no local runtime source")
            # Re-resolve the same source offline at startup. Replacing a Hub
            # specification with its local path drops repo/revision/commit from
            # the source lock and invalidates source-bound public artifacts.
            runtime_model = model.with_params(
                model_id=resolved.manifest.id,
                local_files_only=model.kind in {"huggingface", "safetensors", "vllm"},
            )
            if mode is PrivacyMode.PUBLIC:
                engine_name = "masked-transformer-w4a4"
            elif proprietary_protocol is ProprietaryProtocol.GUARDED:
                engine_name = "guarded-transformer-proprietary"
            elif proprietary_protocol is ProprietaryProtocol.BLINDED:
                engine_name = "blinded-transformer-proprietary"
            elif proprietary_protocol is ProprietaryProtocol.DIRECT:
                engine_name = "direct-bfv-transformer-proprietary"
            else:
                raise AssertionError("secure mode must fail before model loading")
            resolved_models.append({
                "engine": engine_name, **runtime_model.to_runtime_spec(),
                "cache_dir": args.hf_cache_dir,
                "source_lock_digest": resolved.source_lock_digest,
            })
        value["engine_models"] = resolved_models
    config = GatewayConfig.from_dict(value)
    loopback = _is_loopback_host(args.host)
    if not loopback and (not config.api_keys or "pllm-local" in config.api_keys):
        raise RuntimeCLIError(
            "non-loopback serving requires an explicit --api-key or config api_keys"
        )

    if mode is PrivacyMode.PUBLIC:
        engine_type = MaskedTransformerEngine
    elif proprietary_protocol is ProprietaryProtocol.GUARDED:
        engine_type = GuardedBlindedTransformerEngine
    elif proprietary_protocol is ProprietaryProtocol.BLINDED:
        engine_type = BlindedTransformerEngine
    elif proprietary_protocol is ProprietaryProtocol.DIRECT:
        engine_type = DirectFHETransformerEngine
    else:
        raise AssertionError("secure mode must fail before engine creation")

    engine_kwargs: dict[str, Any] = {
        "tenseal_path": config.tenseal_path,
        "threads": args.engine_threads or None,
        "native_library": args.native_library,
        "compiled_cache_dir": args.compiled_cache_dir,
        "streaming_threshold_elements": args.streaming_threshold_elements,
        "quantization_chunk_rows": args.quantization_chunk_rows,
        "weight_bits": args.weight_bits,
        "activation_bits": args.activation_bits,
        "verification_component": args.verification_component,
        "verification_target_failure_bits": args.verification_target_failure_bits,
        "metal_min_rows": metal_min_rows,
    }
    if engine_type is MaskedTransformerEngine:
        engine_kwargs["weight_residency"] = "provider" if preparation else "provider_and_bundle"
        from dataclasses import replace
        from pllm.configuration import Experiment
        from pllm.profiles import resolve_runtime_composition
        import json

        experiment = getattr(args, "resolved_experiment", None)
        raw = os.environ.get("PLLM_ROLE_EXPERIMENT_JSON")
        if experiment is None and raw is not None:
            experiment = Experiment.from_spec(json.loads(raw))
            experiment.resolve()
        if experiment is not None:
            selected = resolve_runtime_composition(experiment.pipeline)
            if selected is None:
                raise RuntimeCLIError("unsupported provider Experiment")
            if bool(getattr(selected, "private_boundary", False)) != args.private_boundary:
                raise RuntimeCLIError("private boundary role flag differs from its Experiment")
            if preparation:
                engine_kwargs["weight_storage"] = selected.preparation_storage
                engine_kwargs["preparation_kernel"] = selected.preparation_kernel
                engine_kwargs["preparation_min_rows"] = selected.preparation_min_rows
            else:
                if config.public_artifact_cache_bytes not in (0, selected.provider_artifact_cache_bytes):
                    raise RuntimeCLIError("provider artifact cache differs from its Experiment")
                config = replace(config, public_artifact_cache_bytes=selected.provider_artifact_cache_bytes)
    if args.public_equalization_digest is not None:
        if engine_type is not MaskedTransformerEngine:
            raise RuntimeCLIError("public equalization requires a public masked-linear engine")
        engine_kwargs["public_equalization_digest"] = args.public_equalization_digest
    if args.remote_output_head:
        if engine_type is not MaskedTransformerEngine:
            raise RuntimeCLIError("remote output head requires public prepared roles")
        engine_kwargs["remote_output_head"] = True
    if args.private_boundary:
        if engine_type is not MaskedTransformerEngine:
            raise RuntimeCLIError("private boundary requires public prepared roles")
        engine_kwargs["private_boundary"] = True
    if args.client_prefix_layers:
        if engine_type is not MaskedTransformerEngine:
            raise RuntimeCLIError("client prefix layers require public prepared roles")
        engine_kwargs["client_prefix_layers"] = args.client_prefix_layers
    if args.client_linear_roles:
        if engine_type is not MaskedTransformerEngine:
            raise RuntimeCLIError("client linear roles require public prepared roles")
        engine_kwargs["client_linear_roles"] = tuple(args.client_linear_roles.split(","))
    if getattr(args, "client_linear_layer_roles", "[]") != "[]":
        if engine_type is not MaskedTransformerEngine:
            raise RuntimeCLIError("client linear layer roles require public prepared roles")
        engine_kwargs["client_linear_layer_roles"] = json.loads(args.client_linear_layer_roles)
    if getattr(args, "prepared_output_encoding", None) not in (None, "raw"):
        if engine_type is not MaskedTransformerEngine:
            raise RuntimeCLIError("prepared residue encoding requires public roles")
        engine_kwargs["prepared_output_encoding"] = args.prepared_output_encoding
    if engine_type is GuardedBlindedTransformerEngine:
        engine_kwargs["guard_policy"] = GuardPolicy(
            max_rows_per_request=args.guard_max_rows_per_request,
            max_rows_per_owner_stage=args.guard_max_rows_per_stage,
            max_requests_per_owner_minute=args.guard_max_requests_per_minute,
            output_dither_bound=args.guard_output_dither,
        )
    engine = engine_type(**engine_kwargs)
    from .telemetry import configure_telemetry

    configure_telemetry("pllm-preparation" if preparation else "pllm-inference")
    app = (
        create_preparation_app(config, engine)
        if preparation
        else create_app(config, engines={engine.capabilities.name: engine})
    )
    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        access_log=False,
        ws_max_size=config.prepared_payload_max_bytes,
    )


def run_sidecar(args: argparse.Namespace) -> None:
    """Run gateway from already-parsed options."""
    config = getattr(args, "config", None)
    try:
        settings = ClientSettings.load(Path(config).expanduser() if config else None)
    except (OSError, TypeError, ValueError) as exc:
        raise RuntimeCLIError(f"Cannot load client config: {exc}") from exc
    if settings.network:
        manual = ("inference_url", "inference_key", "preparation_url", "preparation_key",
                  "transport", "correlation_mode", "correlation_prefetch", "prepared_inventory_rows",
                  "token_cache_size", "bundle_cache_mode", "bundle_cache_dir", "timeout", "tenseal_path")
        if any(getattr(args, name, None) is not None for name in manual):
            raise RuntimeCLIError("automatic network planning conflicts with manual runtime overrides")
    settings = settings.merged(
        base_url=getattr(args, "inference_url", None),
        api_key=getattr(args, "inference_key", None),
        model=getattr(args, "model", None) or getattr(args, "model_id", None),
        transport=getattr(args, "transport", None),
        correlation_mode=getattr(args, "correlation_mode", None),
        preparation_base_url=getattr(args, "preparation_url", None),
        preparation_api_key=getattr(args, "preparation_key", None),
        correlation_prefetch=getattr(args, "correlation_prefetch", None),
        prepared_inventory_rows=getattr(args, "prepared_inventory_rows", None),
        token_cache_size=getattr(args, "token_cache_size", None),
        bundle_cache_mode=getattr(args, "bundle_cache_mode", None),
        bundle_cache_dir=getattr(args, "bundle_cache_dir", None),
        timeout=getattr(args, "timeout", None),
    )
    if settings.network:
        from pllm.deployment.selection import SelectedClientFactory

        app = create_sidecar_app(
            client_factory=SelectedClientFactory.from_settings(settings),
            local_api_key=getattr(args, "api_key", None) or _env("PLLM_GATEWAY_API_KEY", "local"),
        )
    else:
        app = _configured_sidecar(settings, args)
    uvicorn.run(
        app,
        host=getattr(args, "host", "127.0.0.1"),
        port=getattr(args, "port", 8080),
        access_log=False,
    )


def _configured_sidecar(settings, args):
    return create_sidecar_app(
        remote_base_url=settings.base_url,
        remote_api_key=settings.api_key,
        local_api_key=getattr(args, "api_key", None) or _env("PLLM_GATEWAY_API_KEY", "local"),
        tenseal_path=getattr(args, "tenseal_path", None) or _env("PLLM_PYDEPS"),
        correlation_mode=settings.correlation_mode,
        preparation_base_url=settings.preparation_base_url,
        preparation_api_key=settings.preparation_api_key,
        session_transport=settings.transport,
        correlation_prefetch=settings.correlation_prefetch,
        prepared_inventory_rows=settings.prepared_inventory_rows,
        default_model=settings.model,
        token_cache_size=settings.token_cache_size,
        bundle_cache_mode=settings.bundle_cache_mode,
        bundle_cache_dir=settings.bundle_cache_dir,
        timeout=settings.timeout,
    )


def _is_loopback_host(host: str) -> bool:
    value = str(host).strip("[]")
    if value.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(value).is_loopback
    except ValueError:
        try:
            addresses = {
                item[4][0] for item in socket.getaddrinfo(value, None, type=socket.SOCK_STREAM)
            }
        except socket.gaierror:
            return False
        return bool(addresses) and all(ipaddress.ip_address(item).is_loopback for item in addresses)


def run_local_gateway(args: argparse.Namespace) -> None:
    """Run local inference/preparation process groups and gateway foreground."""

    def argument_or_default(name: str, default: Any) -> Any:
        value = getattr(args, name, None)
        return default if value is None else value

    experiment = getattr(args, "resolved_experiment", None)
    if experiment is not None:
        model = experiment
        model_id = None
    elif getattr(args, "tiny", False):
        source = str(args.model)
        model_id = getattr(args, "model_id", None) or "pllm-gateway-tiny"
        model = TinyModel(model_id=model_id)
    else:
        source = str(args.model)
        model_id = getattr(args, "model_id", None) or source
        model = Model.hf(
            source,
            model_id=model_id,
            revision=getattr(args, "revision", None),
            local_files_only=getattr(args, "local_files_only", False),
        )
    with build_roles(
        model,
        model_id=model_id,
        weight_bits=getattr(args, "weight_bits", None)
        if experiment is not None
        else argument_or_default("weight_bits", 8),
        activation_bits=getattr(args, "activation_bits", None)
        if experiment is not None
        else argument_or_default("activation_bits", 8),
        correlation_mode=argument_or_default("correlation_mode", "bfv"),
        tenseal_path=getattr(args, "tenseal_path", None),
        hf_cache_dir=getattr(args, "hf_cache_dir", None),
        reserved_ports=(args.port,),
    ) as topology:
        app = topology.gateway_app(
            local_api_key=getattr(args, "api_key", None) or _env("PLLM_GATEWAY_API_KEY", "local"),
            tenseal_path=getattr(args, "tenseal_path", None) or _env("PLLM_PYDEPS"),
            session_transport=argument_or_default("transport", "websocket"),
            correlation_prefetch=argument_or_default("correlation_prefetch", 4),
            prepared_inventory_rows=getattr(args, "prepared_inventory_rows", None),
            token_cache_size=argument_or_default("token_cache_size", 512),
            bundle_cache_mode=argument_or_default("bundle_cache_mode", "read-write"),
            bundle_cache_dir=getattr(args, "bundle_cache_dir", None),
            timeout=argument_or_default("timeout", 300.0),
        )
        uvicorn.run(
            app,
            host=getattr(args, "host", "127.0.0.1"),
            port=getattr(args, "port", 8080),
            access_log=False,
        )
