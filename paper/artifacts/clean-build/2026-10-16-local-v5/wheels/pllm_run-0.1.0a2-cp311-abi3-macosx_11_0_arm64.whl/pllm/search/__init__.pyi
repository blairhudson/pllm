from collections.abc import Callable, Iterable, Mapping, Sequence
from typing import Any

from pllm.configuration import Experiment
from pllm.evidence import BenchmarkResult
from pllm.search.placement import (
    ArtifactCostEvidence as ArtifactCostEvidence,
    CandidateCostEvidence as CandidateCostEvidence,
    ClientStateCostEvidence as ClientStateCostEvidence,
    PlanningPolicy as PlanningPolicy,
    PlanningRequest as PlanningRequest,
)

class SearchError(ValueError): ...

class Constraint:
    path: str
    operator: str
    value: Any
    def __init__(self, path: str, operator: str, value: Any) -> None: ...
    def accepts(self, experiment: Experiment) -> bool: ...

class SearchSpace:
    base: Experiment
    parameters: Mapping[str, tuple[Any, ...]]
    constraints: tuple[Constraint, ...]
    def __init__(
        self,
        base: Experiment,
        parameters: Mapping[str, Sequence[Any]],
        *,
        constraints: Iterable[Constraint] = ...,
    ) -> None: ...

class SearchCandidate:
    trial_id: str
    index: int
    experiment: Experiment
    parameters: Mapping[str, Any]
    configuration_digest: str
    def python_source(self) -> str: ...

class SearchEvaluation:
    candidate: SearchCandidate
    result: BenchmarkResult

class CandidateRejected(Exception):
    def __init__(self, reason: str) -> None: ...

class SearchRejection:
    parameters: Mapping[str, Any]
    reason: str
    candidate: SearchCandidate | None

class SearchOutcome:
    evaluations: tuple[SearchEvaluation, ...]
    rejections: tuple[SearchRejection, ...]
    best: SearchEvaluation | None
    objective: str
    direction: str
    stop_reason: str
    attempted: int
    def to_dict(self) -> dict[str, Any]: ...

class BeamSearch:
    identity: str
    space: SearchSpace
    objective: str
    direction: str
    width: int
    max_trials: int
    def __init__(
        self, identity: str, space: SearchSpace, objective: str, direction: str,
        width: int = ..., max_trials: int = ...,
    ) -> None: ...
    def evaluate(
        self, evaluator: Callable[[SearchCandidate], BenchmarkResult], *,
        admit: Callable[[SearchCandidate], str | None] | None = ...,
    ) -> SearchOutcome: ...

class GridSearch:
    identity: str
    space: SearchSpace
    def __init__(self, identity: str, space: SearchSpace) -> None: ...
    def candidates(self) -> tuple[SearchCandidate, ...]: ...
    def evaluate(
        self, evaluator: Callable[[SearchCandidate], BenchmarkResult]
    ) -> tuple[SearchEvaluation, ...]: ...

class RandomSearch:
    identity: str
    space: SearchSpace
    count: int
    seed: int
    def __init__(
        self, identity: str, space: SearchSpace, *, count: int, seed: int
    ) -> None: ...
    def candidates(self) -> tuple[SearchCandidate, ...]: ...
    def evaluate(
        self, evaluator: Callable[[SearchCandidate], BenchmarkResult]
    ) -> tuple[SearchEvaluation, ...]: ...

class ParetoFrontier:
    objectives: Mapping[str, str]
    def __init__(
        self,
        evaluations: Iterable[SearchEvaluation],
        *,
        objectives: Mapping[str, str],
    ) -> None: ...
    def results(self) -> tuple[SearchEvaluation, ...]: ...
    def excluded(self) -> tuple[SearchEvaluation, ...]: ...

class QualityLockedNetworkSearch:
    minimum_top1_agreement: float
    minimum_top_k_recall: float
    maximum_abs_logit_error: float
    def __init__(
        self, minimum_top1_agreement: float, minimum_top_k_recall: float,
        maximum_abs_logit_error: float,
    ) -> None: ...
    def select(
        self, quality_report: Mapping[str, Any],
        candidates: Sequence[tuple[Experiment, Mapping[str, Any]]],
    ) -> dict[str, Any]: ...

def evaluate_search(
    candidates: Iterable[SearchCandidate],
    evaluator: Callable[[SearchCandidate], BenchmarkResult],
) -> tuple[SearchEvaluation, ...]: ...

def optimization_space(
    experiment: Experiment, *, allow_client_weights: bool = False,
    client_prefix_layers: tuple[int, ...] = (),
    prefix_cache_bytes: int = 0, metal_min_rows: int | None = None,
    component_choices: dict[str, tuple[Any, ...]] | None = None,
    max_candidates: int = 64,
) -> SearchSpace: ...
from pllm.search.frontier import FrontierStudy as FrontierStudy, FrontierWork as FrontierWork, Variant as Variant
