//! Independent BGI early-terminated Boolean DPF and Grotto parity comparison.
//! BGI 2016 Figure 1 / §3.2.3; Grotto §5–6; SIGMA §2.5–2.6.
//! Seeds retain 128 secret bits; control bits are separate (SIGMA uses 127).
//! Internal reusable key algebra, never a public reusable protocol handle.

use aes::cipher::{BlockEncrypt, KeyInit};
use aes::Aes128;
use zeroize::{Zeroize, Zeroizing};

pub(crate) struct Bits {
    pub data: Zeroizing<Vec<u8>>,
    pub len: usize,
}

pub(crate) trait BitSink {
    fn put(&mut self, value: u128, width: usize);
    fn random(&mut self, value: u128, width: usize, _parties: RandomField) {
        self.put(value, width);
    }
}

#[derive(Clone, Copy)]
pub(crate) enum RandomField {
    BothParties,
    FirstParty,
}

pub(crate) trait BitSource {
    fn take(&mut self, width: usize) -> Result<u128, DecodeError>;
    fn random(&mut self, width: usize, _parties: RandomField) -> Result<u128, DecodeError> {
        self.take(width)
    }
}

#[derive(Default)]
pub(crate) struct BitCount(pub usize);

impl BitSink for BitCount {
    fn put(&mut self, _value: u128, width: usize) {
        self.0 += width;
    }
}

impl Bits {
    pub fn new() -> Self {
        Self {
            data: Zeroizing::new(Vec::new()),
            len: 0,
        }
    }
}

impl BitSink for Bits {
    fn put(&mut self, value: u128, width: usize) {
        for i in 0..width {
            if self.len % 8 == 0 {
                self.data.push(0);
            }
            self.data[self.len / 8] |= (((value >> i) & 1) as u8) << (self.len % 8);
            self.len += 1;
        }
    }
}

#[derive(Debug)]
pub(crate) struct DecodeError;

/// Exact-length, canonical bit reader for authenticated party-local material.
pub(crate) struct BitReader<'a> {
    bytes: &'a [u8],
    bits: usize,
    position: usize,
}

impl<'a> BitReader<'a> {
    pub fn new(bytes: &'a [u8], bits: usize) -> Result<Self, DecodeError> {
        if bytes.len() != bits.div_ceil(8)
            || (bits % 8 != 0 && bytes.last().is_some_and(|b| *b >> (bits % 8) != 0))
        {
            return Err(DecodeError);
        }
        Ok(Self {
            bytes,
            bits,
            position: 0,
        })
    }

    pub fn take(&mut self, width: usize) -> Result<u128, DecodeError> {
        let end = self.position.checked_add(width).ok_or(DecodeError)?;
        if !(1..=128).contains(&width) || end > self.bits {
            return Err(DecodeError);
        }
        let mut value = 0;
        for i in 0..width {
            let index = self.position + i;
            value |= u128::from((self.bytes[index / 8] >> (index % 8)) & 1) << i;
        }
        self.position = end;
        Ok(value)
    }

    pub fn finish(self) -> Result<(), DecodeError> {
        if self.position == self.bits {
            Ok(())
        } else {
            Err(DecodeError)
        }
    }
}

impl BitSource for BitReader<'_> {
    fn take(&mut self, width: usize) -> Result<u128, DecodeError> {
        self.take(width)
    }
}

struct Correction {
    seed: u128,
    control: [u8; 2],
}
impl Drop for Correction {
    fn drop(&mut self) {
        self.seed.zeroize();
        self.control.zeroize();
    }
}

pub(crate) struct Key {
    bits: u8,
    root: u128,
    words: Vec<Correction>,
    leaf: u128,
}
impl Drop for Key {
    fn drop(&mut self) {
        self.root.zeroize();
        self.leaf.zeroize();
    }
}

fn random() -> Result<u128, getrandom::Error> {
    let mut b = Zeroizing::new([0; 16]);
    getrandom::fill(&mut *b)?;
    Ok(u128::from_le_bytes(*b))
}

// AES-CTR under the seed. Distinct counter 2 supplies control bits without
// taking bits out of the secret seed. Single-path traversal needs two blocks;
// paired expansion below shares the key schedule and control block.
fn child(seed: u128, branch: usize) -> (u128, u8) {
    let cipher = Aes128::new(&seed.to_le_bytes().into());
    let mut block = (branch as u128).to_le_bytes().into();
    let mut flags = 2u128.to_le_bytes().into();
    cipher.encrypt_block(&mut block);
    cipher.encrypt_block(&mut flags);
    (u128::from_le_bytes(block.into()), (flags[0] >> branch) & 1)
}

fn children(seed: u128) -> [(u128, u8); 2] {
    // Identical AES(seed, 0/1/2) PRG words. No expansion crosses a seed boundary.
    let cipher = Aes128::new(&seed.to_le_bytes().into());
    let mut blocks = [
        0u128.to_le_bytes().into(),
        1u128.to_le_bytes().into(),
        2u128.to_le_bytes().into(),
    ];
    cipher.encrypt_blocks(&mut blocks);
    [
        (u128::from_le_bytes(blocks[0].into()), blocks[2][0] & 1),
        (
            u128::from_le_bytes(blocks[1].into()),
            (blocks[2][0] >> 1) & 1,
        ),
    ]
}

impl Key {
    pub fn encoded_bits(bits: u8) -> usize {
        if bits <= 7 {
            1usize << bits
        } else {
            256 + 130 * usize::from(bits - 7)
        }
    }

    pub fn issue(bits: u8, point: u64) -> Result<[Self; 2], getrandom::Error> {
        Self::issue_with(bits, point, |_| random())
    }

    pub fn issue_with(
        bits: u8,
        point: u64,
        mut random: impl FnMut(usize) -> Result<u128, getrandom::Error>,
    ) -> Result<[Self; 2], getrandom::Error> {
        assert!((1..=63).contains(&bits) && point < 1u64 << bits);
        if bits <= 7 {
            let mask = if bits == 7 {
                u128::MAX
            } else {
                (1u128 << (1 << bits)) - 1
            };
            let left = random(0)? & mask;
            return Ok([left, left ^ (1u128 << point)].map(|leaf| Self {
                bits,
                root: 0,
                words: vec![],
                leaf,
            }));
        }
        let roots = Zeroizing::new([random(0)?, random(1)?]);
        let mut seeds = Zeroizing::new(*roots);
        let mut controls = [0u8, 1];
        let mut words = [Vec::new(), Vec::new()];
        for level in (7..bits).rev() {
            let keep = ((point >> level) & 1) as usize;
            let a = children(seeds[0]);
            let b = children(seeds[1]);
            let seed = a[1 - keep].0 ^ b[1 - keep].0;
            let cw = [
                a[0].1 ^ b[0].1 ^ keep as u8 ^ 1,
                a[1].1 ^ b[1].1 ^ keep as u8,
            ];
            for party in 0..2 {
                let expanded = if party == 0 { a } else { b };
                let flag = u128::from(controls[party]);
                seeds[party] = expanded[keep].0 ^ (seed & 0u128.wrapping_sub(flag));
                controls[party] = expanded[keep].1 ^ (cw[keep] & flag as u8);
                words[party].push(Correction { seed, control: cw });
            }
        }
        // Identity Convert into 128 Boolean output bits; no seed entropy is
        // discarded. Matching off-path seeds/control cancel in both keys.
        let leaf = seeds[0] ^ seeds[1] ^ (1u128 << (point & 127));
        let [left, right] = words;
        Ok([
            Self {
                bits,
                root: roots[0],
                words: left,
                leaf,
            },
            Self {
                bits,
                root: roots[1],
                words: right,
                leaf,
            },
        ])
    }

    fn descend(&self, level: usize, seed: u128, flag: u8, branch: usize) -> (u128, u8) {
        let (next, control) = child(seed, branch);
        let cw = &self.words[level];
        (
            next ^ (cw.seed & 0u128.wrapping_sub(u128::from(flag))),
            control ^ (flag & cw.control[branch]),
        )
    }

    pub fn point(&self, party: u8, input: u64) -> u8 {
        assert!(party <= 1 && input < 1u64 << self.bits);
        if self.bits <= 7 {
            return ((self.leaf >> input) & 1) as u8;
        }
        let (mut seed, mut flag) = (self.root, party);
        for i in 0..self.words.len() {
            (seed, flag) = self.descend(
                i,
                seed,
                flag,
                ((input >> (self.bits as usize - 1 - i)) & 1) as usize,
            );
        }
        (((seed ^ (self.leaf & 0u128.wrapping_sub(u128::from(flag)))) >> (input & 127)) & 1) as u8
    }

    /// XOR shares of input < point. Grotto suffix parity with one traversed
    /// child per level: a right-subtree parity is parent XOR left-child.
    pub fn less(&self, party: u8, input: u64) -> u8 {
        assert!(party <= 1 && input < 1u64 << self.bits);
        let (mut seed, mut flag, mut parity) = (self.root, party, 0);
        if self.bits > 7 {
            for i in 0..self.words.len() {
                let branch = ((input >> (self.bits as usize - 1 - i)) & 1) as usize;
                let (next, control) = self.descend(i, seed, flag, branch);
                parity ^= (flag ^ control) & (1 ^ branch as u8);
                (seed, flag) = (next, control);
            }
        }
        let leaf = if self.bits <= 7 {
            self.leaf
        } else {
            seed ^ (self.leaf & 0u128.wrapping_sub(u128::from(flag)))
        };
        let shift = (input & 127) + 1;
        parity
            ^ if shift == 128 {
                0
            } else {
                ((leaf >> shift).count_ones() & 1) as u8
            }
    }

    /// Bounded full-domain expansion, one visit per tree edge. Lookup parties
    /// perform all public table work; there is no secret-indexed memory query.
    pub fn all(&self, party: u8) -> Zeroizing<Vec<u8>> {
        assert!(self.bits <= 10 && party <= 1);
        fn walk(key: &Key, depth: usize, seed: u128, flag: u8, out: &mut Vec<u8>) {
            if depth == key.words.len() {
                let leaf = seed ^ (key.leaf & 0u128.wrapping_sub(u128::from(flag)));
                out.extend((0..128).map(|i| ((leaf >> i) & 1) as u8));
            } else {
                let cw = &key.words[depth];
                let enabled = 0u128.wrapping_sub(flag.into());
                for (branch, (s, t)) in children(seed).into_iter().enumerate() {
                    let s = s ^ (cw.seed & enabled);
                    let t = t ^ (cw.control[branch] & flag);
                    walk(key, depth + 1, s, t, out);
                }
            }
        }
        let mut out = Zeroizing::new(Vec::with_capacity(1 << self.bits));
        if self.bits <= 7 {
            out.extend((0..1 << self.bits).map(|i| ((self.leaf >> i) & 1) as u8));
        } else {
            walk(self, 0, self.root, party, &mut out);
        }
        out
    }

    pub fn encode(&self, output: &mut impl BitSink) {
        if self.bits <= 7 {
            output.random(self.leaf, 1 << self.bits, RandomField::FirstParty);
        } else {
            output.random(self.root, 128, RandomField::BothParties);
            for cw in &self.words {
                output.put(cw.seed, 128);
                output.put(u128::from(cw.control[0]), 1);
                output.put(u128::from(cw.control[1]), 1);
            }
            output.put(self.leaf, 128);
        }
    }

    pub fn decode(bits: u8, input: &mut impl BitSource) -> Result<Self, DecodeError> {
        if !(1..=63).contains(&bits) {
            return Err(DecodeError);
        }
        if bits <= 7 {
            return Ok(Self {
                bits,
                root: 0,
                words: vec![],
                leaf: input.random(1 << bits, RandomField::FirstParty)?,
            });
        }
        let root = Zeroizing::new(input.random(128, RandomField::BothParties)?);
        let mut words = Vec::with_capacity(usize::from(bits - 7));
        for _ in 7..bits {
            words.push(Correction {
                seed: input.take(128)?,
                control: [input.take(1)? as u8, input.take(1)? as u8],
            });
        }
        Ok(Self {
            bits,
            root: *root,
            words,
            leaf: input.take(128)?,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn paired_children_preserve_every_prg_word() {
        for seed in [0, u128::MAX, 0x123456789abcdef0fedcba9876543210]
            .into_iter()
            .chain((0..128).map(|bit| 1u128 << bit))
        {
            assert_eq!(children(seed), [child(seed, 0), child(seed, 1)]);
        }
    }

    #[test]
    fn exhaustive_small_points_and_parities_and_tree_boundaries() {
        for bits in 1..=10 {
            let points: Vec<_> = if bits <= 7 {
                (0..1u64 << bits).collect()
            } else {
                vec![0, 1, 126, 127, 128, 129, (1 << bits) - 1]
            };
            for point in points {
                let keys = Key::issue(bits, point).unwrap();
                let all = [keys[0].all(0), keys[1].all(1)];
                for x in 0..1 << bits {
                    assert_eq!(
                        keys[0].point(0, x) ^ keys[1].point(1, x),
                        u8::from(x == point)
                    );
                    assert_eq!(keys[0].less(0, x) ^ keys[1].less(1, x), u8::from(x < point));
                    for b in 0..2 {
                        assert_eq!(all[b][x as usize], keys[b].point(b as u8, x));
                    }
                }
                let mut encoded = Bits::new();
                keys[0].encode(&mut encoded);
                assert_eq!(encoded.len, Key::encoded_bits(bits));
            }
        }
    }

    #[test]
    fn wide_comparisons_do_not_expand_the_domain() {
        for bits in [12, 25, 32, 40, 63] {
            for p in [
                0,
                1,
                (1 << (bits - 1)) - 1,
                1 << (bits - 1),
                (1 << bits) - 1,
            ] {
                let k = Key::issue(bits, p).unwrap();
                for x in [
                    0,
                    p.saturating_sub(1),
                    p,
                    (p + 1) & ((1 << bits) - 1),
                    (1 << bits) - 1,
                ] {
                    assert_eq!(k[0].less(0, x) ^ k[1].less(1, x), u8::from(x < p));
                    assert_eq!(k[0].point(0, x) ^ k[1].point(1, x), u8::from(x == p));
                }
            }
        }
    }

    #[test]
    fn canonical_material_roundtrips_and_rejects_truncation_and_padding() {
        for width in [1, 7, 8, 10, 12, 30, 63] {
            let point = (1u64 << width) - 2;
            let keys = Key::issue(width, point).unwrap();
            for (party, key) in keys.iter().enumerate() {
                let mut out = Bits::new();
                key.encode(&mut out);
                let mut count = BitCount::default();
                key.encode(&mut count);
                assert_eq!(count.0, out.len);
                let mut reader = BitReader::new(&out.data, out.len).unwrap();
                let restored = Key::decode(width, &mut reader).unwrap();
                reader.finish().unwrap();
                for x in [0, point - u64::from(point > 0), point, point + 1] {
                    assert_eq!(restored.less(party as u8, x), key.less(party as u8, x));
                    assert_eq!(restored.point(party as u8, x), key.point(party as u8, x));
                }
                assert!(BitReader::new(&out.data[..out.data.len() - 1], out.len).is_err());
                if out.len % 8 != 0 {
                    *out.data.last_mut().unwrap() |= 0x80;
                    assert!(BitReader::new(&out.data, out.len).is_err());
                }
            }
        }
    }
}
