from __future__ import annotations

from abc import ABC, abstractmethod
from importlib import import_module
from typing import TYPE_CHECKING, Any

from pllm.configuration import ComponentDescriptor, ComponentRef, ConfigurationError
from pllm.components._planned import install_planned_components

if TYPE_CHECKING:
    from pllm.runtime.correction_batch import CorrectionBatch, CorrectionTicket
    from pllm.runtime.preparation_protocol import PreparationRequest
    from pllm.runtime.preparation_server import create_preparation_app as create_preparation_app


class PreparationProvider(ComponentRef, ABC):
    __slots__ = ()

    @classmethod
    @abstractmethod
    def describe(cls) -> ComponentDescriptor: ...


class ModelAwareCorrections(PreparationProvider):
    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/model-aware-corrections",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/preparation-provider",
        category_version="1",
        lifecycle_phase="preparation",
        parameter_schema={"type": "object", "additionalProperties": False,
                          "properties": {"storage": {"type": "string", "enum": ["paged"]},
                                         "kernel": {"type": "string", "enum": ["digit8"]},
                                         "min_rows": {"type": "integer", "minimum": 1, "maximum": 4096}}},
        capabilities=("one-use-masked-linear-corrections",),
        role_eligibility=("preparation",),
    )

    def __init__(self, *, storage: str = "resident", kernel: str = "native", min_rows: int = 64) -> None:
        if type(storage) is not str or storage not in {"resident", "paged"}:
            raise ConfigurationError("preparation storage must be resident or paged")
        if type(kernel) is not str or kernel not in {"native", "digit8"}:
            raise ConfigurationError("preparation kernel must be native or digit8")
        if type(min_rows) is not int or not 1 <= min_rows <= 4096 or (kernel == "native" and min_rows != 64):
            raise ConfigurationError("digit8 threshold must be in [1,4096] and requires digit8")
        params = {} if storage == "resident" else {"storage": storage}
        if kernel != "native":
            params.update(kernel=kernel, min_rows=min_rows)
        super().__init__(self.descriptor.component, params)

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {"storage": "resident", "kernel": "native", "min_rows": 64, **self.params}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


def validate_decode_epoch_schedule(value: object) -> tuple[int, ...]:
    """Normalize a bounded public policy; never derive sizes from private state."""
    if (not isinstance(value, (tuple, list)) or not 1 <= len(value) <= 64
            or any(type(size) is not int or not 1 <= size <= 64 for size in value)
            or any(left > right for left, right in zip(value, value[1:]))):
        raise ConfigurationError("decode_epoch_schedule requires 1–64 nondecreasing integer sizes in [1, 64]")
    return tuple(value)


class PreparedInventory(ComponentRef):
    """Client inventory floor and startup policy; rows remain strictly one-use."""

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/prepared-inventory-policy/v1",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/inventory-policy",
        category_version="1",
        lifecycle_phase="offline",
        parameter_schema={
            "type": "object",
            "required": ["policy", "rows"],
            "additionalProperties": False,
            "properties": {
                "policy": {"type": "string", "enum": ["prewarm", "request-sized"]},
                "rows": {"type": "integer", "minimum": 1, "maximum": 4096},
                "refill": {"type": "string", "enum": ["idle", "on-demand"]},
                "stage_window": {"type": "integer", "minimum": 1, "maximum": 4},
                "stage_window_bytes": {"type": "integer", "minimum": 1048576, "maximum": 67108864},
                "allocation": {"type": "string", "enum": ["demand"]},
                "decode_epoch_tokens": {"type": "integer", "minimum": 1, "maximum": 64},
                "decode_epoch_schedule": {"type": "array", "minItems": 1, "maxItems": 64,
                                          "items": {"type": "integer", "minimum": 1, "maximum": 64}},
            },
            "allOf": [{
                "if": {"anyOf": [{"required": ["decode_epoch_tokens"]}, {"required": ["decode_epoch_schedule"]}]},
                "then": {"required": ["allocation", "refill"], "properties": {
                    "policy": {"const": "request-sized"}, "rows": {"const": 1},
                    "allocation": {"const": "demand"}, "refill": {"const": "on-demand"},
                }},
            }, {"not": {"required": ["decode_epoch_tokens", "decode_epoch_schedule"]}}],
        },
        capabilities=("bounded-prepared-inventory", "request-sized-preparation"),
        role_eligibility=("client", "preparation", "inference"),
    )

    def __init__(self, policy: str = "request-sized", *, rows: int | None = None, refill: str | None = None,
                 stage_window: int = 1, allocation: str = "uniform",
                 stage_window_bytes: int = 16 << 20, decode_epoch_tokens: int | None = None,
                 decode_epoch_schedule: tuple[int, ...] | list[int] | None = None) -> None:
        if policy not in {"prewarm", "request-sized"}:
            raise ConfigurationError("inventory policy must be prewarm or request-sized")
        if rows is None:
            rows = 1 if policy == "request-sized" else 64
        if type(rows) is not int or not 1 <= rows <= 4096:
            raise ConfigurationError("inventory row floor must be in [1, 4096]")
        if type(stage_window) is not int or not 1 <= stage_window <= 4:
            raise ConfigurationError("preparation stage window must be in [1, 4]")
        if (type(stage_window_bytes) is not int or not 1 << 20 <= stage_window_bytes <= 64 << 20
                or (stage_window == 1 and stage_window_bytes != 16 << 20)):
            raise ConfigurationError("preparation work window requires 1–64 MiB and concurrent stages")
        if allocation not in {"uniform", "demand"} or (allocation == "demand" and
            (policy != "request-sized" or rows != 1 or refill != "on-demand")):
            raise ConfigurationError("demand allocation requires request-sized rows=1 and on-demand refill")
        params = {"policy": policy, "rows": rows}
        if decode_epoch_schedule is not None:
            if decode_epoch_tokens is not None:
                raise ConfigurationError("fixed and scheduled decode epochs are mutually exclusive")
            schedule = validate_decode_epoch_schedule(decode_epoch_schedule)
            if policy != "request-sized" or rows != 1 or allocation != "demand" or refill != "on-demand":
                raise ConfigurationError("decode epochs require request-sized rows=1, demand allocation and on-demand refill")
            params["decode_epoch_schedule"] = schedule
        if decode_epoch_tokens is not None:
            if type(decode_epoch_tokens) is not int or not 1 <= decode_epoch_tokens <= 64:
                raise ConfigurationError("decode_epoch_tokens must be an integer in [1, 64]")
            if policy != "request-sized" or rows != 1 or allocation != "demand" or refill != "on-demand":
                raise ConfigurationError("decode epochs require request-sized rows=1, demand allocation and on-demand refill")
            params["decode_epoch_tokens"] = decode_epoch_tokens
        if refill is not None:
            if refill not in {"idle", "on-demand"}:
                raise ConfigurationError("inventory refill must be idle or on-demand")
            params["refill"] = refill
        if stage_window != 1:
            params["stage_window"] = stage_window
        if stage_window_bytes != 16 << 20:
            params["stage_window_bytes"] = stage_window_bytes
        if allocation != "uniform":
            params["allocation"] = allocation
        super().__init__(self.descriptor.component, params)

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {"stage_window": 1, "stage_window_bytes": 16 << 20, "allocation": "uniform",
                "decode_epoch_tokens": None, "decode_epoch_schedule": None, **self.params}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class BFVCorrelations(PreparationProvider):
    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/bfv-correlations/v1",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/preparation-provider",
        category_version="1",
        lifecycle_phase="preparation",
        parameter_schema={
            "type": "object",
            "properties": {
                "poly_modulus_degree": {"type": "integer", "enum": [4096, 8192, 16384]},
            },
            "required": ["poly_modulus_degree"],
            "additionalProperties": False,
        },
        capabilities=("bfv-correlation-generation",),
        required_host_features=("tenseal-backend",),
        role_eligibility=("client", "preparation"),
    )

    def __init__(self, *, poly_modulus_degree: int = 4096) -> None:
        if poly_modulus_degree not in {4096, 8192, 16384} or type(poly_modulus_degree) is not int:
            raise ConfigurationError("poly_modulus_degree must be 4096, 8192, or 16384")
        super().__init__(
            self.descriptor.component,
            {"poly_modulus_degree": poly_modulus_degree},
        )

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {"poly_modulus_degree": self.params["poly_modulus_degree"]}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class HEAuthenticatedPreprocessing(PreparationProvider):
    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/he-authenticated-preprocessing",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/preparation-provider",
        category_version="1",
        lifecycle_phase="preparation",
        parameter_schema={
            "type": "object",
            "properties": {
                "poly_modulus_degree": {"type": "integer", "enum": [4096, 8192, 16384]},
                "threads": {"type": "integer", "minimum": 1},
                "enable_linear_correlations": {"type": "boolean"},
            },
            "required": ["poly_modulus_degree", "threads", "enable_linear_correlations"],
            "additionalProperties": False,
        },
        capabilities=("he-authenticated-preprocessing",),
        required_host_features=("tenseal-backend",),
        role_eligibility=("client", "preparation"),
    )

    def __init__(
        self,
        *,
        poly_modulus_degree: int = 4096,
        threads: int = 1,
        enable_linear_correlations: bool = True,
    ) -> None:
        if poly_modulus_degree not in {4096, 8192, 16384} or type(poly_modulus_degree) is not int:
            raise ConfigurationError("poly_modulus_degree must be 4096, 8192, or 16384")
        if type(threads) is not int or threads < 1:
            raise ConfigurationError("threads must be an integer >= 1")
        if type(enable_linear_correlations) is not bool:
            raise ConfigurationError("enable_linear_correlations must be a bool")
        super().__init__(
            self.descriptor.component,
            {
                "poly_modulus_degree": poly_modulus_degree,
                "threads": threads,
                "enable_linear_correlations": enable_linear_correlations,
            },
        )

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return dict(self.params)

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


__all__ = [
    "CorrectionBatch",
    "CorrectionTicket",
    "PreparationRequest",
    "BFVCorrelations",
    "HEAuthenticatedPreprocessing",
    "ModelAwareCorrections",
    "PreparationProvider",
    "PreparedInventory",
    "create_preparation_app",
]

install_planned_components(globals())


def __getattr__(name: str) -> Any:
    if name in {"CorrectionBatch", "CorrectionTicket", "PreparationRequest"}:
        module = "preparation_protocol" if name == "PreparationRequest" else "correction_batch"
        value = getattr(import_module(f"pllm.runtime.{module}"), name)
        globals()[name] = value
        return value
    if name != "create_preparation_app":
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = import_module("pllm.runtime.preparation_server").create_preparation_app
    globals()[name] = value
    return value
