"""Public nonlinear protocol component declarations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import TYPE_CHECKING

from pllm.configuration import ComponentDescriptor, ComponentRef, ConfigurationError
from pllm.components._planned import PendingComponent as PendingMethod, install_planned_components, planned as pending
from pllm.components._q7_activation import parameter_schema as _q7_schema, parameters as _q7_parameters

if TYPE_CHECKING:
    from pllm._native import CompactQ7Reference, ScaledSiluQ7Reference


class NonlinearProtocol(ComponentRef, ABC):
    __slots__ = ()

    @classmethod
    @abstractmethod
    def describe(cls) -> ComponentDescriptor: ...


class PackedEncryptedSoftmax(NonlinearProtocol):
    """Narrow public-range CKKS normalization, available as operator benchmarks."""

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/packed-encrypted-softmax/v1", provider="pllm", distribution="pllm.run",
        version="1", category="pllm/nonlinear-protocol", category_version="1", lifecycle_phase="runtime",
        parameter_schema={"type": "object", "additionalProperties": False,
            "properties": {"method": {"enum": ["repeated_squaring", "square_normalize"]}},
            "required": ["method"]},
        capabilities=("packed-ckks-softmax-reference", "bounded-operator-benchmark"),
        required_host_features=("native-core", "seal"), role_eligibility=("client", "inference"),
    )

    def __init__(self, *, method: str = "repeated_squaring") -> None:
        if method not in ("repeated_squaring", "square_normalize"):
            raise ConfigurationError("method must be repeated_squaring or square_normalize")
        super().__init__(self.descriptor.component, {"method": method})

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return self.to_spec()["params"]

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class ArithmeticGarblingSiluQ7(NonlinearProtocol):
    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/arithmetic-garbling-silu-q7/v1",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/nonlinear-protocol",
        category_version="1",
        lifecycle_phase="runtime",
        parameter_schema={"type": "object", "additionalProperties": False},
        capabilities=("protected-silu-q7",),
        required_host_features=("native-core",),
        role_eligibility=("client", "inference"),
    )

    def __init__(self) -> None:
        super().__init__(self.descriptor.component)

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class BinaryTableGatedMultiplyQ7(NonlinearProtocol):
    """Binary-table implementation of protected Q7 ``SiLU(gate) * up``."""

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/binary-table/v1",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/nonlinear-protocol",
        category_version="1",
        lifecycle_phase="compilation",
        parameter_schema={"type": "object", "additionalProperties": False},
        capabilities=("protected-gated-multiply-q7",),
        required_host_features=("decoder-plan-v1", "signed-q7"),
        role_eligibility=("client", "inference"),
    )

    def __init__(self) -> None:
        super().__init__(self.descriptor.component)

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class R03CrtGatedMultiplyQ7(NonlinearProtocol):
    """R03 CRT implementation of protected Q7 ``SiLU(gate) * up``."""

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/r03-crt/v1",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/nonlinear-protocol",
        category_version="1",
        lifecycle_phase="compilation",
        parameter_schema={"type": "object", "additionalProperties": False},
        capabilities=("protected-gated-multiply-q7",),
        required_host_features=("decoder-plan-v1", "signed-q7"),
        role_eligibility=("client", "inference"),
    )

    def __init__(self) -> None:
        super().__init__(self.descriptor.component)

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class MaskedWireGatedMultiplyQ12(NonlinearProtocol):
    """SIGMA-derived masked-wire ``SiLU(gate) * up`` with signed Q24 inputs.

    Gate and up ranges are [-48, 48] and [-128, 128]. The fixed residual
    table and floor shifts produce Q12 output. ``layout="fused"`` computes the
    input gate shifts and predicates through public masked views, preserving
    the numeric contract. Operator benchmarks use a local dealer. The CPU
    two-offset Experiment uses client-issued material and authenticated
    party-local workers, with peer frames relayed through the trusted client.
    ``dispatch="overlap"`` overlaps one future chunk's issuance with paired
    worker requests, retaining at most two client material chunks.
    ``material_encoding="seeded"`` replaces each worker's independent random
    key fields with one fresh party-local seed. Client wire masks stay private;
    correlated corrections remain explicit and expanded memory stays bounded.
    """

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/masked-wire-gated-multiply-q12/v1",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/nonlinear-protocol",
        category_version="1",
        lifecycle_phase="runtime",
        parameter_schema={
            "type": "object", "properties": {
                "layout": {"enum": ["unfused", "fused"]},
                "dispatch": {"enum": ["serial", "overlap"]},
                "material_encoding": {"enum": ["full", "seeded"]},
            },
            "additionalProperties": False,
        },
        capabilities=("protected-gated-multiply-q12", "bounded-operator-benchmark", "compiled-gated-regions"),
        required_host_features=("native-core", "trusted-client-fss-dealer"),
        role_eligibility=("client", "worker_a", "worker_b"),
    )

    def __init__(self, *, layout: str = "unfused", dispatch: str = "serial", material_encoding: str = "full") -> None:
        if type(layout) is not str or layout not in {"unfused", "fused"}:
            raise ConfigurationError("layout must be unfused or fused")
        if type(dispatch) is not str or dispatch not in {"serial", "overlap"}:
            raise ConfigurationError("dispatch must be serial or overlap")
        if type(material_encoding) is not str or material_encoding not in {"full", "seeded"}:
            raise ConfigurationError("material_encoding must be full or seeded")
        # Preserve the original default component and historical configurations.
        params = {} if layout == "unfused" else {"layout": layout}
        if dispatch != "serial":
            params["dispatch"] = dispatch
        if material_encoding != "full":
            params["material_encoding"] = material_encoding
        super().__init__(self.descriptor.component, params)

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {"layout": self.params.get("layout", "unfused"), "dispatch": self.params.get("dispatch", "serial"),
                "material_encoding": self.params.get("material_encoding", "full")}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class SharedRescale(NonlinearProtocol):
    """Signed shared rescaling and the original input's nonnegative predicate.

    The fused/unfused layouts share one numeric contract and comparison
    backend. Floor and the ties-even extension have distinct numeric identities.
    Bounded operator execution uses a local dealer and two one-use evaluators.
    """

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/shared-rescale/v1",
        provider="pllm",
        distribution="pllm.run",
        version="1",
        category="pllm/nonlinear-protocol",
        category_version="1",
        lifecycle_phase="runtime",
        parameter_schema={
            "type": "object",
            "properties": {
                "bits": {"type": "integer", "minimum": 2, "maximum": 32},
                "shift": {"type": "integer", "minimum": 1, "maximum": 31},
                "rounding": {"enum": ["floor", "ties_even"]},
                "layout": {"enum": ["fused", "unfused"]},
                "backend": {"enum": ["prefix_dpf", "compact_dcf", "interval_dcf"]},
            },
            "required": ["bits", "shift", "rounding", "layout", "backend"],
            "additionalProperties": False,
        },
        capabilities=("protected-signed-rescale", "original-input-nonnegative", "bounded-operator-benchmark"),
        required_host_features=("native-core", "local-fss-dealer"),
        role_eligibility=("client",),
    )

    def __init__(
        self,
        *,
        bits: int = 16,
        shift: int = 7,
        rounding: str = "floor",
        layout: str = "fused",
        backend: str = "interval_dcf",
    ) -> None:
        if type(bits) is not int or not 2 <= bits <= 32:
            raise ConfigurationError("bits must be an integer in [2, 32]")
        if type(shift) is not int or not 1 <= shift < bits:
            raise ConfigurationError("shift must be an integer in [1, bits)")
        for name, value, choices in (
            ("rounding", rounding, {"floor", "ties_even"}),
            ("layout", layout, {"fused", "unfused"}),
            ("backend", backend, {"prefix_dpf", "compact_dcf", "interval_dcf"}),
        ):
            if type(value) is not str or value not in choices:
                raise ConfigurationError(f"{name} must be one of {sorted(choices)}")
        super().__init__(
            self.descriptor.component,
            {"bits": bits, "shift": shift, "rounding": rounding, "layout": layout, "backend": backend},
        )

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return self.to_spec()["params"]

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


__all__ = [
    "ArithmeticGarblingSiluQ7",
    "BinaryTableGatedMultiplyQ7",
    "NonlinearProtocol",
    "R03CrtGatedMultiplyQ7",
    "MaskedWireGatedMultiplyQ12",
    "SharedRescale",
]


@pending("shaft")
class ShaftFixedPointTransformerOps(PendingMethod):
    pass


class CompactPiecewiseActivation(NonlinearProtocol):
    """Publicly calibrated Q7 SiLU with private half-gates polynomial evaluation.

    The bounded operator accepts encoded inputs in [-128, 128]. Calibration
    counts must come from public offline data; the default is uniform. This
    CPU adaptation evaluates selection and Chebyshev arithmetic together.
    """

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/compact-piecewise-activation-q7/v1", provider="pllm",
        distribution="pllm.run", version="1", category="pllm/nonlinear-protocol",
        category_version="1", lifecycle_phase="runtime", parameter_schema=_q7_schema(),
        capabilities=("protected-silu-q7", "bounded-operator-benchmark"),
        required_host_features=("native-core", "local-garbler"),
        role_eligibility=("client", "inference"),
    )

    def __init__(self, *, max_pieces: int = 4,
                 public_calibration_counts: Sequence[int] | None = None) -> None:
        super().__init__(self.descriptor.component, _q7_parameters(max_pieces, public_calibration_counts))

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return self.to_spec()["params"]

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class CompactGatedMultiplyQ12(NonlinearProtocol):
    """Complete SiLU×up with public-density-weighted Chebyshev pieces.

    Q18 gate/up inputs have fixed public ranges ±48/±128. The Q12 profile
    has zero/identity tails at ±8 and exact ties-even arithmetic. Public
    calibration supplies 1,024 bin counts over [-8,8), or uniform defaults.
    Dyadic refinement replaces Compact's annealing. Private selection,
    polynomial evaluation and multiplication default to a fresh half-gates
    circuit. ``backend="mixed"`` uses arithmetic products with exact garbled
    rounding and dealer-aided conversions, preserving the numeric profile.
    """

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/compact-gated-multiply-q12/v1", provider="pllm",
        distribution="pllm.run", version="1", category="pllm/nonlinear-protocol",
        category_version="1", lifecycle_phase="runtime",
        parameter_schema={"type": "object", "properties": {
            "max_pieces": {"type": "integer", "minimum": 1, "maximum": 16},
            "degree": {"type": "integer", "enum": [2, 3]},
            "backend": {"type": "string", "enum": ["half_gates", "mixed"]},
            "public_calibration_counts": {"type": "array", "minItems": 1024, "maxItems": 1024,
                "items": {"type": "integer", "minimum": 0, "maximum": 1_000_000}}},
            "required": ["max_pieces", "degree", "public_calibration_counts"], "additionalProperties": False},
        capabilities=("protected-gated-multiply-q12", "bounded-operator-benchmark"),
        required_host_features=("native-core", "local-garbler"),
        role_eligibility=("client", "inference"),
    )

    def __init__(self, *, max_pieces: int = 8, degree: int = 3,
                 public_calibration_counts: Sequence[int] | None = None, backend: str = "half_gates") -> None:
        if type(max_pieces) is not int or not 1 <= max_pieces <= 16:
            raise ConfigurationError("max_pieces must be an integer in [1, 16]")
        if type(degree) is not int or degree not in (2, 3):
            raise ConfigurationError("degree must be 2 or 3")
        if type(backend) is not str or backend not in ("half_gates", "mixed"):
            raise ConfigurationError("Compact backend must be half_gates or mixed")
        if public_calibration_counts is None:
            counts = [0] * 1024
        else:
            if (not isinstance(public_calibration_counts, Sequence)
                    or isinstance(public_calibration_counts, (str, bytes, bytearray))
                    or len(public_calibration_counts) != 1024):
                raise ConfigurationError("Compact requires 1,024 public offline calibration counts")
            counts = list(public_calibration_counts)
            if (any(type(value) is not int or not 0 <= value <= 1_000_000 for value in counts)
                    or sum(counts) > 100_000_000):
                raise ConfigurationError("public calibration exceeds the bounded fitting contract")
        super().__init__(self.descriptor.component, {
            "max_pieces": max_pieces, "degree": degree, "public_calibration_counts": counts,
            **({"backend": backend} if backend != "half_gates" else {})})

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {"backend": "half_gates", **self.to_spec()["params"]}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class LogRowGatedMultiplyQ9(NonlinearProtocol):
    """Complete Q18-input/Q9-output SiLU×up with garbled lookup and arithmetic.

    Fixed public gate/up ranges are ±48/±128. The uncompressed 4,096-row
    numeric profile matches Curl's level-zero adaptation. One-use LogRow
    labels feed exact half-gates rescaling and multiplication without an
    intermediate plaintext boundary. Only bounded operator execution exists.
    ``backend="mixed"`` selects party-local arithmetic multiplication and
    exact garbled conversions, supplied by a trusted in-process dealer.
    """

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/logrow-gated-multiply-q9/v1", provider="pllm",
        distribution="pllm.run", version="1", category="pllm/nonlinear-protocol",
        category_version="1", lifecycle_phase="runtime",
        parameter_schema={"type": "object", "properties": {
            "backend": {"type": "string", "enum": ["half_gates", "mixed"]}}, "additionalProperties": False},
        capabilities=("protected-gated-multiply-q9", "bounded-operator-benchmark"),
        required_host_features=("native-core", "local-garbler"),
        role_eligibility=("client", "inference"),
    )

    def __init__(self, *, backend: str = "half_gates") -> None:
        if type(backend) is not str or backend not in ("half_gates", "mixed"):
            raise ConfigurationError("LogRow backend must be half_gates or mixed")
        super().__init__(self.descriptor.component, {"backend": backend} if backend != "half_gates" else {})

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {"backend": "half_gates", **self.to_spec()["params"]}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class CurlWaveletGatedMultiplyQ9(NonlinearProtocol):
    """Complete Haar-table ``SiLU(gate) * up`` on signed Q18 inputs.

    Public gate/up bounds are ±48/±128. A 4,096-row table covers [-64, 64)
    at 1/32 spacing; ``levels`` discards Haar detail coefficients. Protected
    index reduction uses exact floor, while up and output rescaling use exact
    ties-even. Output is Q9. This bounded two-share operator uses a local dealer
    and fresh Beaver material; it does not bind a decoder or provider transport.
    ``backend="mixed"`` replaces interval-key rescalings with exact garbled
    conversions and keeps the same Haar table and numeric profile.
    """

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/curl-wavelet-gated-multiply-q9/v1", provider="pllm",
        distribution="pllm.run", version="1", category="pllm/nonlinear-protocol",
        category_version="1", lifecycle_phase="runtime",
        parameter_schema={"type": "object", "properties": {
            "backend": {"type": "string", "enum": ["interval", "mixed"]},
            "levels": {"type": "integer", "minimum": 0, "maximum": 8}},
            "required": ["levels"], "additionalProperties": False},
        capabilities=("protected-gated-multiply-q9", "bounded-operator-benchmark"),
        required_host_features=("native-core", "local-correlation-dealer"),
        role_eligibility=("client", "worker_a", "worker_b"),
    )

    def __init__(self, *, levels: int = 0, backend: str = "interval") -> None:
        if type(levels) is not int or not 0 <= levels <= 8:
            raise ConfigurationError("levels must be an integer in [0, 8]")
        if type(backend) is not str or backend not in ("interval", "mixed"):
            raise ConfigurationError("Curl backend must be interval or mixed")
        super().__init__(self.descriptor.component, {"levels": levels,
            **({"backend": backend} if backend != "interval" else {})})

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return {"backend": "interval", **self.to_spec()["params"]}

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


class CurlWaveletEncodedTable(NonlinearProtocol):
    """Haar-compressed Q7 activation table with one-use party-local private lookup.

    Inputs are already quantized and client-local index reduction is explicit.
    Levels 0..8 retain block means with ties-even rounding. Calibration is
    public and offline; each lookup uses fresh dealer shares.
    """

    __slots__ = ()
    descriptor = ComponentDescriptor(
        component="pllm/curl-wavelet-encoded-table-q7/v1", provider="pllm",
        distribution="pllm.run", version="1", category="pllm/nonlinear-protocol",
        category_version="1", lifecycle_phase="runtime", parameter_schema=_q7_schema(wavelet=True),
        capabilities=("protected-table-lookup-q7", "bounded-operator-benchmark"),
        required_host_features=("native-core", "local-correlation-dealer"),
        role_eligibility=("client", "worker_a", "worker_b"),
    )

    def __init__(self, *, levels: int = 0, max_pieces: int = 4,
                 public_calibration_counts: Sequence[int] | None = None) -> None:
        if type(levels) is not int or not 0 <= levels <= 8:
            raise ConfigurationError("levels must be an integer in [0, 8]")
        super().__init__(self.descriptor.component,
                         _q7_parameters(max_pieces, public_calibration_counts) | {"levels": levels})

    def get_params(self, deep: bool = True) -> dict[str, object]:
        return self.to_spec()["params"]

    @classmethod
    def describe(cls) -> ComponentDescriptor:
        return cls.descriptor


@pending("llama-math")
class LlamaSecureMath(PendingMethod):
    pass


@pending("sirnn")
class SirnnSecureMath(PendingMethod):
    pass


@pending("ripple")
class WaveletHomomorphicLookup(PendingMethod):
    pass


__all__ += [
    "PackedEncryptedSoftmax",
    "ShaftFixedPointTransformerOps", "CompactPiecewiseActivation", "CurlWaveletEncodedTable", "CurlWaveletGatedMultiplyQ9",
    "LogRowGatedMultiplyQ9",
    "CompactGatedMultiplyQ12",
    "LlamaSecureMath", "SirnnSecureMath", "WaveletHomomorphicLookup",
]

install_planned_components(globals())


def fit_compact_silu_q7_reference(
    public_calibration_counts: bytes, max_pieces: int = 4
) -> CompactQ7Reference:
    """Fit a bounded public-calibration Q7 SiLU numeric reference.

    Supply exactly 257 little-endian unsigned-32 counts for Q7 inputs
    -128..128. Inputs must come from public *offline* calibration, never a
    private prompt. The returned profile selects intervals in plaintext;
    it is not a private protocol or an executable pipeline component.
    """
    if not isinstance(public_calibration_counts, bytes):
        raise TypeError("public calibration counts must be immutable bytes")
    from pllm import _native

    return _native.fit_compact_silu_q7_reference(public_calibration_counts, max_pieces)


__all__.append("fit_compact_silu_q7_reference")


def create_logrow_scaled_silu_q7_reference(max_abs: int) -> ScaledSiluQ7Reference:
    """Fix a public integer SiLU range for one-use LogRow research sessions.

    ``max_abs`` is a public/offline range in 1..=16, not a statistic derived
    from a private request. No clipping occurs; a gate outside the selected
    range fails and burns the remaining session material. The profile is not
    an executable Pipeline component.
    """
    from pllm import _native

    return _native.create_logrow_scaled_silu_q7_reference(max_abs)


__all__.append("create_logrow_scaled_silu_q7_reference")
