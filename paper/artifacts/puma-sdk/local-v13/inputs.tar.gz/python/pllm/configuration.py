"""Immutable public configuration values and strict serialization."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field, fields, replace
from pathlib import Path
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Iterable, Mapping, cast
from urllib.parse import urlsplit

import yaml

if TYPE_CHECKING:
    from pllm.providers import ProviderDescriptor
    from pllm.roles.topology import RoleGraph

_DIGEST_DOMAIN = b"pllm.configuration.v1\0"
_PIPELINE_DIGEST_DOMAIN = b"pllm.pipeline.v2\0"
_EXPERIMENT_SCHEMA = "pllm.experiment.v2"
_MAX_DOCUMENT_BYTES = 1_048_576


class ConfigurationError(ValueError):
    """Configuration is malformed or outside the supported schema."""


@dataclass(frozen=True, slots=True)
class ComponentDescriptor:
    """Static, immutable identity and compatibility metadata for a built-in component."""

    component: str
    provider: str
    distribution: str
    version: str
    category: str
    category_version: str
    lifecycle_phase: str
    parameter_schema: Mapping[str, Any]
    capabilities: tuple[str, ...] = ()
    required_host_features: tuple[str, ...] = ()
    role_eligibility: tuple[str, ...] = ()
    artifacts: tuple[Mapping[str, Any], ...] = ()
    evidence: tuple[Mapping[str, Any], ...] = ()

    def __post_init__(self) -> None:
        for name in (
            "component",
            "provider",
            "distribution",
            "version",
            "category",
            "category_version",
            "lifecycle_phase",
        ):
            _string(getattr(self, name), f"descriptor.{name}")
        object.__setattr__(
            self,
            "parameter_schema",
            _freeze_json(self.parameter_schema, "descriptor.parameter_schema"),
        )
        for name in ("capabilities", "required_host_features", "role_eligibility"):
            values = getattr(self, name)
            if type(values) is not tuple:
                raise ConfigurationError(f"descriptor.{name} must be a tuple")
            object.__setattr__(
                self,
                name,
                tuple(_string(value, f"descriptor.{name}") for value in values),
            )
        for name in ("artifacts", "evidence"):
            values = getattr(self, name)
            if type(values) is not tuple:
                raise ConfigurationError(f"descriptor.{name} must be a tuple")
            frozen = _freeze_json(values, f"descriptor.{name}")
            object.__setattr__(self, name, frozen)

    def to_dict(self) -> dict[str, Any]:
        return {
            "component": self.component,
            "provider": self.provider,
            "distribution": self.distribution,
            "version": self.version,
            "category": self.category,
            "category_version": self.category_version,
            "lifecycle_phase": self.lifecycle_phase,
            "parameter_schema": _thaw_json(self.parameter_schema),
            "capabilities": list(self.capabilities),
            "required_host_features": list(self.required_host_features),
            "role_eligibility": list(self.role_eligibility),
            "artifacts": _thaw_json(self.artifacts),
            "evidence": _thaw_json(self.evidence),
        }

    def __hash__(self) -> int:
        return hash(
            json.dumps(
                self.to_dict(),
                ensure_ascii=False,
                allow_nan=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        )


def _string(value: object, path: str) -> str:
    if type(value) is not str or not value:
        raise ConfigurationError(f"{path} must be a non-empty string")
    return value


def _integer(value: object, path: str, *, minimum: int = 1) -> int:
    if type(value) is not int or value < minimum:
        raise ConfigurationError(f"{path} must be an integer >= {minimum}")
    return value


def _freeze_json(value: object, path: str = "value", active: set[int] | None = None) -> Any:
    if value is None or type(value) in (bool, str, int):
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise ConfigurationError(f"{path} must be finite")
        return value
    if isinstance(value, Mapping):
        active = set() if active is None else active
        identity = id(value)
        if identity in active:
            raise ConfigurationError(f"{path} contains a cycle")
        active.add(identity)
        frozen_mapping: dict[str, Any] = {}
        for key, item in value.items():
            if type(key) is not str:
                raise ConfigurationError(f"{path} keys must be strings")
            if not key or "__" in key:
                raise ConfigurationError(f"{path} contains invalid key {key!r}")
            frozen_mapping[key] = _freeze_json(item, f"{path}.{key}", active)
        active.remove(identity)
        return MappingProxyType(frozen_mapping)
    if isinstance(value, (list, tuple)):
        active = set() if active is None else active
        identity = id(value)
        if identity in active:
            raise ConfigurationError(f"{path} contains a cycle")
        active.add(identity)
        frozen_sequence = tuple(
            _freeze_json(item, f"{path}[{index}]", active) for index, item in enumerate(value)
        )
        active.remove(identity)
        return frozen_sequence
    raise ConfigurationError(f"{path} has unsupported type {type(value).__name__}")


def _thaw_json(value: object) -> Any:
    if isinstance(value, Mapping):
        return {key: _thaw_json(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw_json(item) for item in value]
    return value


def _hashable_json(value: object) -> object:
    if isinstance(value, Mapping):
        return tuple(sorted((key, _hashable_json(item)) for key, item in value.items()))
    if isinstance(value, tuple):
        return tuple(_hashable_json(item) for item in value)
    return value


def _flatten_mapping(prefix: str, value: Mapping[str, Any], output: dict[str, Any]) -> None:
    for key, item in value.items():
        path = f"{prefix}__{key}"
        output[path] = item
        if isinstance(item, Mapping):
            _flatten_mapping(path, item, output)


class _Configuration:
    def get_params(self, deep: bool = True) -> dict[str, Any]:
        params = {field.name: getattr(self, field.name) for field in fields(cast(Any, self))}
        if not deep:
            return params
        output = dict(params)
        for name, value in params.items():
            if isinstance(value, _Configuration):
                for nested_name, nested_value in value.get_params(deep=True).items():
                    output[f"{name}__{nested_name}"] = nested_value
            elif isinstance(value, Mapping):
                for key, item in value.items():
                    path = f"{name}__{key}"
                    output[path] = item
                    if isinstance(item, _Configuration):
                        for nested_name, nested_value in item.get_params(deep=True).items():
                            output[f"{path}__{nested_name}"] = nested_value
                    elif isinstance(item, Mapping):
                        _flatten_mapping(path, item, output)
        return output

    def with_params(self, **changes: object) -> Any:
        paths = [path.split("__") for path in changes]
        if any(not path or any(not part for part in path) for path in paths):
            raise ConfigurationError("parameter paths must contain non-empty '__'-separated names")
        for index, path in enumerate(paths):
            for other in paths[index + 1 :]:
                shorter = min(len(path), len(other))
                if path[:shorter] == other[:shorter]:
                    raise ConfigurationError("overlapping parameter paths are not allowed")
        return _replace_paths(self, list(zip(paths, changes.values(), strict=True)))


_MODEL_KINDS = frozenset(
    {
        "huggingface",
        "safetensors",
        "vllm",
        "mlx",
        "mlx-lm",
        "gguf",
        "llama.cpp",
        "ollama",
        "tiny",
    }
)
_MODEL_PATH_KINDS = _MODEL_KINDS - {"ollama", "tiny"}


@dataclass(frozen=True, slots=True, init=False)
class Model(_Configuration):
    source: str
    kind: str
    model_id: str | None
    revision: str | None
    local_files_only: bool
    endpoint: str | None

    def __init__(
        self,
        source: str,
        *,
        kind: str = "huggingface",
        model_id: str | None = None,
        revision: str | None = None,
        local_files_only: bool = False,
        endpoint: str | None = None,
    ) -> None:
        source = _string(source, "model.source")
        kind = _string(kind, "model.kind")
        if kind not in _MODEL_KINDS:
            raise ConfigurationError(f"unsupported model kind {kind!r}")
        if model_id is not None:
            model_id = _string(model_id, "model.model_id")
        if revision is not None:
            revision = _string(revision, "model.revision")
        if type(local_files_only) is not bool:
            raise ConfigurationError("model.local_files_only must be a boolean")
        if endpoint is not None:
            endpoint = _string(endpoint, "model.endpoint")
            parsed_endpoint = urlsplit(endpoint)
            try:
                port = parsed_endpoint.port
            except ValueError as exc:
                raise ConfigurationError("model.endpoint has an invalid port") from exc
            if (
                parsed_endpoint.scheme.lower() not in {"http", "https"}
                or parsed_endpoint.hostname is None
                or parsed_endpoint.username is not None
                or parsed_endpoint.password is not None
                or parsed_endpoint.path not in {"", "/"}
                or parsed_endpoint.query
                or parsed_endpoint.fragment
                or port is not None
                and not 1 <= port <= 65535
            ):
                raise ConfigurationError(
                    "model.endpoint must be an HTTP(S) origin without credentials"
                )
            endpoint = f"{parsed_endpoint.scheme.lower()}://{parsed_endpoint.netloc}"
        if revision is not None and kind not in {"huggingface", "safetensors", "vllm"}:
            raise ConfigurationError(
                "model.revision is supported only for Hugging Face-compatible models"
            )
        if local_files_only and kind not in {"huggingface", "safetensors", "vllm"}:
            raise ConfigurationError(
                "model.local_files_only is supported only for Hugging Face-compatible models"
            )
        if kind == "ollama" and endpoint is None:
            endpoint = "http://127.0.0.1:11434"
        if kind != "ollama" and endpoint is not None:
            raise ConfigurationError("model.endpoint is supported only for ollama models")
        object.__setattr__(self, "source", source)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "model_id", model_id)
        object.__setattr__(self, "revision", revision)
        object.__setattr__(self, "local_files_only", local_files_only)
        object.__setattr__(self, "endpoint", endpoint)

    @classmethod
    def hf(
        cls,
        repo_id: str,
        *,
        model_id: str | None = None,
        revision: str | None = None,
        local_files_only: bool = False,
    ) -> Model:
        return Model(
            repo_id,
            model_id=model_id,
            revision=revision,
            local_files_only=local_files_only,
        )

    @classmethod
    def path(
        cls,
        path: str,
        *,
        format: str = "huggingface",
        model_id: str | None = None,
    ) -> Model:
        if format not in _MODEL_PATH_KINDS:
            raise ConfigurationError(f"unsupported model path format {format!r}")
        from pllm.sources import BundleModel

        return BundleModel(path, format=format, model_id=model_id)

    @classmethod
    def tiny(cls, name: str = "qwen2", *, model_id: str | None = None) -> Model:
        from pllm.sources import TinyModel

        return TinyModel(name, model_id=model_id)

    @classmethod
    def ollama(
        cls,
        name: str,
        *,
        endpoint: str = "http://127.0.0.1:11434",
        model_id: str | None = None,
    ) -> Model:
        return Model(name, kind="ollama", model_id=model_id, endpoint=endpoint)

    @classmethod
    def from_spec(cls, value: Mapping[str, Any]) -> Model:
        if not isinstance(value, Mapping):
            raise ConfigurationError("model must be a mapping")
        allowed = {
            "source",
            "kind",
            "model_id",
            "revision",
            "local_files_only",
            "endpoint",
        }
        unknown = set(value) - allowed
        if unknown:
            raise ConfigurationError(f"model has unknown fields: {sorted(unknown)}")
        if "source" not in value:
            raise ConfigurationError("model requires source")
        kind = value.get("kind", "huggingface")
        local_files_only = value.get("local_files_only", False)
        validated = Model(
            value["source"],
            kind=kind,
            model_id=value.get("model_id"),
            revision=value.get("revision"),
            local_files_only=local_files_only,
            endpoint=value.get("endpoint"),
        )
        if kind == "tiny":
            from pllm.sources import TinyModel

            return TinyModel(value["source"], model_id=value.get("model_id"))
        if (local_files_only and value.get("revision") is None) or kind in {
            "mlx",
            "mlx-lm",
            "gguf",
            "llama.cpp",
        }:
            from pllm.sources import BundleModel

            return BundleModel(
                value["source"],
                format=kind,
                model_id=value.get("model_id"),
            )
        return validated

    def to_spec(self) -> dict[str, Any]:
        result: dict[str, Any] = {"source": self.source}
        if self.kind != "huggingface":
            result["kind"] = self.kind
        if self.model_id is not None:
            result["model_id"] = self.model_id
        if self.revision is not None:
            result["revision"] = self.revision
        if self.local_files_only:
            result["local_files_only"] = True
        if self.endpoint is not None:
            result["endpoint"] = self.endpoint
        return result

    def to_runtime_spec(self) -> dict[str, Any]:
        return {"kind": self.kind, **self.to_spec()}

    def with_params(self, **changes: object) -> Model:
        fields = {
            "source": self.source,
            "kind": self.kind,
            "model_id": self.model_id,
            "revision": self.revision,
            "local_files_only": self.local_files_only,
            "endpoint": self.endpoint,
        }
        for name, value in changes.items():
            if "__" in name or name not in fields:
                raise ConfigurationError(f"unknown parameter path: {name}")
            fields[name] = value
        return Model.from_spec(fields)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Model):
            return NotImplemented
        return self.to_spec() == other.to_spec()

    def __hash__(self) -> int:
        return hash(
            (
                self.source,
                self.kind,
                self.model_id,
                self.revision,
                self.local_files_only,
                self.endpoint,
            )
        )


@dataclass(frozen=True, slots=True)
class ComponentRef(_Configuration):
    component: str
    params: Mapping[str, Any]

    def __init__(self, component: str, params: Mapping[str, Any] | None = None) -> None:
        component = _string(component, "component.component")
        from pllm.components._planned import require_implemented_identity

        require_implemented_identity(component)
        object.__setattr__(self, "component", component)
        frozen = _freeze_json({} if params is None else params, "component.params")
        if "component" in frozen or "params" in frozen:
            raise ConfigurationError("component parameter names cannot be 'component' or 'params'")
        object.__setattr__(self, "params", frozen)

    @classmethod
    def from_params(cls, params: Mapping[str, Any]) -> ComponentRef:
        if not isinstance(params, Mapping):
            raise ConfigurationError("component params must be a mapping")
        try:
            return cls(**dict(params))
        except TypeError as exc:
            raise ConfigurationError(f"invalid parameters for {cls.__name__}: {exc}") from exc

    def get_params(self, deep: bool = True) -> dict[str, Any]:
        output = {"component": self.component, **self.params}
        if deep:
            for key, value in self.params.items():
                if isinstance(value, Mapping):
                    _flatten_mapping(key, value, output)
        return output

    def to_spec(self) -> dict[str, Any]:
        return {"component": self.component, "params": _thaw_json(self.params)}

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ComponentRef):
            return NotImplemented
        return self.component == other.component and self.params == other.params

    def __hash__(self) -> int:
        return hash((self.component, _hashable_json(self.params)))


@dataclass(frozen=True, slots=True)
class Pipeline(_Configuration):
    model: Model
    components: Mapping[str, ComponentRef]
    profile: str | None = field(default=None, compare=False)

    def __post_init__(self) -> None:
        if self.profile is not None:
            _string(self.profile, "pipeline.profile")
        if not isinstance(self.model, Model):
            raise ConfigurationError("pipeline.model must be a Model")
        if not isinstance(self.components, Mapping):
            raise ConfigurationError("pipeline.components must be a mapping")
        copied: dict[str, ComponentRef] = {}
        for name, component in self.components.items():
            _string(name, "pipeline component name")
            if "__" in name:
                raise ConfigurationError("pipeline component names cannot contain '__'")
            if not isinstance(component, ComponentRef):
                raise ConfigurationError(f"pipeline.components.{name} must be a ComponentRef")
            if not component.component.startswith("pllm/"):
                copied[name] = component
            else:
                from pllm.components import create_component

                copied[name] = cast(
                    ComponentRef,
                    create_component(component.component, component.params),
                )
        object.__setattr__(self, "components", MappingProxyType(copied))

    @classmethod
    def from_profile(
        cls,
        profile: str,
        *,
        model: Model,
        components: Mapping[str, ComponentRef],
    ) -> Pipeline:
        return cls(profile=profile, model=model, components=components)

    @classmethod
    def from_spec(
        cls,
        value: Mapping[str, Any],
        *,
        providers: Iterable[ProviderDescriptor] = (),
    ) -> Pipeline:
        if cls is not Pipeline:
            raise TypeError("Pipeline.from_spec must be called on Pipeline")
        data = _fields(value, {"model", "components"}, "pipeline")
        model = Model.from_spec(data["model"])
        raw_components = data["components"]
        if not isinstance(raw_components, Mapping):
            raise ConfigurationError("pipeline.components must be a mapping")
        providers = tuple(providers)
        components = {
            _string(name, "pipeline component name"): _component_from_spec(
                component,
                f"pipeline.components.{name}",
                providers=providers,
            )
            for name, component in raw_components.items()
        }
        return cls(
            model=model,
            components=components,
        )

    def to_spec(self) -> dict[str, Any]:
        return {
            "model": self.model.to_spec(),
            "components": {
                name: component.to_spec() for name, component in self.components.items()
            },
        }

    def canonical_bytes(self) -> bytes:
        return json.dumps(
            self.to_spec(),
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def digest(self) -> str:
        return hashlib.sha256(_PIPELINE_DIGEST_DOMAIN + self.canonical_bytes()).hexdigest()

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Pipeline):
            return NotImplemented
        return self.to_spec() == other.to_spec()

    def __hash__(self) -> int:
        return hash((self.model, tuple(sorted(self.components.items()))))


@dataclass(frozen=True, slots=True)
class Deployment(_Configuration):
    kind: str
    root: str | None = None
    network_id: str | None = None
    network_spec_digest: str | None = None
    snapshot_digest: str | None = None

    def __post_init__(self) -> None:
        if self.kind == "local":
            _string(self.root, "deployment.root")
            if any(value is not None for value in (
                self.network_id, self.network_spec_digest, self.snapshot_digest
            )):
                raise ConfigurationError("local deployment cannot contain network intent")
        elif self.kind == "network":
            from pllm.deployment.network import digest_value, identity

            if self.root is not None:
                raise ConfigurationError("network deployment has no local root")
            try:
                identity(self.network_id, "network_id")
                digest_value(self.network_spec_digest, "network_spec", nonzero=True)
                if self.snapshot_digest is not None:
                    digest_value(self.snapshot_digest, "snapshot", nonzero=True)
            except ValueError as exc:
                raise ConfigurationError(str(exc)) from exc
        else:
            raise ConfigurationError("deployment.kind must be 'local' or 'network'")

    @classmethod
    def local(cls, *, root: str) -> Deployment:
        return cls(kind="local", root=root)

    @classmethod
    def network(cls, *, network_id: str, network_spec_digest: str,
                snapshot_digest: str | None = None) -> Deployment:
        return cls(kind="network", network_id=network_id,
                   network_spec_digest=network_spec_digest, snapshot_digest=snapshot_digest)

    def to_spec(self) -> dict[str, Any]:
        if self.kind == "network":
            return {"kind": "network", "network_id": self.network_id,
                    "network_spec_digest": self.network_spec_digest,
                    "snapshot_digest": self.snapshot_digest}
        return {"kind": self.kind, "root": self.root}


@dataclass(frozen=True, slots=True)
class ExecutionBudget(_Configuration):
    requests: int
    max_input_tokens: int
    max_new_tokens: int

    def __post_init__(self) -> None:
        _integer(self.requests, "budget.requests")
        _integer(self.max_input_tokens, "budget.max_input_tokens")
        _integer(self.max_new_tokens, "budget.max_new_tokens")

    def to_spec(self) -> dict[str, Any]:
        return {
            "requests": self.requests,
            "max_input_tokens": self.max_input_tokens,
            "max_new_tokens": self.max_new_tokens,
        }


@dataclass(frozen=True, slots=True)
class Experiment(_Configuration):
    name: str
    pipeline: Pipeline
    deployment: Deployment
    budget: ExecutionBudget

    def __post_init__(self) -> None:
        _string(self.name, "experiment.name")
        if not isinstance(self.pipeline, Pipeline):
            raise ConfigurationError("experiment.pipeline must be a Pipeline")
        if not isinstance(self.deployment, Deployment):
            raise ConfigurationError("experiment.deployment must be a Deployment")
        if not isinstance(self.budget, ExecutionBudget):
            raise ConfigurationError("experiment.budget must be an ExecutionBudget")
        cache = self.pipeline.components.get("cache")
        if (self.deployment.kind == "network" and cache is not None
                and {"decode", "decode_max_bytes"} & cache.params.keys()):
            raise ConfigurationError("network automatic planning does not support caller-owned decode cache resources")

    @classmethod
    def from_spec(
        cls,
        spec: Mapping[str, Any],
        *,
        providers: Iterable[ProviderDescriptor] = (),
    ) -> Experiment:
        return _experiment_from_spec(spec, providers=providers)

    @classmethod
    def from_file(
        cls,
        path: str | Path,
        *,
        providers: Iterable[ProviderDescriptor] = (),
    ) -> Experiment:
        return load_configuration(path, providers=providers)

    def to_spec(self) -> dict[str, Any]:
        return {
            "schema": "pllm.experiment.v3" if self.deployment.kind == "network" else _EXPERIMENT_SCHEMA,
            "name": self.name,
            "pipeline": self.pipeline.to_spec(),
            "deployment": self.deployment.to_spec(),
            "budget": self.budget.to_spec(),
        }

    def canonical_bytes(self) -> bytes:
        return canonical_bytes(self)

    def configuration_digest(self) -> str:
        return configuration_digest(self)

    def resolve(self) -> ExperimentProfile:
        return ExperimentProfile(self)


@dataclass(frozen=True, slots=True, init=False)
class ExperimentProfile:
    """Immutable runtime resolution of one component composition."""

    model: str
    canonical_composition: bytes
    composition_digest: str
    configuration_digest: str
    profile: str | None
    privacy_mode: str
    proprietary_protocol: str
    requires_preparation: bool
    client_runtime: str
    privacy_protocol: str | None
    verification_component: str | None
    verification_target_failure_bits: int
    public_equalization_digest: str | None
    prefix_cache_bytes: int
    prefix_cache_bound_tokens: int | None
    remote_output_head: bool
    private_boundary: bool
    client_prefix_layers: int
    client_linear_roles: tuple[str, ...]
    client_linear_layer_roles: tuple[tuple[int, str], ...]
    inventory_policy: str
    prepared_inventory_rows: int
    background_inventory_refill: bool
    inventory_refill: str | None
    preparation_decode_epoch_tokens: int | None
    preparation_decode_epoch_schedule: tuple[int, ...] | None
    decode: bool
    decode_max_bytes: int
    inflight: bool
    inflight_max_requests: int
    inflight_max_bytes: int
    bundle_compression: str
    provider_artifact_cache_bytes: int
    role_graph: RoleGraph | None

    def __init__(self, experiment: Experiment) -> None:
        if not isinstance(experiment, Experiment):
            raise TypeError("experiment must be an Experiment")
        from pllm.profiles import resolve_runtime_composition
        from pllm.roles.topology import graph_for_runtime

        runtime_options = resolve_runtime_composition(experiment.pipeline)
        if runtime_options is not None:
            for name in ("preparation_decode_epoch_tokens", "preparation_decode_epoch_schedule", "decode", "decode_max_bytes", "inflight", "inflight_max_requests", "inflight_max_bytes"):
                object.__setattr__(self, name, getattr(runtime_options, name))
        object.__setattr__(
            self,
            "role_graph",
            graph_for_runtime(runtime_options) if runtime_options is not None else None,
        )
        if runtime_options is not None and runtime_options.privacy_mode == "proprietary":
            object.__setattr__(
                self,
                "model",
                experiment.pipeline.model.model_id or experiment.pipeline.model.source,
            )
            object.__setattr__(
                self, "canonical_composition", experiment.pipeline.canonical_bytes()
            )
            object.__setattr__(self, "composition_digest", experiment.pipeline.digest())
            object.__setattr__(self, "configuration_digest", experiment.configuration_digest())
            object.__setattr__(self, "profile", experiment.pipeline.profile)
            object.__setattr__(self, "privacy_mode", runtime_options.privacy_mode)
            object.__setattr__(self, "proprietary_protocol", runtime_options.proprietary_protocol)
            object.__setattr__(self, "requires_preparation", runtime_options.requires_preparation)
            object.__setattr__(self, "client_runtime", runtime_options.client_runtime)
            object.__setattr__(self, "privacy_protocol", runtime_options.privacy_protocol)
            object.__setattr__(self, "verification_component", runtime_options.verification_component)
            object.__setattr__(
                self,
                "verification_target_failure_bits",
                runtime_options.verification_target_failure_bits,
            )
            object.__setattr__(self, "public_equalization_digest", runtime_options.public_equalization_digest)
            object.__setattr__(self, "prefix_cache_bytes", runtime_options.prefix_cache_bytes)
            object.__setattr__(self, "prefix_cache_bound_tokens", runtime_options.prefix_cache_bound_tokens)
            object.__setattr__(self, "remote_output_head", runtime_options.remote_output_head)
            object.__setattr__(self, "private_boundary", runtime_options.private_boundary)
            object.__setattr__(self, "client_prefix_layers", runtime_options.client_prefix_layers)
            object.__setattr__(self, "client_linear_roles", runtime_options.client_linear_roles)
            object.__setattr__(self, "client_linear_layer_roles", runtime_options.client_linear_layer_roles)
            object.__setattr__(self, "inventory_policy", runtime_options.inventory_policy)
            object.__setattr__(self, "prepared_inventory_rows", runtime_options.prepared_inventory_rows)
            object.__setattr__(self, "background_inventory_refill", runtime_options.background_inventory_refill)
            object.__setattr__(self, "inventory_refill", runtime_options.inventory_refill)
            object.__setattr__(self, "bundle_compression", runtime_options.bundle_compression)
            object.__setattr__(self, "provider_artifact_cache_bytes", runtime_options.provider_artifact_cache_bytes)
            return
        from pllm import _native

        try:
            resolved = _native.resolve_experiment(experiment.canonical_bytes())
        except ValueError as exc:
            raise ConfigurationError(str(exc)) from exc
        from pllm.model_loader import expected_model_id

        object.__setattr__(self, "model", expected_model_id(experiment.pipeline.model))
        object.__setattr__(
            self, "canonical_composition", resolved.canonical_composition
        )
        object.__setattr__(self, "composition_digest", resolved.composition_digest)
        object.__setattr__(self, "configuration_digest", resolved.configuration_digest)
        if runtime_options is None:
            raise ConfigurationError("resolved profile has no runtime contract")
        object.__setattr__(self, "profile", experiment.pipeline.profile)
        object.__setattr__(self, "privacy_mode", runtime_options.privacy_mode)
        object.__setattr__(self, "proprietary_protocol", runtime_options.proprietary_protocol)
        object.__setattr__(self, "requires_preparation", runtime_options.requires_preparation)
        object.__setattr__(self, "client_runtime", runtime_options.client_runtime)
        object.__setattr__(self, "privacy_protocol", runtime_options.privacy_protocol)
        object.__setattr__(self, "verification_component", runtime_options.verification_component)
        object.__setattr__(
            self,
            "verification_target_failure_bits",
            runtime_options.verification_target_failure_bits,
        )
        object.__setattr__(self, "public_equalization_digest", runtime_options.public_equalization_digest)
        object.__setattr__(self, "prefix_cache_bytes", runtime_options.prefix_cache_bytes)
        object.__setattr__(self, "prefix_cache_bound_tokens", runtime_options.prefix_cache_bound_tokens)
        object.__setattr__(self, "remote_output_head", runtime_options.remote_output_head)
        object.__setattr__(self, "private_boundary", runtime_options.private_boundary)
        object.__setattr__(self, "client_prefix_layers", runtime_options.client_prefix_layers)
        object.__setattr__(self, "client_linear_roles", runtime_options.client_linear_roles)
        object.__setattr__(self, "client_linear_layer_roles", runtime_options.client_linear_layer_roles)
        object.__setattr__(self, "inventory_policy", runtime_options.inventory_policy)
        object.__setattr__(self, "prepared_inventory_rows", runtime_options.prepared_inventory_rows)
        object.__setattr__(self, "background_inventory_refill", runtime_options.background_inventory_refill)
        object.__setattr__(self, "inventory_refill", runtime_options.inventory_refill)
        object.__setattr__(self, "bundle_compression", runtime_options.bundle_compression)
        object.__setattr__(self, "provider_artifact_cache_bytes", runtime_options.provider_artifact_cache_bytes)


def _replace_paths(target: Any, changes: list[tuple[list[str], object]]) -> Any:
    """Rebuild each immutable owner once, after applying all sibling changes."""
    if not changes:
        return target
    if isinstance(target, ComponentRef):
        current = target.get_params(deep=False)
    elif isinstance(target, Pipeline) and type(target) is not Pipeline:
        return target.with_params(**{"__".join(path): value for path, value in changes})
    elif isinstance(target, _Configuration):
        current = {field.name: getattr(target, field.name) for field in fields(cast(Any, target))}
    elif isinstance(target, Mapping):
        current = target
    else:
        raise ConfigurationError(
            f"parameter path continues through non-configuration value {changes[0][0][0]!r}"
        )
    grouped: dict[str, list[tuple[list[str], object]]] = {}
    for path, value in changes:
        name, *rest = path
        if name not in current:
            raise ConfigurationError(f"unknown parameter path: {'__'.join(path)}")
        grouped.setdefault(name, []).append((rest, value))
    changed = {name: _replace_paths(current[name], nested) if nested[0][0] else nested[0][1]
               for name, nested in grouped.items()}
    if isinstance(target, ComponentRef):
        params = {**target.params, **changed}
        if type(target) is ComponentRef:
            return ComponentRef(cast(str, params.pop("component", target.component)), params)
        return type(target).from_params(params)
    if isinstance(target, Model):
        return target.with_params(**changed)
    if isinstance(target, _Configuration):
        return replace(cast(Any, target), **changed)
    return {**current, **changed}


def _fields(value: object, expected: set[str], path: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ConfigurationError(f"{path} must be a mapping")
    keys: set[str] = set()
    for key in value:
        if type(key) is not str:
            raise ConfigurationError(f"{path} keys must be strings")
        keys.add(key)
    unknown = keys - expected
    missing = expected - keys
    if unknown:
        raise ConfigurationError(
            f"{path} has unknown fields: {', '.join(sorted(map(str, unknown)))}"
        )
    if missing:
        raise ConfigurationError(f"{path} is missing fields: {', '.join(sorted(missing))}")
    return value


def _component_from_spec(
    value: object,
    path: str,
    *,
    providers: Iterable[ProviderDescriptor] = (),
) -> ComponentRef:
    data = _fields(value, {"component", "params"}, path)
    component = _string(data["component"], f"{path}.component")
    params = data["params"]
    if not isinstance(params, Mapping):
        raise ConfigurationError(f"{path}.params must be a mapping")
    from pllm.components import create_component

    return create_component(component, params, providers=providers)


def _experiment_from_spec(
    value: object,
    *,
    providers: Iterable[ProviderDescriptor] = (),
) -> Experiment:
    data = _fields(value, {"schema", "name", "pipeline", "deployment", "budget"}, "experiment")
    if data["schema"] not in {_EXPERIMENT_SCHEMA, "pllm.experiment.v3"}:
        raise ConfigurationError(f"unsupported schema: {data['schema']!r}")
    pipeline = Pipeline.from_spec(data["pipeline"], providers=providers)
    network = data["schema"] == "pllm.experiment.v3"
    deployment_data = _fields(data["deployment"],
                             {"kind", "network_id", "network_spec_digest", "snapshot_digest"}
                             if network else {"kind", "root"}, "deployment")
    if deployment_data["kind"] != ("network" if network else "local"):
        raise ConfigurationError("experiment schema and deployment kind disagree")
    budget_data = _fields(
        data["budget"], {"requests", "max_input_tokens", "max_new_tokens"}, "budget"
    )
    return Experiment(
        name=data["name"],
        pipeline=pipeline,
        deployment=Deployment(**deployment_data),
        budget=ExecutionBudget(
            requests=budget_data["requests"],
            max_input_tokens=budget_data["max_input_tokens"],
            max_new_tokens=budget_data["max_new_tokens"],
        ),
    )


class _UniqueKeyLoader(yaml.SafeLoader):
    pass


def _construct_mapping(loader: yaml.SafeLoader, node: yaml.MappingNode, deep: bool = False) -> dict:
    loader.flatten_mapping(node)
    result: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            duplicate = key in result
        except TypeError as exc:
            raise ConfigurationError("mapping keys must be scalar strings") from exc
        if duplicate:
            raise ConfigurationError(f"duplicate mapping key: {key!r}")
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


_UniqueKeyLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _construct_mapping)


def _json_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ConfigurationError(f"duplicate mapping key: {key!r}")
        result[key] = value
    return result


def loads_configuration(
    text: str,
    *,
    format: str | None = None,
    providers: Iterable[ProviderDescriptor] = (),
) -> Experiment:
    """Parse one strict JSON or safe YAML experiment document."""
    if type(text) is not str:
        raise TypeError("configuration text must be a string")
    providers = tuple(providers)
    try:
        document_bytes = len(text.encode("utf-8"))
    except UnicodeError as exc:
        raise ConfigurationError("configuration must be valid UTF-8") from exc
    if document_bytes > _MAX_DOCUMENT_BYTES:
        raise ConfigurationError(f"configuration exceeds {_MAX_DOCUMENT_BYTES} byte limit")
    selected = ("json" if text.lstrip().startswith("{") else "yaml") if format is None else format
    try:
        if selected == "json":
            value = json.loads(
                text,
                object_pairs_hook=_json_pairs,
                parse_constant=lambda constant: (_ for _ in ()).throw(
                    ConfigurationError(f"non-finite number: {constant}")
                ),
            )
        elif selected in ("yaml", "yml"):
            value = yaml.load(text, Loader=_UniqueKeyLoader)
        else:
            raise ConfigurationError("format must be 'json' or 'yaml'")
        return _experiment_from_spec(value, providers=providers)
    except ConfigurationError:
        raise
    except json.JSONDecodeError as exc:
        raise ConfigurationError(f"invalid JSON: {exc.msg}") from exc
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"invalid YAML: {exc}") from exc
    except (RecursionError, TypeError, ValueError) as exc:
        raise ConfigurationError(f"invalid {selected} document structure") from exc


def load_configuration(
    path: str | Path,
    *,
    providers: Iterable[ProviderDescriptor] = (),
) -> Experiment:
    """Read and parse one experiment file; constructors themselves perform no I/O."""
    source = Path(path)
    suffix = source.suffix.lower()
    if suffix not in (".json", ".yaml", ".yml"):
        raise ConfigurationError("configuration file must use .json, .yaml, or .yml")
    if source.stat().st_size > _MAX_DOCUMENT_BYTES:
        raise ConfigurationError(f"configuration exceeds {_MAX_DOCUMENT_BYTES} byte limit")
    try:
        text = source.read_text(encoding="utf-8")
    except UnicodeError as exc:
        raise ConfigurationError("configuration must be valid UTF-8") from exc
    return loads_configuration(text, format=suffix[1:], providers=providers)


def canonical_bytes(
    configuration: Experiment | Mapping[str, Any],
    *,
    providers: Iterable[ProviderDescriptor] = (),
) -> bytes:
    """Return deterministic UTF-8 JSON bytes for a supported public specification."""
    if isinstance(configuration, Experiment):
        spec = configuration.to_spec()
    elif isinstance(configuration, Mapping):
        spec = _experiment_from_spec(configuration, providers=providers).to_spec()
    else:
        raise TypeError("configuration must be an Experiment or experiment mapping")
    return json.dumps(
        spec, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def configuration_digest(
    configuration: Experiment | Mapping[str, Any],
    *,
    providers: Iterable[ProviderDescriptor] = (),
) -> str:
    """Return domain-separated SHA-256 identity for public configuration."""
    return hashlib.sha256(
        _DIGEST_DOMAIN + canonical_bytes(configuration, providers=providers)
    ).hexdigest()


_CONCRETE_EXPORTS = {
    "ArithmeticGarblingSiluQ7": ("pllm.nonlinear", "ArithmeticGarblingSiluQ7"),
    "BinaryTableGatedMultiplyQ7": ("pllm.nonlinear", "BinaryTableGatedMultiplyQ7"),
    "BoundedIndependentElementsProtectedTensorSchedule": (
        "pllm.schedulers",
        "BoundedIndependentElementsProtectedTensorSchedule",
    ),
    "ChunkedIndependentLanesProtectedTensorSchedule": (
        "pllm.schedulers",
        "ChunkedIndependentLanesProtectedTensorSchedule",
    ),
    "Cpu": ("pllm.kernels", "Cpu"),
    "IndependentLanesProtectedTensorSchedule": (
        "pllm.schedulers",
        "IndependentLanesProtectedTensorSchedule",
    ),
    "KvCacheEviction": ("pllm.passes", "KvCacheEviction"),
    "MaskedLinear": ("pllm.protocols", "MaskedLinear"),
    "ModelAwareCorrections": ("pllm.preparation", "ModelAwareCorrections"),
    "R03CrtGatedMultiplyQ7": ("pllm.nonlinear", "R03CrtGatedMultiplyQ7"),
    "ScalarProtectedTensorSchedule": ("pllm.schedulers", "ScalarProtectedTensorSchedule"),
}


__all__ = [
    "ComponentDescriptor",
    "ComponentRef",
    "ConfigurationError",
    "Deployment",
    "ExecutionBudget",
    "Experiment",
    "ExperimentProfile",
    "Model",
    "Pipeline",
    "canonical_bytes",
    "configuration_digest",
    "load_configuration",
    "loads_configuration",
]


def __getattr__(name: str) -> Any:
    if name not in _CONCRETE_EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    from importlib import import_module

    module, attribute = _CONCRETE_EXPORTS[name]
    value = getattr(import_module(module), attribute)
    globals()[name] = value
    return value
