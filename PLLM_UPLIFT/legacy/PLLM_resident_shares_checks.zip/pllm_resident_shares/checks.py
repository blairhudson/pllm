#!/usr/bin/env python3
"""Algebra checks and an explicitly hypothetical latency budget, not an MPC runtime.

Uses deterministic NumPy randomness only for reproducible tests. Arrays represent
separate workers' state inside one test process. No LLM/GPU TPS is benchmarked.
Arithmetic is exact in Z/(2**32); no floating-point fidelity claim is made.
"""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
import numpy as np

MOD = 1 << 32
MASK = np.uint64(MOD - 1)
RNG = np.random.default_rng(20260913)


def rand(shape: tuple[int, ...]) -> np.ndarray:
    return RNG.integers(0, MOD, size=shape, dtype=np.uint64)


def ring(x: np.ndarray) -> np.ndarray:
    return x.astype(np.uint64) & MASK


def split(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    a = rand(x.shape)
    return a, ring(x - a)


def reveal(x: tuple[np.ndarray, np.ndarray]) -> np.ndarray:
    return ring(x[0] + x[1])


def linear(w: np.ndarray, shares: tuple[np.ndarray, np.ndarray]):
    # Independent local computations: no cross-worker messages or corrections.
    return tuple(ring(w @ a) for a in shares)


@dataclass
class Triple:
    a: tuple[np.ndarray, np.ndarray]
    b: tuple[np.ndarray, np.ndarray]
    c: tuple[np.ndarray, np.ndarray]
    used: bool = False


def prepare_matmul(m: int, k: int, n: int) -> Triple:
    # Only public dimensions: no model weights or user input.
    a, b = rand((m, k)), rand((k, n))
    return Triple(split(a), split(b), split(ring(a @ b)))


def secure_matmul(x, y, t: Triple):
    if t.used:
        raise ValueError('preprocessing record already consumed')
    t.used = True
    dx = tuple(ring(x[i] - t.a[i]) for i in range(2))
    dy = tuple(ring(y[i] - t.b[i]) for i in range(2))
    # Workers exchange these masked differences, not their activation shares.
    d, e = reveal(dx), reveal(dy)
    z = [ring(t.c[i] + d @ t.b[i] + t.a[i] @ e) for i in range(2)]
    z[0] = ring(z[0] + d @ e)
    # Both directions, ring elements packed into four bytes each.
    online_bytes = 2 * 4 * (d.size + e.size)
    prep_bytes = 2 * 4 * (t.a[0].size + t.b[0].size + t.c[0].size)
    return tuple(z), online_bytes, prep_bytes


def main() -> None:
    linear_cases = product_cases = reuse_rejections = 0
    shapes = [(3, 7, 2), (16, 32, 4), (64, 64, 1), (24, 80, 8)]
    for _ in range(50):
        for m, k, n in shapes:
            w, x = rand((m, k)), rand((k, n))
            assert np.array_equal(reveal(linear(w, split(x))), ring(w @ x))
            linear_cases += 1
            a, b = rand((m, k)), rand((k, n))
            t = prepare_matmul(m, k, n)
            out, _, _ = secure_matmul(split(a), split(b), t)
            assert np.array_equal(reveal(out), ring(a @ b))
            product_cases += 1
            try:
                secure_matmul(split(a), split(b), t)
            except ValueError:
                reuse_rejections += 1
            else:
                raise AssertionError('reuse accepted')

    # A resident chain with public linear stages and private square activations.
    # A square uses generic matrix triples here for simplicity, not an optimized
    # square-pair protocol. Nonlinear/attention traffic must not be called zero.
    graph_cases, linear_layers = 0, 0
    total_online = total_prep = 0
    for _ in range(20):
        width, depth = 16, 8
        x = rand((width, 1))
        shares, reference = split(x), x
        for layer in range(depth):
            w = rand((width, width))
            shares = linear(w, shares)
            reference = ring(w @ reference)
            linear_layers += 1
            # Secret scalar inner product produces a new secret scalar, then a
            # public vector projection restores width. This is not a transformer.
            t = prepare_matmul(1, width, 1)
            left = tuple(a.T for a in shares)
            scalar, online, prep = secure_matmul(left, shares, t)
            ref_scalar = ring(reference.T @ reference)
            w_up = rand((width, 1))
            shares = linear(w_up, scalar)
            reference = ring(w_up @ ref_scalar)
            linear_layers += 1
            total_online += online
            total_prep += prep
            assert np.array_equal(reveal(shares), reference)
        graph_cases += 1

    native_ms = 20.0  # illustrative 50 output tokens/s, not measured
    target_fraction = 0.9
    rounds = 64
    table = []
    for sync_us in [10, 100, 1000, 20000]:
        ideal_ms = native_ms + rounds * sync_us / 1000
        table.append({
            'sequential_exchanges': rounds,
            'unhidden_stall_us_per_exchange': sync_us,
            'assumed_base_ms_per_token': native_ms,
            'optimistic_ms_per_token_excluding_extra_crypto_and_bytes': ideal_ms,
            'optimistic_tps': 1000 / ideal_ms,
        })
    budget_ms = native_ms * (1 / target_fraction - 1)
    bandwidth_bytes_s = 100e9 / 8  # hypothetical effective 100 Gbit/s
    critical_path_bytes = 10_000_000
    serial_ms = 1000 * critical_path_bytes / bandwidth_bytes_s
    result = {
        'scope': 'Exact modular algebra tests and assumed performance budgets; no complete MPC implementation, security audit, LLM quality test, GPU benchmark or network measurement.',
        'public_linear_cases': linear_cases,
        'public_linear_online_bytes': 0,
        'public_linear_correction_preprocessing_bytes': 0,
        'private_matmul_cases': product_cases,
        'preprocessing_reuse_rejections': reuse_rejections,
        'resident_modular_graph_cases': graph_cases,
        'resident_modular_graph_public_linear_layers': linear_layers,
        'resident_graph_total_private_gate_online_bytes': total_online,
        'resident_graph_total_private_gate_preprocessing_bytes': total_prep,
        'latency_scenarios': table,
        'budget_example': {
            'assumed_native_tps': 50,
            'target_fraction': target_fraction,
            'total_extra_ms_allowed': budget_ms,
            '64_exchanges_at_10us_ms': .64,
            'assumed_critical_path_bytes': critical_path_bytes,
            'assumed_effective_bandwidth_gbit_s': 100,
            'byte_serialization_ms': serial_ms,
            'extra_crypto_and_kernel_ms_remaining': budget_ms - .64 - serial_ms,
        },
    }
    p = Path(__file__).with_name('results.json')
    p.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
