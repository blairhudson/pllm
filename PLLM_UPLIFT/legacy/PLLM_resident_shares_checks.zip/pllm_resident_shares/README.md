# PLLM: resident secret-sharing feasibility checks

Research note, 13 September 2026.

## Question
Can replacing client/server projection RPCs with two resident, non-colluding
inference workers remove network traffic without requiring weights at the client
or at Preparation?

## Algebraic result
For additive shares x = a + b (mod 2^32) and public W, each worker evaluates W
on its own share. Wa + Wb = Wx. The matrix multiplication itself needs no online
messages, no one-use W-dependent correction, and no HE preparation.

This is established MPC algebra, NOT a novel primitive. Both inference workers
must store W and perform a matrix multiplication. It does not satisfy a stricter
one-copy-total requirement. Fixed-point rescaling is not covered by the local
linear identity and must be implemented securely where required.

## What ran
Run `python checks.py` with Python 3 and NumPy installed. `results.json` is the
captured output. Tests include 200 public linear products, 200 private matrix
products with generic one-use Beaver triples, 200 record-reuse rejections, and
20 small resident modular graphs with 320 public linear stages.

The dealer routine for matrix triples accepts only dimensions, not model weights.
The graph uses inner products and public projections, NOT transformer attention
or a language model. Unsigned 64-bit wrapping followed by reduction is valid
for these Z/(2^32) examples. These are exact modular calculations, not evidence
of floating-point or quantized LLM fidelity.

This is a single-process reference simulation. Deterministic NumPy randomness
is for reproducible tests, NOT production cryptography. There are no network
sockets, GPU kernels, authentication, attestation, deployment isolation, secure
sampling, embedding lookup, or full malicious-security protocol. The tests do
not prove transcript privacy or measure production TPS. The offline dealer must
not receive the online openings or collude with an inference worker.

Private multiplication communication and preprocessing are explicitly counted.
Only the PUBLIC LINEAR operation has zero communication. Initial sharing, final
output delivery, nonlinear gates, conversions, preprocessing, framing and
transport must all be accounted for in an eventual implementation.

## Latency budget, not benchmark
The script assumes a 50 output-token/s native reference, 64 sequential exchange
stalls per token and several hypothetical unhidden stall times. It ignores extra
cryptographic/kernel work in its optimistic table. These are not measured RTTs
and 64 is not a measured PLLM stage/round count.

Achieving 90% of that native TPS allows 2.222 ms of total additional work per token.
64 stalls of 10 microseconds consume 0.64 ms. Ten million critical-path byte-
equivalents at an assumed effective 100 Gbit/s add 0.8 ms. Only 0.782 ms then
remains for extra secure-kernel and runtime work. Real full-duplex scheduling,
overlap, congestion, and GPU transfers require measurement.

## Architectural research target
Keep activations, KV cache, private token selection, and private embedding access
at the inference workers. The client should not participate in the per-layer or
per-token feedback loop. Both workers hold public model weights; an isolated
Preparation service supplies model-independent, shape-dependent gate material.
This changes trust from the existing Preparation/Inference split to a trusted
preprocessing dealer and two non-colluding online workers.

Measure private nonlinearities, attention products, rescaling, sampling, data-
oblivious embeddings, authentication, and replenishment before claiming near-
native throughput. Masked ring arithmetic is not automatically as fast as native
low-bit/floating-point kernels. Compare both per-user TPS and tokens per GPU-second.

## Primary research reviewed
- FuseFSS, arXiv:2606.09551v1: https://arxiv.org/html/2606.09551v1
  Explicit public-model two-server setting and nonlinear/helper-operator compiler.
  This is close prior art, not a demonstration of the proposed native-TPS target.
- SIGMA, PoPETs 2024: https://petsymposium.org/popets/2024/popets-2024-0107.php
  FSS/preprocessing and faithful fixed-point operations; preprocessing remains real.
- Gupta, Katz and Miers, ePrint 2026/1849: https://eprint.iacr.org/2026/1849
  Abstract reports malicious non-colluding servers, model-owner verifier data and
  no additional server overhead. Full PDF retrieval failed; no detailed protocol
  or sustained autoregressive performance claim is inferred from the abstract.
- NVIDIA, July 2026: https://developer.nvidia.com/blog/hardware-rooted-ai-security-that-wont-slow-you-down/
  Vendor measurements show 1-7.5% throughput reductions on the listed B300 model
  configurations. This protects plaintext execution inside a hardware trust
  boundary; it is not MPC/FHE or hardware-independent confidentiality.
