"""Experimental polynomial-plus-Fourier translated gate, not audited crypto.

SiLU(x) = x/2 + a*x*x + h(x), where even h has matched endpoint derivatives.
Approximate periodic h with cosines. Translation is closed within sine/cosine
pairs, so preprocessing shares coefficients instead of private interval keys.
Open full-width uniform masks. No weak real-valued masking is used.

Output is an approximate fixed-point gate, NOT bit-identical SiLU. Each
preprocessing record is used for ONE distinct activation. The test driver has
both shares; deployed workers must not. Supports only its declared range.
"""
from __future__ import annotations
import json, math, os, struct
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
import numpy as np

Q=1<<64
MASK=Q-1
F=10                  # activation scale 2^10
OUT=44                # intermediate SiLU numerator scale
T=OUT//2              # public sine/cosine and coefficient scale
R=8
PERIOD=2*R*(1<<F)     # 2^14, divides the masking ring exactly


def rand64():return int.from_bytes(os.urandom(8),'little')
def split(v):
    a=rand64()
    return a,(int(v)-a)&MASK

def center(v):
    v=int(v)&MASK
    return v-Q if v>=Q//2 else v

def silu(x):return x/(1+np.exp(-np.clip(x,-700,700)))

@dataclass(frozen=True)
class PublicSpec:
    modes:int
    quadratic:float
    coefficients:tuple[float,...]
    p:tuple[int,...]


def make_spec(modes):
    x=np.arange(PERIOD,dtype=np.float64)/(1<<F)
    x=(x+R)%(2*R)-R
    gp=.5*np.tanh(R/2)+.25*R/(np.cosh(R/2)**2)
    a=float(gp/(2*R))
    h=.5*x*np.tanh(x/2)-a*x*x
    c=np.fft.rfft(h)/PERIOD
    # Negative and positive frequency pair combine into real cosine.
    coefficients=(float(c[0].real),)+tuple(float(2*c[j].real) for j in range(1,modes+1))
    p=(round(coefficients[0]*(1<<OUT)),1<<(OUT-F-1),round(a*(1<<(OUT-2*F))))
    return PublicSpec(modes,a,coefficients,p)


def shifted(c,r):
    return [sum(int(c[j])*math.comb(j,k)*pow(r,j-k,Q) for j in range(k,len(c)))&MASK for k in range(len(c))]

@dataclass(frozen=True)
class Key:
    rshare:int
    sshare:int
    a:tuple[int,...]
    b:tuple[int,...]
    def to_bytes(self):
        # Profile/modes are fixed in the public manifest, not repeated per record.
        values=(self.rshare,self.sshare)+self.a+self.b
        return struct.pack('<'+'Q'*len(values),*values)
    def eval(self,spec,d,e):
        phase=(int(d)%PERIOD)*(2*np.pi/PERIOD)
        basis=[1,int(d),pow(int(d),2,Q)]
        for j in range(1,spec.modes+1):
            basis.extend((round(np.cos(j*phase)*(1<<T)),round(np.sin(j*phase)*(1<<T))))
        return sum((int(e)*a+b)*int(v) for a,b,v in zip(self.a,self.b,basis,strict=True))&MASK


def gen(spec):
    r,s=rand64(),rand64()
    a=shifted(spec.p,r)
    phase=(r%PERIOD)*(2*np.pi/PERIOD)
    for j,c in enumerate(spec.coefficients[1:],1):
        a.extend((round(c*np.cos(j*phase)*(1<<T))&MASK,round(-c*np.sin(j*phase)*(1<<T))&MASK))
    b=[s*v&MASK for v in a]
    rp,sp=split(r),split(s)
    aa=[split(v) for v in a];bb=[split(v) for v in b]
    return tuple(Key(rp[i],sp[i],tuple(v[i] for v in aa),tuple(v[i] for v in bb)) for i in (0,1))


def numeric_grid(spec,phases=32):
    # Every admissible quantized x, multiple secret phases. These evaluations
    # assess numerical accuracy only, not protocol security or masked key reuse.
    xi=np.arange(-R*(1<<F),R*(1<<F),dtype=np.int64)
    x=xi/(1<<F);ref=silu(x)
    maxerr=0.;rms=[];maxjitter=0.
    previous=None
    for r in np.linspace(0,PERIOD-1,phases,dtype=np.int64):
        d=(xi-r)%PERIOD
        phase_r=r*2*np.pi/PERIOD
        out=np.full(len(xi),spec.p[0],dtype=np.int64)+spec.p[1]*xi+spec.p[2]*xi*xi
        for j,c in enumerate(spec.coefficients[1:],1):
            a=round(c*np.cos(j*phase_r)*(1<<T));b=round(-c*np.sin(j*phase_r)*(1<<T))
            cp=np.rint(np.cos(j*d*2*np.pi/PERIOD)*(1<<T)).astype(np.int64)
            sp=np.rint(np.sin(j*d*2*np.pi/PERIOD)*(1<<T)).astype(np.int64)
            out+=a*cp+b*sp
        got=out/(1<<OUT)
        maxerr=max(maxerr,float(np.max(np.abs(got-ref))))
        rms.append(float(np.sqrt(np.mean((got-ref)**2))))
        if previous is not None:maxjitter=max(maxjitter,float(np.max(np.abs(got-previous))))
        previous=got
    # Exhaustive input-grid truncation component, separate from phase rounding.
    ideal=.5*x+spec.quadratic*x*x+spec.coefficients[0]
    for j,c in enumerate(spec.coefficients[1:],1):ideal+=c*np.cos(j*np.pi*x/R)
    truncerr=float(np.max(np.abs(ideal-ref)))
    delta=.5/(1<<T)
    # Uniform-in-mask real arithmetic bound on coefficient/basis quantization.
    # Floating-library sin/cos/FFT error is not formally interval-certified.
    rounding_bound=abs(spec.p[0]/(1<<OUT)-spec.coefficients[0])
    rounding_bound+=abs(spec.p[2]/(1<<(OUT-2*F))-spec.quadratic)*R*R
    rounding_bound+=sum(math.sqrt(2)*delta*(abs(c)+1)+2*delta*delta for c in spec.coefficients[1:])
    return dict(input_grid_points=len(xi),mask_phases=phases,evaluations=len(xi)*phases,
      max_silu_absolute_error=maxerr,mean_silu_rmse=float(np.mean(rms)),
      max_phase_to_phase_jitter=maxjitter,grid_truncation_error=truncerr,
      uniform_mask_rounding_bound_excluding_math_library_error=rounding_bound,
      gate_error_bound_for_abs_u_at_most_8=8*(truncerr+rounding_bound))


def main():
    start=perf_counter();rng=np.random.default_rng(1193);profiles=[]
    for modes in (4,8,12,16):
        spec=make_spec(modes);stats=numeric_grid(spec)
        cases=256;maxerr=0.;sizes=[];gen_time=[];eval_time=[]
        for t in range(cases):
            x=int(rng.integers(-R*(1<<F),R*(1<<F)))
            u=int(rng.integers(-R*(1<<F),R*(1<<F)))
            ti=perf_counter();keys=gen(spec);gen_time.append(perf_counter()-ti)
            sizes.append(sum(len(k.to_bytes()) for k in keys))
            xs,us=split(x),split(u)
            d=sum((xs[i]-keys[i].rshare)&MASK for i in (0,1))&MASK
            e=sum((us[i]-keys[i].sshare)&MASK for i in (0,1))&MASK
            ti=perf_counter();vals=[keys[i].eval(spec,d,e) for i in (0,1)];eval_time.append(perf_counter()-ti)
            answer=center(sum(vals))
            # Independent numeric coefficient oracle; checks exact modular gate.
            r=(keys[0].rshare+keys[1].rshare)&MASK
            phase_r=(r%PERIOD)*2*np.pi/PERIOD
            phase_d=(d%PERIOD)*2*np.pi/PERIOD
            base=spec.p[0]+spec.p[1]*x+spec.p[2]*x*x
            for j,c in enumerate(spec.coefficients[1:],1):
                a=round(c*np.cos(j*phase_r)*(1<<T));b=round(-c*np.sin(j*phase_r)*(1<<T))
                base+=a*round(np.cos(j*phase_d)*(1<<T))+b*round(np.sin(j*phase_d)*(1<<T))
            assert answer==u*base,(modes,t,answer,u*base)
            assert abs(answer)<Q//2
            expected=(u/(1<<F))*silu(x/(1<<F))
            error=abs(answer/(1<<(OUT+F))-expected)
            maxerr=max(maxerr,float(error))
        assert len(set(sizes))==1
        stats.update(modes=modes,exact_modular_gate_cases=cases,fresh_record_bytes_both_workers=sizes[0],
          online_bytes_both_directions=32,online_opening_rounds=1,
          max_observed_fused_gate_absolute_error=maxerr,
          median_preparation_ms=1000*float(np.median(gen_time)),
          median_combined_worker_eval_ms=1000*float(np.median(eval_time)))
        profiles.append(stats)
    # Out-of-range is not repaired by periodic encoding.
    spec=make_spec(12);tails=[]
    for x in (-32.,-16.,16.,32.):
        approx=.5*x+spec.quadratic*x*x+spec.coefficients[0]+sum(c*np.cos(j*np.pi*x/R) for j,c in enumerate(spec.coefficients[1:],1))
        tails.append(dict(x=x,approx=float(approx),reference=float(silu(x)),absolute_error=float(abs(approx-silu(x)))))
    result={'scope':'NEW CANDIDATE: boundary-matched polynomial-plus-Fourier shifted-coefficient fusion, with actual 64-bit full-mask two-party shares. No interval FSS or sine on a secret input online. Public cos/sin are local CPU math calls. Approximate gate, not native SiLU.',
     'parameters':dict(input_fraction_bits=F,mask_ring_bits=64,silu_numerator_fraction_bits=OUT,basis_fraction_bits=T,declared_abs_x_u_bound=R,period_in_integer_units=PERIOD),
     'profiles':profiles,'out_of_range_negative_controls':tails,'wall_seconds':perf_counter()-start,
     'limits':['Fresh masks and coefficient shares per distinct activation. Keys and masks are not retained in the artifact.',
       'Actual model activations not available: no trained-model quality, layer execution, or TPS measured.',
       'Output must still be securely rescaled; secure final truncation is NOT included in the one-round or byte claim.',
       'Public declared activation range must be guaranteed, securely enforced, or accepted as an approximation contract. Adaptive plaintext fallback is unsafe.',
       'Numerical output depends slightly on fresh mask through coefficient/basis quantization; it is not bit-identical to a deterministic SiLU LUT.',
       'Small empirical error is NOT a cryptographic security argument. Conditional privacy uses fresh full-ring pads and independent additive shares of translated coefficients.',
       'Polynomial/Fourier approximation, public-basis coefficient sharing, and shifted-function preprocessing have prior art; priority for this specific boundary-matched fusion is unestablished.',
       'The random phases do not constitute small real-valued masks: the opened values are uniform residues modulo 2^64.']}
    Path(__file__).with_name('spectral_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
