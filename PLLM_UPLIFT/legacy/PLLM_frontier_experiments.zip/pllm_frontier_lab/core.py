"""Single-process, two-party reference protocols. Not production cryptography.

All RNG is deterministic for reproducibility. No sockets or GPU implementation.
Online payload counters count both directions; offline counters count both parties.
"""
from dataclasses import dataclass
import numpy as np

K=32
Q=1<<K
MASK=np.uint64(Q-1)

@dataclass
class Cost:
    online_bytes:int=0
    offline_bytes:int=0
    rounds:int=0
    arithmetic_products:int=0
    boolean_ands:int=0
    def snapshot(self):
        return dict(self.__dict__)

class MPC:
    def __init__(self, seed=0):
        self.rng=np.random.default_rng(seed)
        self.cost=Cost()
    def rand(self, shape):
        return self.rng.integers(0,Q,shape,dtype=np.uint64)
    def share(self,x):
        x=np.asarray(x,dtype=np.int64).astype(np.uint64)&MASK
        a=self.rand(x.shape)
        return a,(x-a)&MASK
    def reconstruct(self,x):
        return (x[0]+x[1])&MASK
    def add(self,x,y):
        return (x[0]+y[0])&MASK,(x[1]+y[1])&MASK
    def sub(self,x,y):
        return (x[0]-y[0])&MASK,(x[1]-y[1])&MASK
    def scale(self,x,c):
        c=np.asarray(c,dtype=np.int64).astype(np.uint64)
        return (x[0]*c)&MASK,(x[1]*c)&MASK
    def public(self,x):
        x=np.asarray(x,dtype=np.int64).astype(np.uint64)&MASK
        return x,np.zeros_like(x)
    def open_batch(self,*xs):
        self.cost.online_bytes+=2*4*sum(x[0].size for x in xs)
        self.cost.rounds+=1
        return [self.reconstruct(x) for x in xs]
    def mul(self,x,y):
        shape=np.broadcast_shapes(x[0].shape,y[0].shape)
        a,b=self.rand(shape),self.rand(shape)
        c=(a*b)&MASK
        aa,bb,cc=self.share(a),self.share(b),self.share(c)
        self.cost.offline_bytes+=2*3*4*c.size
        self.cost.arithmetic_products+=c.size
        d,e=self.open_batch(self.sub(x,aa),self.sub(y,bb))
        z=[(cc[i]+d*bb[i]+e*aa[i])&MASK for i in range(2)]
        z[0]=(z[0]+d*e)&MASK
        return tuple(z)
    def matmul(self,x,y):
        a,b=self.rand(x[0].shape),self.rand(y[0].shape)
        c=(a@b)&MASK
        aa,bb,cc=self.share(a),self.share(b),self.share(c)
        self.cost.offline_bytes+=2*4*(a.size+b.size+c.size)
        d,e=self.open_batch(self.sub(x,aa),self.sub(y,bb))
        z=[(cc[i]+d@bb[i]+aa[i]@e)&MASK for i in range(2)]
        z[0]=(z[0]+d@e)&MASK
        return tuple(z)
    def bshare(self,x):
        x=np.asarray(x,dtype=bool)
        a=self.rng.integers(0,2,x.shape,dtype=np.uint8).astype(bool)
        return a,a^x
    def band(self,x,y):
        shape=np.broadcast_shapes(x[0].shape,y[0].shape)
        a=self.rng.integers(0,2,shape,dtype=np.uint8).astype(bool)
        b=self.rng.integers(0,2,shape,dtype=np.uint8).astype(bool)
        aa,bb,cc=self.bshare(a),self.bshare(b),self.bshare(a&b)
        d=(x[0]^aa[0])^(x[1]^aa[1]);e=(y[0]^bb[0])^(y[1]^bb[1])
        # Two n-bit openings, two directions, independently byte padded.
        n=a.size
        self.cost.online_bytes+=4*((n+7)//8)
        self.cost.offline_bytes+=6*((n+7)//8)
        self.cost.rounds+=1;self.cost.boolean_ands+=n
        return cc[0]^(d&bb[0])^(e&aa[0])^(d&e),cc[1]^(d&bb[1])^(e&aa[1])
    def a2bits(self,x,width=32):
        shifts=np.arange(width,dtype=np.uint64)
        a=((x[0][...,None]>>shifts)&np.uint64(1)).astype(bool)
        b=((x[1][...,None]>>shifts)&np.uint64(1)).astype(bool)
        zero=np.zeros_like(a)
        p=(a,b)
        original=p
        g=self.band((a,zero),(zero,b))
        offset=1
        while offset<width:
            # Compute p_hi*g_lo and p_hi*p_lo in one batched AND round.
            lx=np.concatenate((p[0][...,offset:],p[0][...,offset:]),axis=-1)
            ly=np.concatenate((p[1][...,offset:],p[1][...,offset:]),axis=-1)
            rx=np.concatenate((g[0][...,:-offset],p[0][...,:-offset]),axis=-1)
            ry=np.concatenate((g[1][...,:-offset],p[1][...,:-offset]),axis=-1)
            z=self.band((lx,ly),(rx,ry))
            n=width-offset
            g=tuple(np.concatenate((g[i][...,:offset],g[i][...,offset:]^z[i][...,:n]),axis=-1) for i in range(2))
            p=tuple(np.concatenate((p[i][...,:offset],z[i][...,n:]),axis=-1) for i in range(2))
            offset*=2
        return tuple(original[i]^np.concatenate((np.zeros_like(g[i][...,:1]),g[i][...,:-1]),axis=-1) for i in range(2))
    def b2a(self,b):
        # b0 XOR b1 = b0+b1-2*b0*b1 over the arithmetic ring.
        x=(b[0].astype(np.uint64),np.zeros_like(b[0],dtype=np.uint64))
        y=(np.zeros_like(b[1],dtype=np.uint64),b[1].astype(np.uint64))
        return self.sub(self.add(x,y),self.scale(self.mul(x,y),2))

class ImmutableOperand:
    """One immutable shared right-hand matrix; dealer keeps its random mask.

    Fresh left masks and products are generated for EVERY call. The right mask
    is used only with this exact right-hand value. A full-capacity append-only
    cache is modelled by binding each row exactly once.
    """
    def __init__(self,mpc,rows,cols):
        self.mpc=mpc
        self.mask=mpc.rand((rows,cols))
        self.mask_shares=mpc.share(self.mask)
        self.opened=np.zeros_like(self.mask)
        self.bound=np.zeros(rows,dtype=bool)
        self.pending=[]
        mpc.cost.offline_bytes+=2*4*self.mask.size
    def bind(self,start,shares,defer=False):
        n=shares[0].shape[0]
        sl=slice(start,start+n)
        if start<0 or start+n>len(self.bound) or self.bound[sl].any():
            raise ValueError('A cache row cannot be rebound: use a fresh row identity and mask.')
        m=(self.mask_shares[0][sl],self.mask_shares[1][sl])
        delta=self.mpc.sub(shares,m)
        # Reserve immutable identity before any possible exposure.
        self.bound[sl]=True
        if defer:
            self.pending.append((sl,delta))
        else:
            (e,)=self.mpc.open_batch(delta)
            self.opened[sl]=e
    def multiply(self,left,rows,transpose=False,flush_with=()):
        if rows<=0 or not self.bound[:rows].all():raise ValueError('Unbound cache row')
        mpc=self.mpc
        b=self.mask[:rows]
        if transpose:b=b.T
        a=mpc.rand(left[0].shape);c=(a@b)&MASK
        aa,cc=mpc.share(a),mpc.share(c)
        mpc.cost.offline_bytes+=2*4*(a.size+c.size)
        pending=[(cache,sl,delta) for cache in (self,)+tuple(flush_with) for sl,delta in cache.pending]
        opened=mpc.open_batch(mpc.sub(left,aa),*(delta for _,_,delta in pending))
        d=opened[0]
        for (cache,sl,_),e in zip(pending,opened[1:]):cache.opened[sl]=e
        for cache in (self,)+tuple(flush_with):cache.pending.clear()
        bs=tuple(s[:rows] for s in self.mask_shares);e=self.opened[:rows]
        if transpose:bs,e=tuple(s.T for s in bs),e.T
        z=[(cc[i]+d@bs[i]+aa[i]@e)&MASK for i in range(2)]
        z[0]=(z[0]+d@e)&MASK
        return tuple(z)
