"""Executable FSS reference, NOT production cryptography.

Standard tree DPF (Boyle et al.) -> fixed-shape prefix-DPF comparison ->
masked, piecewise bivariate polynomial gate. No table or oracle is used online.
SHAKE-256 is a domain-separated reference PRG; secret seeds use os.urandom.

Two comparison backends are implemented: independent prefix DPFs, O(n^2),
and a standard shared tree with output corrections at each prefix, O(n).
Sizes are actual serialized key payloads, excluding transport/authentication.
The correctness tests do not establish implementation security.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import shake_256
from math import comb
import os
import struct
from typing import Sequence

Q = 1 << 32
MASK = Q - 1

def xor(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b, strict=True))

def expand(s: bytes):
    z = shake_256(b'PLLM-reference-DPF-tree-v1\0' + s).digest(34)
    return ((z[:16], z[16] & 1), (z[17:33], z[33] & 1))

def convert(s: bytes, width: int) -> tuple[int, ...]:
    z = shake_256(b'PLLM-reference-DPF-leaf-v1\0' + struct.pack('<I', width) + s).digest(4 * width)
    return struct.unpack('<' + 'I' * width, z)

@dataclass(frozen=True)
class DPFKey:
    n: int
    seed: bytes
    corrections: tuple[tuple[bytes, int, int], ...]
    final: tuple[int, ...]

    def to_bytes(self) -> bytes:
        return (struct.pack('<II', self.n, len(self.final)) + self.seed
                + b''.join(s + bytes((l | (r << 1),)) for s, l, r in self.corrections)
                + struct.pack('<' + 'I' * len(self.final), *self.final))

    def eval(self, party: int, x: int) -> tuple[int, ...]:
        if party not in (0, 1) or not 0 <= x < (1 << self.n):
            raise ValueError('invalid party or DPF input')
        s, t = self.seed, party
        for i, (scw, l, r) in enumerate(self.corrections):
            bit = (x >> (self.n - 1 - i)) & 1
            child_s, child_t = expand(s)[bit]
            s = xor(child_s, scw) if t else child_s
            t = child_t ^ (t & (r if bit else l))
        leaf = convert(s, len(self.final))
        sign = 1 if party == 0 else -1
        return tuple((sign * (v + t * c)) & MASK for v, c in zip(leaf, self.final, strict=True))


def dpf_gen(n: int, alpha: int, beta: Sequence[int]) -> tuple[DPFKey, DPFKey]:
    if n < 0 or n > 32 or not 0 <= alpha < (1 << n) or not beta:
        raise ValueError('invalid DPF parameters')
    roots = [os.urandom(16), os.urandom(16)]
    seeds, control, words = roots.copy(), [0, 1], []
    for i in range(n):
        bit = (alpha >> (n - 1 - i)) & 1
        children = [expand(s) for s in seeds]
        scw = xor(children[0][1-bit][0], children[1][1-bit][0])
        lcw = children[0][0][1] ^ children[1][0][1] ^ bit ^ 1
        rcw = children[0][1][1] ^ children[1][1][1] ^ bit
        words.append((scw, lcw, rcw))
        next_s, next_t = [], []
        for j in (0, 1):
            s, t = children[j][bit]
            next_s.append(xor(s, scw) if control[j] else s)
            next_t.append(t ^ (control[j] & (rcw if bit else lcw)))
        seeds, control = next_s, next_t
    z0, z1 = convert(seeds[0], len(beta)), convert(seeds[1], len(beta))
    sign = -1 if control[1] else 1
    final = tuple((sign * (b - a + c)) & MASK for b, a, c in zip(beta, z0, z1, strict=True))
    return tuple(DPFKey(n, roots[j], tuple(words), final) for j in (0, 1))

@dataclass(frozen=True)
class DCFKey:
    n: int
    points: tuple[DPFKey, ...]
    width: int

    def to_bytes(self) -> bytes:
        return struct.pack('<II', self.n, self.width) + b''.join(k.to_bytes() for k in self.points)

    def eval(self, party: int, x: int) -> tuple[int, ...]:
        if not 0 <= x < (1 << self.n):
            raise ValueError('invalid DCF input')
        out = [0] * self.width
        # Branch depends only on the publicly opened masked x.
        for i, key in enumerate(self.points):
            bit = (x >> (self.n - 1 - i)) & 1
            v = key.eval(party, x >> (self.n - i))
            if not bit:
                out = [(a + b) & MASK for a, b in zip(out, v, strict=True)]
        return tuple(out)


def dcf_gen(n: int, alpha: int, beta: Sequence[int]) -> tuple[DCFKey, DCFKey]:
    if not 1 <= n <= 32 or not 0 <= alpha < (1 << n):
        raise ValueError('invalid threshold')
    lists = [[], []]
    for i in range(n):
        bit = (alpha >> (n - 1 - i)) & 1
        pair = dpf_gen(i, alpha >> (n - i), [int(v) * bit for v in beta])
        for j in (0, 1):
            lists[j].append(pair[j])
    return tuple(DCFKey(n, tuple(lists[j]), len(beta)) for j in (0, 1))


@dataclass(frozen=True)
class TreeDCFKey:
    """One shared DPF tree with an output correction at EVERY prefix.

    This is the standard linear-size comparison extension, not a new primitive.
    Public zero bits query the sibling with next bit one; traverse actual x.
    """
    n: int
    seed: bytes
    corrections: tuple[tuple[bytes, int, int, tuple[int, ...]], ...]
    width: int

    def to_bytes(self) -> bytes:
        return (struct.pack('<II', self.n, self.width) + self.seed
          + b''.join(s+bytes((l|(r<<1),))+struct.pack('<'+'I'*self.width,*v)
                     for s,l,r,v in self.corrections))

    def eval(self, party: int, x: int) -> tuple[int, ...]:
        if party not in (0,1) or not 0 <= x < (1 << self.n):
            raise ValueError('invalid DCF input')
        seed, control, out = self.seed, party, [0]*self.width
        sign = 1 if party==0 else -1
        for i,(scw,lcw,rcw,vcw) in enumerate(self.corrections):
            child=[]
            for b,(s,t) in enumerate(expand(seed)):
                child.append((xor(s,scw) if control else s,t^(control&(rcw if b else lcw))))
            bit=(x>>(self.n-1-i))&1
            # Calculate every local output to keep a fixed operation count.
            s,t=child[1]; v=convert(s,self.width)
            contribution=tuple((sign*(a+t*b))&MASK for a,b in zip(v,vcw,strict=True))
            out=[(a+(1-bit)*b)&MASK for a,b in zip(out,contribution,strict=True)]
            seed,control=child[bit]
        return tuple(out)


def tree_dcf_gen(n: int, alpha: int, beta: Sequence[int]) -> tuple[TreeDCFKey, TreeDCFKey]:
    if not 1 <= n <= 32 or not 0 <= alpha < (1 << n) or not beta:
        raise ValueError('invalid comparison parameters')
    roots=[os.urandom(16),os.urandom(16)]
    seeds,control,words=roots.copy(),[0,1],[]
    for i in range(n):
        bit=(alpha>>(n-1-i))&1
        children=[expand(s) for s in seeds]
        scw=xor(children[0][1-bit][0],children[1][1-bit][0])
        lcw=children[0][0][1]^children[1][0][1]^bit^1
        rcw=children[0][1][1]^children[1][1][1]^bit
        next_s,next_t=[],[]
        for j in (0,1):
            s,t=children[j][bit]
            next_s.append(xor(s,scw) if control[j] else s)
            next_t.append(t^(control[j]&(rcw if bit else lcw)))
        seeds,control=next_s,next_t
        v0,v1=convert(seeds[0],len(beta)),convert(seeds[1],len(beta))
        sign=-1 if control[1] else 1
        vcw=tuple((sign*(b-a+c))&MASK for b,a,c in zip(beta,v0,v1,strict=True))
        words.append((scw,lcw,rcw,vcw))
    return tuple(TreeDCFKey(n,roots[j],tuple(words),len(beta)) for j in (0,1))


def signed(x: int, n: int) -> int:
    x %= 1 << n
    return x - (1 << n) if x >= (1 << (n-1)) else x


def polynomial(coefficients: Sequence[int], x: int) -> int:
    y = 0
    for c in reversed(coefficients):
        y = (y * x + int(c)) & MASK
    return y

@dataclass(frozen=True)
class GateKey:
    n: int
    degree: int
    x_mask_share: int
    u_mask_share: int
    base: tuple[int, ...]
    steps: tuple[DCFKey | TreeDCFKey, ...]

    def to_bytes(self) -> bytes:
        head = struct.pack('<IIIII', self.n, self.degree, self.x_mask_share, self.u_mask_share, len(self.steps))
        return head + struct.pack('<' + 'I'*len(self.base), *self.base) + b''.join(s.to_bytes() for s in self.steps)

    def eval(self, party: int, d: int, e: int) -> int:
        coeffs = list(self.base)
        for key in self.steps:
            coeffs = [(a+b) & MASK for a,b in zip(coeffs, key.eval(party,d), strict=True)]
        count = self.degree + 1
        return (int(e) * polynomial(coeffs[:count], d) + polynomial(coeffs[count:], d)) & MASK


def gate_gen(n: int, breaks: Sequence[int], polys: Sequence[Sequence[int]], backend: str = 'tree') -> tuple[GateKey, GateKey]:
    """Generate fresh keys for u * P_i(signed_n(x)), output in Z_(2^32).

    Signed intervals [breaks[i], breaks[i+1]) cover the input ring; same degree.
    No model matrix or secret activation is used by the key generator.
    """
    if not 2 <= n <= 32 or len(breaks) != len(polys)+1:
        raise ValueError('invalid intervals')
    if breaks[0] != -(1 << (n-1)) or breaks[-1] != 1 << (n-1):
        raise ValueError('intervals must cover signed ring')
    if any(a >= b for a,b in zip(breaks[:-1],breaks[1:],strict=True)):
        raise ValueError('intervals must be strictly ordered')
    degree = len(polys[0])-1
    if any(len(p) != degree+1 for p in polys):
        raise ValueError('use fixed public polynomial degree')
    if backend not in ('tree','prefix'):
        raise ValueError('unknown comparison backend')
    qin=1 << n
    r=int.from_bytes(os.urandom(4),'little') % qin
    s=int.from_bytes(os.urandom(4),'little')
    rx=int.from_bytes(os.urandom(4),'little') % qin
    su=int.from_bytes(os.urandom(4),'little')
    # A cyclic translation of J source intervals has at most J internal boundaries.
    boundaries=sorted({(int(b)-r)%qin for b in breaks[:-1]} - {0})
    starts=[0]+boundaries
    payloads=[]
    for d in starts:
        x=signed(d+r,n)
        index=next(i for i in range(len(polys)) if breaks[i] <= x < breaks[i+1])
        h=x-d
        a=[sum(int(polys[index][j])*comb(j,k)*pow(h,j-k,Q) for j in range(k,degree+1)) & MASK
           for k in range(degree+1)]
        payloads.append(tuple(a+[(s*v)&MASK for v in a]))
    random_base=tuple(int.from_bytes(os.urandom(4),'little') for _ in payloads[-1])
    base_pair=(random_base, tuple((v-z)&MASK for v,z in zip(payloads[-1],random_base,strict=True)))
    step_lists=[[],[]]
    for i in range(len(polys)):
        if i < len(boundaries):
            boundary=boundaries[i]
            delta=tuple((a-b)&MASK for a,b in zip(payloads[i],payloads[i+1],strict=True))
        else:
            boundary=0
            delta=(0,)*len(random_base)
        pair=(tree_dcf_gen if backend=='tree' else dcf_gen)(n,boundary,delta)
        for j in (0,1):
            step_lists[j].append(pair[j])
    return tuple(GateKey(n,degree,rx if j==0 else (r-rx)%qin,su if j==0 else (s-su)&MASK,
                         base_pair[j],tuple(step_lists[j])) for j in (0,1))
