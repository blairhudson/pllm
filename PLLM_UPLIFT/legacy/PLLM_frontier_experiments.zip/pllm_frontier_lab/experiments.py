"""Run bounded, reproducible experiments; no LLM/GPU/production-security claims."""
import json, math, platform, time
from collections import Counter
from pathlib import Path
import numpy as np
from core import MPC, ImmutableOperand, Q, MASK
ROOT=Path(__file__).parent
np.seterr(over='ignore')  # uint64 wrap is intentional; outputs are reduced modulo 2^32.

def cached_kv():
    rng=np.random.default_rng(714)
    exact=0;reject=0;totbase=Counter();totcache=Counter()
    for seed in range(8):
        old,steps,d=32,24,16
        n=old+steps
        K=rng.integers(-128,128,(n,d));V=rng.integers(-128,128,(n,d))
        base,cache=MPC(seed),MPC(seed+100)
        kb,vb=base.share(K),base.share(V)
        ks,vs=cache.share(K),cache.share(V)
        kc,vc=ImmutableOperand(cache,n,d),ImmutableOperand(cache,n,d)
        kc.bind(0,tuple(s[:old] for s in ks),defer=True);vc.bind(0,tuple(s[:old] for s in vs),defer=True)
        for t in range(old,n):
            L=t+1
            kc.bind(t,tuple(s[t:t+1] for s in ks),defer=True);vc.bind(t,tuple(s[t:t+1] for s in vs),defer=True)
            q=rng.integers(-16,16,(1,d));a=rng.integers(0,256,(1,L))
            y=cache.reconstruct(kc.multiply(cache.share(q),L,True,flush_with=(vc,)))
            yb=base.reconstruct(base.matmul(base.share(q),tuple(s[:L].T for s in kb)))
            ref=(q.astype(np.uint64)@K[:L].astype(np.uint64).T)&MASK
            assert np.array_equal(y,ref) and np.array_equal(yb,ref);exact+=1
            y=cache.reconstruct(vc.multiply(cache.share(a),L))
            yb=base.reconstruct(base.matmul(base.share(a),tuple(s[:L] for s in vb)))
            ref=(a.astype(np.uint64)@V[:L].astype(np.uint64))&MASK
            assert np.array_equal(y,ref) and np.array_equal(yb,ref);exact+=1
            try: kc.bind(t,tuple(s[t:t+1] for s in ks))
            except ValueError:reject+=1
            else:raise AssertionError('Rebinding accepted')
        totbase.update(base.cost.snapshot());totcache.update(cache.cost.snapshot())
    # Exhaustive public-opening distribution, ONE immutable operand and TWO fresh left masks.
    # This tests only the public opening marginal, not a full simulation proof.
    histograms=[]
    for x0,x1,b in [(0,0,0),(0,1,1),(1,0,2),(2,3,1)]:
        h=Counter()
        for a0 in range(4):
            for a1 in range(4):
                for bm in range(4):h[((x0-a0)%4,(x1-a1)%4,(b-bm)%4)]+=1
        histograms.append(h)
    assert all(h==histograms[0] for h in histograms)
    # Negative control: same right mask with a changed right operand.
    b0,b1,mask=17,93,101
    leak=((b1-mask)-(b0-mask))%256
    assert leak==(b1-b0)%256
    projections=[]
    for L in [1024,4096,8192,32768]:
        # Qwen2.5-0.5B public configuration; formulas only, NOT model measurements.
        layers,hq,hkv,d=24,14,2,64
        naive=layers*8*(2*hkv*L*d+hq*d+hq*L)
        cached=layers*8*(2*hkv*d+hq*d+hq*L)
        initial=layers*8*2*hkv*L*d
        prep_fresh_ac=layers*8*(hq*d+hq*L+hq*L+hq*d)
        projections.append(dict(context=L,naive_private_matmul_online_bytes=naive,
          cached_steady_state_online_bytes=cached,initial_cache_opening_bytes=initial,
          fresh_A_C_shares_per_step_offline_bytes=prep_fresh_ac,
          ratio=naive/cached,serial_ms_at_100gbit=cached*8/1e8))
    return dict(exact_matmul_pairs=exact,rebind_rejections=reject,baseline_cost=dict(totbase),
      cached_cost=dict(totcache),online_reduction=1-totcache['online_bytes']/totbase['online_bytes'],
      small_ring_public_view_histograms_equal=True,append_openings_fused_with_query=True,changed_operand_negative_control_delta=leak,
      projections=projections,
      limits='Fresh input-independent A,C for EVERY multiply; cache-only mask B is persistent. '
      'Counts exclude normalization, exponentiation, truncation, integrity, transport and model kernels. '
      'No whole-protocol security proof; no matrix-state changes under an existing cache-row identity.')

def late_normalization():
    rng=np.random.default_rng(228)
    rows=[];exact=0;maxdiff=0.
    for L in [64,512,4096]:
        earlyerr=[];lateerr=[];fixed_diffs=0
        for t in range(20):
            scores=rng.normal(0,[1.,3.,6.][t%3],L)
            values=rng.normal(0,1,(L,64))
            e=np.exp(scores-scores.max());p=e/e.sum();ref=p@values
            late=(e@values)/e.sum()
            diff=float(np.max(np.abs(late-ref)));maxdiff=max(maxdiff,diff)
            assert np.allclose(late,ref,rtol=1e-12,atol=1e-12);exact+=1
            # Reference fixed-point sensitivity, not a secure reciprocal implementation.
            ei=np.rint(e*65536).astype(np.int64);vi=np.rint(values*4096).astype(np.int64)
            S=int(ei.sum());assert S>0
            pi=np.rint(ei.astype(float)*4096/S).astype(np.int64)
            early=(pi@vi)/(4096.*4096.)
            latefixed=(ei@vi)/(float(S)*4096.)
            earlyerr.append(float(np.sqrt(np.mean((early-ref)**2))))
            lateerr.append(float(np.sqrt(np.mean((latefixed-ref)**2))))
            fixed_diffs+=int(not np.array_equal(early,latefixed))
        rows.append(dict(context=L,dimensions=64,normalization_secret_products_before=L,
          normalization_secret_products_after=64,mean_early_rmse=float(np.mean(earlyerr)),
          mean_late_rmse=float(np.mean(lateerr)),changed_fixedpoint_results=fixed_diffs))
    # Exact finite-field algebra: inverse(sum(e)) before versus after private matmul.
    pfield=65521
    for _ in range(100):
        e=rng.integers(1,100,32).astype(object);v=rng.integers(-100,100,(32,8)).astype(object)
        den=int(sum(e))%pfield;inv=pow(den,-1,pfield)
        assert np.array_equal(((e*inv)%pfield@v)%pfield,((e@v)*inv)%pfield)
    return dict(float64_cases=exact,max_float64_absolute_difference=maxdiff,
      exact_field_cases=100,fixedpoint_sensitivity=rows,
      limits='Changes rounding order: not bit-identical to the original quantized graph. '
      'Still requires private exponentiation, a reciprocal and weighted-sum computation. '
      'The reciprocal and numerator product may run in parallel; circuit scheduling was not benchmarked.')

def shifted_poly_coefficients(c,r,q=Q):
    d=len(c)-1
    return [sum(int(c[i])*math.comb(i,j)*pow(int(r),i-j,q) for i in range(j,d+1))%q for j in range(d+1)]

def fused_polynomial():
    rng=np.random.default_rng(311);mpc=MPC(932);cases=0;opening_rounds=0
    for degree in [2,3,5,7]:
        for _ in range(100):
            c=rng.integers(-8,9,degree+1).tolist();r,s=[int(v) for v in mpc.rand((2,))]
            x,u=[int(v) for v in mpc.rand((2,))]
            aa=shifted_poly_coefficients(c,r);bb=[s*a%Q for a in aa]
            ash,bsh=mpc.share(aa),mpc.share(bb)
            rsh,ssh=mpc.share(r),mpc.share(s)
            d,e=mpc.open_batch(mpc.sub(mpc.share(x),rsh),mpc.sub(mpc.share(u),ssh));opening_rounds+=1
            d,e=int(d),int(e)
            z=[sum((int(ash[i][j])*e+int(bsh[i][j]))*pow(d,j,Q) for j in range(degree+1))%Q for i in range(2)]
            expected=u*sum(int(c[j])*pow(x,j,Q) for j in range(degree+1))%Q
            assert sum(z)%Q==expected;cases+=1
    # A REAL dense-table function-sharing implementation on an 8-bit gate domain.
    # Each party receives a uniformly random share of every payload row.
    # This is deliberately NOT a compact DPF/DCF implementation.
    piece_cases=0;max_table_bytes=0
    for _ in range(64):
        degree=3;r=int(rng.integers(0,256));s=int(mpc.rand(()));table=[]
        polynomials=[[0,0,0,0],[1,2,1,-1],[2,-1,0,1],[0,1,0,0]]
        for d in range(256):
            x=((d+r+128)%256)-128
            idx=(x+128)//64;h=x-d
            aa=shifted_poly_coefficients(polynomials[idx],h)
            table.append(aa+[s*a%Q for a in aa])
        ts=mpc.share(table);max_table_bytes=max(max_table_bytes,2*4*np.prod(ts[0].shape))
        x=int(rng.integers(-128,128));u=int(mpc.rand(()));d=(x-r)%256;e=(u-s)%Q
        # d/e correspond to one batched masked input opening (different input rings).
        z=[]
        for i in range(2):
            row=ts[i][d];z.append(sum((int(row[j])*e+int(row[j+degree+1]))*pow(d,j,Q) for j in range(degree+1))%Q)
        c=polynomials[(x+128)//64]
        expected=u*sum(c[j]*pow(x,j,Q) for j in range(degree+1))%Q
        assert sum(z)%Q==expected;piece_cases+=1
    # Global SiLU approximations: test the whole declared domain and its tails.
    from numpy.polynomial import Chebyshev
    grid=np.linspace(-8,8,4097)
    silu=lambda x:x/(1+np.exp(-np.clip(x,-700,700)))
    approx=[]
    for degree in [3,5,7,9]:
        fit=Chebyshev.fit(grid,silu(grid),degree,domain=[-8,8])
        inerr=np.abs(fit(grid)-silu(grid));tails=np.array([-32.,-16.,16.,32.])
        approx.append(dict(degree=degree,max_abs_error_inside=float(inerr.max()),
         max_abs_error_at_tail_points=float(np.max(np.abs(fit(tails)-silu(tails)))),
         tail_values=fit(tails).tolist()))
    return dict(global_ring_cases=cases,global_opening_rounds=opening_rounds,
      piecewise_dense_fss_cases=piece_cases,dense_fss_payload_bytes_per_scalar_gate=int(max_table_bytes),
      polynomial_approximation=approx,
      global_cost_formula='Online: 2 input scalars opened = 16 bytes at 32 bits, one round. '
      'Offline: both shares of 2 masks + 2*(degree+1) coefficients = 8*(2+2*(degree+1)) bytes.',
      limits='Exact only for specified ring polynomials. Dense-table FSS is not scalable. '
      'A separate compact_fss.py implementation is tested by fss_experiments.py. '
      'Authenticated preprocessing, fixed-point range/precision and final truncation are not implemented here. '
      'No trained-model quality test.')

def cdf_sampling():
    rng=np.random.default_rng(121);cases=0;costs=Counter();max_tv=0.;grid_cases=0
    for t in range(128):
        V=[8,16,32,64][t%4];d=12;b=8;M=1<<b
        w=rng.integers(0,512,V,dtype=np.int64);w[t%V]+=1
        S=int(w.sum());C=np.cumsum(w);U=int(rng.integers(0,M))
        assert M*S < Q//2
        mpc=MPC(801+t);ws=mpc.share(w)
        cs=tuple(np.cumsum(s,dtype=np.uint64)&MASK for s in ws)
        ss=tuple(s[-1] for s in cs)
        # U is a public, input-independent unbiased test coin. A deployment must
        # specify its generation; public U does not expose private prefix sums.
        z=mpc.sub(mpc.scale(cs,M),mpc.scale(ss,U))
        z=mpc.sub(z,mpc.public(np.ones(V,dtype=np.int64)))
        bits=mpc.a2bits(z)
        ge=(~bits[0][...,-1],bits[1][...,-1])
        threshold=mpc.b2a(ge)
        onehot=tuple((s-np.r_[np.uint64(0),s[:-1]])&MASK for s in threshold)
        h=mpc.reconstruct(onehot)
        idx=int(np.argmax(M*C>U*S))
        assert int(h.sum())==1 and int(h.argmax())==idx
        E=rng.integers(-64,64,(V,d),dtype=np.int64).astype(np.uint64)&MASK
        es=tuple((s@E)&MASK for s in onehot)
        assert np.array_equal(mpc.reconstruct(es),E[idx]);cases+=1
        costs.update(mpc.cost.snapshot())
        # Enumerate finite random coins. Bound pertains ONLY to integer weights.
        hist=np.bincount([int(np.argmax(M*C>u*S)) for u in range(M)],minlength=V)
        tv=float(.5*np.abs(hist/M-w/S).sum());max_tv=max(max_tv,tv)
        assert tv <= (V-1)/M + 1e-12;grid_cases+=1
    # Exact power-of-two mass case gives exact categorical distribution on grid.
    w=np.array([16,32,64,144]);C=w.cumsum();hist=np.bincount([int(np.argmax(256*C>u*256)) for u in range(256)],minlength=4)
    assert np.array_equal(hist,w)
    # Boolean conversion independent test, full-width random values and edge cases.
    mpc=MPC(8001);vals=np.r_[np.arange(1024,dtype=np.uint64),np.array([0,Q//2-1,Q//2,Q-1],dtype=np.uint64),mpc.rand((4096,))]
    bs=mpc.a2bits(mpc.share(vals));rb=bs[0]^bs[1]
    result=np.sum(rb.astype(np.uint64)*(np.uint64(1)<<np.arange(32,dtype=np.uint64)),axis=-1)
    assert np.array_equal(result,vals)
    return dict(sampling_and_embedding_cases=cases,arithmetic_to_binary_cases=len(vals),
      exact_power_of_two_distribution=True,enumerated_distribution_cases=grid_cases,
      maximum_observed_total_variation_at_8bit_grid=max_tv,total_circuit_cost=dict(costs),
      circuit_rounds_per_case=costs['rounds']/cases,
      large_vocabulary_example=dict(vocabulary=151936,coin_bits=48,
        conservative_grid_tv_bound=151935/2**48,
        note='Bound excludes exp/weight quantization and top-p; 48-bit coin requires wider comparison arithmetic.'),
      limits='Uses actual Boolean Beaver ANDs, parallel-prefix A2B and arithmetic B2A in simulation, '
      'not a comparison oracle. Public randomness is independent of inputs. '
      'Unnormalized INTEGER weights are supplied, not privately exponentiated logits. '
      'No greedy/top-k/top-p. Embedding is a full dense public-table scan on each worker.')

def limb_matvec(W,x,k,block=512):
    out=np.zeros(W.shape[0],dtype=np.uint64)
    mask=np.uint64((1<<k)-1)
    for bit in range(0,k,8):
        shift=(np.asarray(x,dtype=np.uint64)>>np.uint64(bit))&np.uint64(255)
        for lo in range(0,W.shape[1],block):
            w=W[:,lo:lo+block]
            v=shift[lo:lo+block].astype(np.int16)-128
            prod=w.astype(np.float32)@v.astype(np.float32)
            # Every product and any partial sum is exact within the 24-bit
            # significand bound because block<=512 and |w|,|v|<=128.
            integer=prod.astype(np.int64)+128*w.astype(np.int64).sum(axis=1)
            out=(out+(integer.astype(np.uint64)<<np.uint64(bit)))&mask
    return out

def native_limb_and_truncation():
    rng=np.random.default_rng(712);exact=0;naive_mismatch=0;coordinates=0
    for k in [16,24,32]:
        for n in [64,576,2048]:
            for _ in range(20):
                W=rng.integers(-128,128,(32,n),dtype=np.int16).astype(np.int8)
                x=rng.integers(0,1<<k,n,dtype=np.uint64)
                ref=(W.astype(np.int64)@x.astype(np.int64)).astype(np.uint64)&np.uint64((1<<k)-1)
                got=limb_matvec(W,x,k)
                assert np.array_equal(got,ref);exact+=1
                naive=(W.astype(np.float32)@x.astype(np.float32)).astype(np.int64).astype(np.uint64)&np.uint64((1<<k)-1)
                naive_mismatch+=int(np.count_nonzero(naive!=ref));coordinates+=len(ref)
    a=np.arange(256,dtype=np.int64)[:,None];b=np.arange(256,dtype=np.int64)[None,:]
    target=((a+b)%256)>>4
    bad=((a>>4)+(b>>4))%16
    carry=((a%16+b%16)>=16)
    corrected=(bad+carry)%16
    assert np.array_equal(corrected,target)
    # Low-bit secure carry via Boolean shared sum; carry-out from f+1-bit adder.
    mpc=MPC(751);a=rng.integers(0,16,4096,dtype=np.uint64);b=rng.integers(0,16,4096,dtype=np.uint64)
    bits=mpc.a2bits((a,b),width=5)
    c=(bits[0]^bits[1])[...,-1]
    assert np.array_equal(c,(a+b)>=16)
    return dict(exact_limb_matvec_cases=exact,naive_fp32_wrong_coordinates=naive_mismatch,
      naive_fp32_tested_coordinates=coordinates,limb_passes_per_worker={'16bit':2,'24bit':3,'32bit':4},
      exhaustive_truncation_cases=65536,naive_local_shift_failures=int(np.count_nonzero(target!=bad)),
      carry_corrected_cases=65536,secure_lowbit_carry_cases=4096,secure_carry_cost=mpc.cost.snapshot(),
      limits='CPU NumPy uses bounded FP32 integer dots as a reference, NOT GPU INT8 Tensor Core kernels. '
      'Ring-narrowing truncation still needs secure carry; widening/sign extension may need more protocols. '
      'Limb passes add work and no near-native throughput is established.')

def warmstart_norm():
    rng=np.random.default_rng(919)
    variance=np.exp(np.cumsum(rng.normal(0,.025,256)))
    stress=variance.copy();stress[[41,113,191]]*=64;stress[[42,114,192]]/=64
    cases=[]
    for label,v in [('smooth',variance),('scale_jumps',stress)]:
        for iterations in [1,2,3]:
            errors=[];wrong_sign=0;divergent=0
            for t in range(1,len(v)):
                # Optimistic: previous scalar is exact, rather than accumulating error.
                r=1/math.sqrt(v[t-1]);s=v[t]
                for _ in range(iterations):r=r*(1.5-.5*s*r*r)
                err=abs(r*math.sqrt(s)-1);errors.append(err)
                wrong_sign+=int(r<=0);divergent+=int(err>1)
            cases.append(dict(trace=label,iterations=iterations,steps=255,
              median_relative_error=float(np.median(errors)),max_relative_error=float(max(errors)),
              wrong_sign_count=wrong_sign,error_over_one_count=divergent))
    # Universal convergence cannot follow from smooth calibration traces.
    r=1.;s=16.;new=r*(1.5-.5*s*r*r)
    assert new<0
    return dict(results=cases,explicit_counterexample=dict(previous_variance=1,new_variance=16,
      one_iteration_estimate=new,true_inverse_sqrt=.25),
      conclusion='Reject as an unconditional drop-in. Range checks/fixed robust iterations remain necessary; '
      'a visible adaptive fallback creates new input-dependent metadata.')

def phi(x,c):
    x=np.asarray(x);pieces=[np.full((*x.shape[:-1],1),c),math.sqrt(2*c)*x]
    for i in range(x.shape[-1]):
        for j in range(i,x.shape[-1]):pieces.append((x[...,i]*x[...,j]*(1 if i==j else math.sqrt(2)))[...,None])
    return np.concatenate(pieces,axis=-1)

def recurrent_attention():
    rng=np.random.default_rng(678);cases=[];exact=0
    for L in [64,512]:
        for sigma in [.25,1.,2.]:
            for c in [1.,5.,8.]:
                rel=[];cos=[];mass=[]
                for _ in range(12):
                    d=8;dv=16
                    K=rng.normal(0,math.sqrt(sigma)/d**.25,(L,d));q=rng.normal(0,math.sqrt(sigma)/d**.25,d)
                    V=rng.normal(0,1,(L,dv));scores=K@q
                    pk,pq=phi(K,c),phi(q,c)
                    state=pk.T@V;den=pk.sum(axis=0)
                    y=pq@state/(pq@den)
                    wt=(scores+c)**2;quad=wt@V/wt.sum()
                    assert np.allclose(y,quad,rtol=1e-11,atol=1e-11);exact+=1
                    p=np.exp(scores-scores.max());p/=p.sum();ref=p@V
                    rel.append(float(np.linalg.norm(y-ref)/max(np.linalg.norm(ref),1e-12)))
                    cos.append(float(np.dot(y,ref)/max(np.linalg.norm(y)*np.linalg.norm(ref),1e-12)))
                    mass.append(float(.5*np.abs(wt/wt.sum()-p).sum()))
                cases.append(dict(context=L,score_scale=sigma,shift=c,feature_dimension=45,
                  mean_relative_output_error=float(np.mean(rel)),mean_cosine=float(np.mean(cos)),
                  mean_attention_total_variation=float(np.mean(mass))))
    # Ranking reversal is deterministic, not a random approximation outlier.
    s=np.array([-12.,0.]);quad=(s+5)**2;sm=np.exp(s-s.max())
    assert int(quad.argmax())!=int(sm.argmax())
    return dict(exact_quadratic_kernel_cases=exact,softmax_comparisons=cases,
      ranking_counterexample=dict(logits=s.tolist(),quadratic_weights=quad.tolist()),
      limits='State size no longer grows with context for the CHANGED kernel. '
      'It is not exact softmax attention; model distillation and downstream evaluation are mandatory. '
      'Secure feature construction/state updates and division were not implemented.')

def privacy_failures():
    rng=np.random.default_rng(925)
    # A random orthogonal transform preserves norms; two candidate inputs distinguish exactly.
    seen=0
    for _ in range(100):
        A=rng.normal(size=(16,16));O,_=np.linalg.qr(A)
        bit=int(rng.integers(0,2));x=np.zeros(16);x[0]=1+bit
        y=O@x
        seen+=int((np.linalg.norm(y)>1.5)==bool(bit))
    # Bounded additive masks have distinguishable supports (exact enumeration).
    M=127;delta=64
    p=Counter(range(-M,M+1));q=Counter(range(-M+delta,M+delta+1));keys=p.keys()|q.keys()
    tv=.5*sum(abs(p[k]-q[k]) for k in keys)/(2*M+1)
    # Data-dependent approximate/exact route is itself one leaked bit.
    a=np.array([20.,0.]);b=np.array([.01,0.])
    gate=lambda z: bool(np.sort(z)[-1]-np.sort(z)[-2]>1)
    assert gate(a)!=gate(b)
    return dict(rotation_candidate_distinguishing_successes=seen,trials=100,
      bounded_mask_exact_total_variation=tv,mask_support_size=255,secret_shift=delta,
      visible_fallback_distinguishes_example=True,
      conclusion='Reject small floating-point masks/secret rotations as cryptographic privacy substitutes. '
      'Do not expose data-dependent approximation fallback or profile choice without changing the leakage contract.')

def main():
    results={'environment':{'python':platform.python_version(),'numpy':np.__version__,
      'platform':platform.platform(),'gpu_used':False,'network_sockets':False,
      'real_model_weights_used':False},
      'scope':'Single-process exact arithmetic/Boolean protocols, operation/payload accounting and synthetic numerical stress tests. '
      'No native/private TPS, no complete transformer, no trained-model quality result, no malicious-security claim.'}
    for fn in [cached_kv,late_normalization,fused_polynomial,cdf_sampling,native_limb_and_truncation,
               warmstart_norm,recurrent_attention,privacy_failures]:
        t=time.perf_counter();results[fn.__name__]=fn();results[fn.__name__]['wall_seconds']=time.perf_counter()-t
        (ROOT/'results.json').write_text(json.dumps(results,indent=2))
        print(fn.__name__,round(time.perf_counter()-t,3),'seconds',flush=True)
    print(json.dumps({k:v for k,v in results.items() if k=='scope'}))
if __name__=='__main__':main()
