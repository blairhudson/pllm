# PLLM: experiments on the remaining communication and computation bottlenecks

**Research notebook and executable reference implementations — 13 September 2026**

## Main result

Two candidates deserve further implementation: **immutable-operand preprocessing for resident KV caches**, and **a boundary-matched polynomial-plus-Fourier gate that trades private interval lookup for locally evaluated public basis functions**. Delaying attention normalization and carrying secret token selection directly into the next embedding are complementary changes.

These experiments do **not** demonstrate near-native LLM throughput. They establish exact arithmetic identities, execute simulated secure subprotocols, measure serialized reference key sizes, explore approximation quality on synthetic inputs, and deliberately test failure cases. No complete transformer, trained-model activation trace, GPU, network connection, or actively secure deployment was evaluated. Public-model two-worker execution remains the architecture; neither the Client nor the preprocessing dealer needs a weight matrix. Both inference workers hold the public model. The dealer must not obtain their online openings, and the workers must not collude.

## Reproduce

Requires Python 3.11+ and NumPy (captured environment: Python 3.13.5, NumPy 2.3.5, CPU Linux).

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python experiments.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python fss_experiments.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python spectral_gate.py
```

Each script writes its own JSON results beside its source. Timings are local Python reference timings, not GPU or LLM performance. The main simulated MPC experiment uses deterministic test randomness; it is unsuitable for deployment. The compact FSS and spectral gate implementations use fresh operating-system entropy for secret key material and seeded synthetic test inputs. Rerunning therefore preserves the tested properties and fixed payload sizes, but not identical secret messages or all numeric timing/error samples. No generated secret keys are included in this package.

| File | Content |
|---|---|
| `core.py` | Arithmetic and Boolean Beaver reference protocols, arithmetic/Boolean conversions, immutable masked operand |
| `experiments.py`, `results.json` | Cache, normalization, polynomial fusion, sampling, limb kernels, truncation, numerical and privacy negative controls |
| `compact_fss.py` | Standard tree DPF, quadratic-size prefix DCF, linear-size tree DCF, shifted piecewise polynomial gate |
| `fss_experiments.py`, `fss_results.json` | Exhaustive small-domain primitive checks and wider-ring gate checks |
| `spectral_gate.py`, `spectral_results.json` | Boundary-matched spectral gate, real full-width additive masking, finite-grid accuracy and tail tests |
| `DESIGN.md` | Detailed construction, cost interpretation, prior art, and next implementation requirements |

## Captured findings

| Direction | Evidence | Decision |
|---|---|---|
| Immutable KV masks with fresh left-hand correlations; fuse append openings | 384 cached products and matching baseline products exact; 2,280,192 → 207,616 online payload bytes; 384 → 384 rounds | Highest-priority exact systems change |
| Polynomial-plus-Fourier fused SiLU-times-input | 12-mode profile: 896 preprocessing bytes, 32 online bytes, one opening; ~5.4e-6 maximum SiLU error on the tested quantized grid/phases | Most interesting additional research candidate; range and rescaling remain material |
| Normalize after attention's weighted sum | 60 float and 100 field cases agree; 4,096 → 64 normalization multiplications for the selected shape | Implement with explicit rounding semantics |
| Compact piecewise polynomial fusion | 1,264 gate evaluations exact; real DPF/DCF implementation; one opening; 6,568 bytes/key pair for 16-bit input and four cubic intervals | Working comparison backend, but expensive preprocessing |
| Division-free sampling followed by secret embedding | 128 exact integer-weight selection/embedding cases; actual seven-round Boolean/arithmetic circuit | Useful token-loop design; not a complete softmax/top-p implementation |
| Byte-sliced integer kernels and exact carry | 180 matrix/vector cases exact; naive local truncation fails 46.875% of exhaustive small-ring cases | Necessary numeric foundation, not a free native-kernel shortcut |
| Previous-token inverse-square-root warm start | Smooth cases work; variance jumps create wrong-sign/divergent estimates | Reject unchecked shortcut |
| Recurrent quadratic attention | Exact for the replacement kernel, but substantial deviations from softmax and an ordering counterexample | Distillation/retraining track only |
| Rotations, bounded masks, visible adaptive fallback | Explicit distinguishing examples | Reject as cryptographic-privacy substitutes |

**Do not multiply the separate savings into an end-to-end speedup.** Components have different baselines, domains, numerical semantics, payload phases and ring widths. The strongest percentages are against explicit elementary protocols or toy representations, not measured superiority over a current optimized secure-inference system.
