"""Run exhaustive small-domain and wider-domain tests of compact_fss.py."""
import json
from pathlib import Path
from time import perf_counter
from statistics import median
import numpy as np
from compact_fss import dpf_gen, dcf_gen, gate_gen, tree_dcf_gen, signed, polynomial, MASK

rng=np.random.default_rng(9132026)
start=perf_counter()
counts={'dpf_queries':0,'dcf_queries':0,'tree_dcf_queries':0,'fused_gate_cases':0}
for n in range(7):
    for alpha in range(1<<n):
        beta=tuple(int(x) for x in rng.integers(0,1<<32,size=3,dtype=np.uint64))
        keys=dpf_gen(n,alpha,beta)
        for x in range(1<<n):
            got=tuple((a+b)&MASK for a,b in zip(keys[0].eval(0,x),keys[1].eval(1,x),strict=True))
            assert got == (beta if x==alpha else (0,0,0))
            counts['dpf_queries']+=1
for n in range(1,6):
    for alpha in range(1<<n):
        beta=tuple(int(x) for x in rng.integers(0,1<<32,size=3,dtype=np.uint64))
        keys=dcf_gen(n,alpha,beta)
        for x in range(1<<n):
            got=tuple((a+b)&MASK for a,b in zip(keys[0].eval(0,x),keys[1].eval(1,x),strict=True))
            assert got == (beta if x<alpha else (0,0,0)),(n,alpha,x,got,beta)
            counts['dcf_queries']+=1
for n in range(1,7):
    for alpha in range(1<<n):
        beta=tuple(int(x) for x in rng.integers(0,1<<32,size=3,dtype=np.uint64))
        keys=tree_dcf_gen(n,alpha,beta)
        for x in range(1<<n):
            got=tuple((a+b)&MASK for a,b in zip(keys[0].eval(0,x),keys[1].eval(1,x),strict=True))
            assert got==(beta if x<alpha else (0,0,0)),(n,alpha,x,got,beta)
            counts['tree_dcf_queries']+=1
polys=[[1,2,3,1],[-4,1,-2,3],[5,-2,1,-1],[0,3,-1,2]]
profiles=[]
for n, batches, cases in [(8,4,256),(16,12,12),(24,4,12),(32,4,12)]:
    q=1<<n
    breaks=[-q//2,-q//4,0,q//4,q//2]
    payloads=[]; generates=[]; evaluates=[]
    for _ in range(batches):
        t=perf_counter();keys=gate_gen(n,breaks,polys);generates.append(perf_counter()-t)
        sizes=[len(k.to_bytes()) for k in keys];payloads.append(sum(sizes))
        # Fresh key for each independent activation in deployment. Deliberate
        # multi-input reuse here tests mathematical function correctness only;
        # it must NOT be copied into online protocol use.
        inputs=list(range(q)) if n==8 else [int(x) for x in rng.integers(0,q,size=cases,dtype=np.uint64)]
        for x in inputs:
            u=int(rng.integers(0,1<<32,dtype=np.uint64))
            r=(keys[0].x_mask_share+keys[1].x_mask_share)%q
            s=(keys[0].u_mask_share+keys[1].u_mask_share)&MASK
            # Additive-share opening (2 directions) reconstructed by test driver.
            xa=int(rng.integers(0,q,dtype=np.uint64)); xb=(x-xa)%q
            ua=int(rng.integers(0,1<<32,dtype=np.uint64));ub=(u-ua)&MASK
            d=((xa-keys[0].x_mask_share)+(xb-keys[1].x_mask_share))%q
            e=((ua-keys[0].u_mask_share)+(ub-keys[1].u_mask_share))&MASK
            t=perf_counter();y=(keys[0].eval(0,d,e)+keys[1].eval(1,d,e))&MASK;evaluates.append(perf_counter()-t)
            sx=signed(x,n);i=next(i for i in range(4) if breaks[i]<=sx<breaks[i+1])
            assert y==(u*polynomial(polys[i],sx))&MASK,(n,x,u,y)
            counts['fused_gate_cases']+=1
    assert len(set(payloads))==1,'key length must be independent of mask'
    profiles.append({'input_bits':n,'output_bits':32,'intervals':4,'degree':3,
      'cases':batches*cases,'fresh_preprocessing_instances':batches,
      'actual_key_bytes_both_parties':payloads[0],
      'dense_table_bytes_both_parties':(1<<n)*8*4*2,
      'independent_prefix_key_bytes_both_parties':sum(len(k.to_bytes()) for k in gate_gen(n,breaks,polys,backend='prefix')),
      'online_packed_masked_input_bytes_both_directions':2*((n+7)//8+4),
      'online_opening_rounds':1,
      'median_keygen_ms_python':1000*median(generates),
      'median_two_party_eval_ms_python':1000*median(evaluates)})
result={'scope':'Actual SHAKE-based tree DPF + linear-size prefix-corrected DCF + piecewise shifted-coefficient fused gate. Single-process, no sockets, no cryptographic audit or GPU inference. Uses fresh OS secret seed material; synthetic inputs seeded.',
 'counts':counts,'profiles':profiles,'wall_seconds':perf_counter()-start,
 'critical_limits':['Tree DCF has O(n) key/evaluation complexity; Python SHAKE implementation has no SIMD/AES/GPU optimization.',
 'Each mask pair is one-activation-only. Exhaustive key reuse above is an offline functional test, NOT private inference.',
 'One-round result covers integer polynomial gate only; fixed-point truncation and verified approximation of SiLU are excluded.',
 'Secret key bytes are NOT saved in the artifact; only aggregate counts/timings are saved.',
 'Serialization totals include two key headers, mask shares, coefficient shares, DPF keys and DCF headers, but not transport or integrity.',
 'DPF key security relies on standard construction assumptions plus correct implementation; correctness tests are not a proof.']}
path=Path(__file__).with_name('fss_results.json');path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
