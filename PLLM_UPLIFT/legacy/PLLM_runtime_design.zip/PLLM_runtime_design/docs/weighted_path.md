# Weighted garbled paths

**Method:** `garbled.weighted_path.experimental.v1`  
**Status:** adapted/novel research composition; synthetic region experiments reported; not integrated full-model inference; not security-reviewed.

## What it does

A discrete nonlinear function is often represented as a table containing one answer for every permitted input. A weighted decision graph shares subfunctions that differ by a constant. The private evaluator follows a fixed number of encrypted decisions and accumulates protected edge contributions. The result remains an arithmetic label that the next public matrix multiplication can consume.

This is useful when a flat encrypted table is too large and a Boolean circuit is expensive to evaluate. It is not automatically useful for simple clipped functions, whose Boolean circuits can be much smaller.

## Where the idea comes from

Public edge-valued decision diagrams and private branching-program evaluation are established techniques. Arithmetic labels and mixed-protocol helpers are established too. Consult source IDs **S01, S03, S36 and S37** in `research_registry.json` for canonical links. PLLM's proposed secret-potential composition is not assigned those papers' security guarantees automatically.

## What the supplied PLLM experiment actually demonstrated

The previous report, captured as source **I04**, implemented a 16-level discrete-function experiment and small protected matrix-to-activation blocks. It did not execute Qwen, a complete transformer, private sampling or sustained preparation.

For its SiLU table, preparation used 302,468 bytes, including conversion. The Boolean comparator used 210,616 bytes; flat lookup used 4,113,408 bytes. Python scalar timings favored the weighted path over that Boolean implementation, while flat lookup remained much faster. The three implementations occupy different trade-offs.

These values are **source-reported earlier experiments**, not rerun measurements from this design task. Do not turn them into a claimed speedup over optimized Rust/CUDA garbling or full-model TPS.

## Parameters and compatibility

Parameters include the exact frozen integer table, decision-bit order, output representation, public input range and conversion implementation. The arithmetic-to-bit bridge must be implemented and included in measured costs. The input range and numeric table hash are part of the graph identity.

The topology is one offline Preparation party plus one online evaluator. It requires fresh garbling for distinct semantic executions. It cannot consume arbitrary publicly editable masked scalars as though they were valid cryptographic labels.

## Known unsafe alternatives

Unpadded early exit revealed input-dependent path information in the prior tests. Deriving secret arithmetic node masks from evaluator-visible keys exposed edge weights and outputs. These variants are negative controls, not performance options.

## Reproduction recipe

1. Pin the original `PLLM_tenx_experiments.zip` archive using its hash in `source_inventory.json`.
2. Run its documented Python reference experiment in a recorded environment.
3. Compare integer outputs and full conversion-inclusive bytes with the prior JSON records.
4. Port the same declared function and encodings into the native interface, with differential tests.
5. Compare optimized Boolean, flat and reviewed compact-LUT alternatives on the same inputs and hardware.
6. Obtain a composition/security review before eligibility for a privacy-bearing default.

The proposed `pllm bench search --config configs/operator-search.yaml` will automate the integrated comparison once those backends exist. It is not implemented by this design package.
