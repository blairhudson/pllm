"""Build public design fixtures and schemas. Does not execute inference."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import yaml
from config_contracts import Experiment, MethodCard, RunResult

ROOT = Path(__file__).resolve().parent

def write_json(path: str, obj: object) -> None:
    (ROOT / path).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")

common = {
    "schema_version": "pllm.experiment.v1",
    "name": "qwen-local-baseline",
    "preset": "baseline.masked_linear_cpu",
    "model": {
        "id": "Qwen/Qwen2.5-0.5B-Instruct",
        "revision": "7ae557604adf67be50417f59c2c2f167def9a775",
        "adapter": "qwen2_dense.v1",
        "trust_remote_code": False,
        "fixture_kind": "public_checkpoint",
        "require_resolved_content_hashes": True,
    },
    "numeric": {
        "profile": "archive.277d19f.numeric_manifest",
        "profile_origin": "archive_to_resolve",
        "preserve_declared_graph": True,
        "compare_original_checkpoint": True,
        "permit_new_approximation": False,
        "missing_certificate": "reject",
        "certificate": "archived_numeric_manifest",
    },
    "privacy": {
        "family": "masked_linear", "adversary": "semi_honest",
        "integrity": "not_claimed", "online_inference_workers": 1,
        "preparation_phase": "offline_only", "client_model": "boundary_matrices",
        "client_compute": "local_model_ops", "he": "forbidden",
        "leakage": ["public_model", "shapes", "lengths", "timing", "traffic_volume"],
        "non_collusion": [["preparation", "inference"]],
        "assurance": "reference_experiments", "allow_unreviewed_composition": False,
        "fallback": "reject",
    },
    "execution": {
        "launcher": "local_processes", "transport": "binary_wss",
        "local_tls": "generated_test_ca",
        "parties": [
            {"id": "client", "role": "client", "device": "cpu", "threads": 2, "weights": "boundary_matrices"},
            {"id": "preparation", "role": "preparation", "device": "cpu", "threads": 2, "weights": "full"},
            {"id": "inference", "role": "inference", "device": "cpu", "threads": 2, "weights": "full"},
        ],
        "secret_export": "forbidden", "collect_payloads": False, "unimplemented": "reject",
    },
    "selection": {
        "mode": "fixed", "methods": ["masked.linear.v1"],
        "kernels": ["cpu.exact.scalar.v1", "cpu.exact.simd.v1"],
        "conversions": "explicit_eligible_only", "region_policy": "fixed_partition",
        "public_parameters": {}, "trial_budget": 1,
        "search_data": "public_calibration_only", "test_data_reuse": "forbidden",
    },
    "budgets": {
        "setup_bytes_limit": 2_147_483_648, "peak_memory_bytes_per_party": 4_294_967_296,
        "online_timeout_seconds": 1800, "total_trial_timeout_seconds": 3600,
        "setup_budget_exceeded": "reject_before_allocation",
    },
    "workload": {
        "scope": "full_model", "prompt_tokens": [30], "output_tokens": [16],
        "concurrency": [1], "warmups": 1, "repetitions": 3,
        "stop_policy": "fixed_work_ignore_eos", "dataset": "pllm.public.smoke.v1",
        "dataset_classification": "public", "crypto_seed_export": False, "public_fixture_seed": 42,
    },
    "benchmark": {
        "phases": ["compile", "prepare", "online", "supply_capacity"],
        "prep_online_policy": "terminate_before_online",
        "metrics": ["ttft", "inter_token_latency", "decode_tps", "payload_bytes_by_edge", "cpu_seconds_by_party", "peak_rss", "prepared_units_per_second", "unused_material", "integer_parity"],
        "baselines": ["plaintext_same_graph", "unmasked_same_partition", "native_source_model"],
        "raw_samples": True, "evidence_origin": "design_only", "claim": "smoke",
    },
}

def clone(x):
    return json.loads(json.dumps(x))

configs = {"qwen-local-baseline.yaml": common}
target = clone(common)
target["name"] = "single-evaluator-target"
target["preset"] = "research.single_evaluator"
target["numeric"].update(profile="qwen2.numeric.v1.to_calibrate", profile_origin="new_profile_to_calibrate", certificate="public_bound")
target["privacy"].update(family="single_evaluator_garbling", client_model="none", client_compute="encode_decode", allow_unreviewed_composition=True)
target["execution"]["parties"][0]["weights"] = "none"
target["selection"].update(mode="pareto_beam", methods=["garbled.public_linear.v1", "garbled.boolean_half_gates.v1", "garbled.full_lut.v1", "garbled.weighted_path.experimental.v1"], region_policy="conversion_aware", trial_budget=24, public_parameters={"decision_bit_order": ["msb", "lsb"], "worker_threads": [1, 2]})
configs["single-evaluator-target.yaml"] = target
op = clone(target)
op["name"] = "operator-search"
op["model"].update(id="pllm.fixtures.silu16", revision="fixture-definition-v1", adapter="public_operator.v1", fixture_kind="synthetic_operator")
op["numeric"].update(profile="silu16.rint.scale4096to256.crt251x241", profile_origin="declared_fixture", compare_original_checkpoint=False)
op["workload"].update(scope="operator", prompt_tokens=[1], output_tokens=[1], warmups=2, repetitions=30, dataset="pllm.fixtures.silu16.public.v1")
op["selection"].update(mode="enumerate", methods=["garbled.boolean_half_gates.v1", "garbled.full_lut.v1", "garbled.weighted_path.experimental.v1"], kernels=["python.reference.v1", "rust.reference.v1"], public_parameters={"decision_bit_order": ["msb", "lsb", "alternating"], "batch_size": [1, 32]}, trial_budget=36)
op["benchmark"].update(claim="operator_study", baselines=["plaintext_same_graph", "full_lut_same_encoding", "boolean_same_encoding"])
configs["operator-search.yaml"] = op

for filename, data in configs.items():
    Experiment.model_validate(data)
    (ROOT / "configs" / filename).write_text("# Proposed runtime contract; this bundle is not an inference implementation.\n" + yaml.safe_dump(data, sort_keys=False))

for name, model in [("experiment", Experiment), ("method", MethodCard), ("result", RunResult)]:
    write_json(f"schemas/{name}.schema.json", model.model_json_schema())

sources = [
("S01", "Dash: Accelerating Distributed Private Convolutional Neural Network Inference with Arithmetic Garbled Circuits", "https://arxiv.org/html/2302.06361v2", "primary_full_text_accessed", "Arithmetic labels, public-weight operations, LabelTensors; CNN scope. Security depends on additional mechanisms, not merely garbling kernels."),
("S02", "ReDASH: Fast and efficient Scaling in Arithmetic Garbled Circuits for Secure Outsourced Inference", "https://arxiv.org/html/2506.14489v1", "primary_full_text_accessed", "RNS scaling and conversion. No claim of a PLLM reproduction."),
("S03", "Two Halves Make a Whole: Reducing Data Transfer in Garbled Circuits using Half Gates", "https://eprint.iacr.org/2014/756", "primary_link_in_supplied_report", "Published Boolean foundation; research hash instantiations are adaptations."),
("S04", "Garbled Circuit Lookup Tables with Logarithmic Number of Ciphertexts", "https://eprint.iacr.org/2024/369", "primary_abstract", "logrow: logarithmic ciphertext count does not mean logarithmic total communication; conversions remain."),
("S05", "Duty-Free Bits: Projectivizing Garbling Schemes", "https://eprint.iacr.org/2026/476", "primary_abstract", "Specific bit-to-arithmetic conversion, not arbitrary bidirectional casting."),
("S06", "Slalom: Fast, Verifiable and Private Execution of Neural Networks in Trusted Hardware", "https://arxiv.org/abs/1806.03287", "primary_abstract", "Linear blinding and local verification precedent; trust/deployment differs from PLLM."),
("S07", "Slalom at the Carnival", "https://cic.iacr.org/p/1/3/40", "primary_full_text_accessed", "Outsourced preprocessing; variants require current cryptanalytic review."),
("S08", "SIGMA: Secure GPT Inference with Function Secret Sharing", "https://petsymposium.org/popets/2024/popets-2024-0107.php", "primary_abstract", "Secure transformer baseline in another online topology."),
("S09", "FuseFSS: Efficient Secure LLM Inference with Function Secret Sharing", "https://arxiv.org/abs/2606.09551", "primary_abstract", "FSS helpers and nonlinear compilation; not default single-evaluator topology."),
("S10", "CryptoGen: Secure Transformer Generation with Encrypted KV-Cache Reuse", "https://arxiv.org/abs/2602.08798", "primary_abstract", "Encrypted-cache reuse precedent; HE/MPC comparison track."),
("S11", "An Efficient Private GPT Never Autoregressively Decodes", "https://arxiv.org/abs/2505.15252", "primary_abstract", "POST; speculative private inference, accounting per accepted token required."),
("S12", "Private and Verifiable Outsourcing of Open-Weight LLM Inference", "https://eprint.iacr.org/2026/1849", "primary_abstract", "Two malicious non-colluding servers; only abstract accessed, performance not independently verified."),
("S13", "Maverick", "https://arxiv.org/abs/2609.10264", "primary_abstract", "Private verifiable delegation and cryptanalytic comparison; match workload definitions."),
("S14", "MOSAIC", "https://arxiv.org/abs/2607.29221", "primary_abstract", "Different model-confidentiality and approximation boundary; separate comparison cohort."),
("S15", "Efficient Pseudorandom Correlation Generators over Z/p^k Z", "https://dl.acm.org/doi/abs/10.1007/978-3-032-01884-7_7", "metadata_only", "Ring-PCG lead; no current implementation or reviewed parameter selection in PLLM."),
("S16", "Prime-field PCG using Walsh-Hadamard transforms", "https://eprint.iacr.org/2026/196", "primary_abstract", "Do not transfer odd-prime transform identities into power-of-two rings without proof."),
("S17", "Curl", "https://eprint.iacr.org/2024/1127", "primary_abstract", "Wavelet nonlinear LUT reference, not implemented by the supplied experiments."),
("S18", "Compact: Approximating Complex Activation Functions for Secure Computation", "https://arxiv.org/abs/2309.04664", "primary_link_in_supplied_report", "Model/numeric approximation comparison; distinguish approximate graph from protected exactness."),
("S19", "Practical Secure Delegated Linear Algebra with Trapdoored Matrices", "https://arxiv.org/html/2502.13060v3", "primary_link_in_supplied_report", "LPN-based structured preprocessing lead with a different operand/interaction boundary."),
("S20", "Maturin project layout", "https://www.maturin.rs/project_layout.html", "official_documentation", "Mixed Python/Rust packaging."),
("S21", "PyO3 parallelism", "https://pyo3.rs/main/parallelism", "official_documentation", "Native work outside the Python interpreter attachment."),
("S22", "Transformers custom models", "https://huggingface.co/docs/transformers/en/custom_models", "official_documentation", "Adapter conventions; PLLM semantic/protected IR remains independent."),
("S23", "Transformers models and custom code", "https://huggingface.co/docs/transformers/en/models", "official_documentation", "Explicit trust and pinned source loading."),
("S24", "Safetensors documentation", "https://huggingface.co/docs/safetensors/index", "official_documentation", "Safe tensor container does not certify model identity/semantics."),
("S25", "Qwen2.5-0.5B-Instruct official configuration", "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct/raw/main/config.json", "official_model_metadata", "Current main metadata accessed; archived revision supplied by manuscript must be verified at resolution."),
("S26", "Scikit-learn pipelines and composite estimators", "https://scikit-learn.org/stable/modules/compose.html", "official_documentation", "Named components and nested parameter-search UX."),
("S27", "Optuna multi-objective optimization", "https://optuna.readthedocs.io/en/stable/tutorial/20_recipes/002_multi_objective.html", "official_documentation", "Optional public-parameter search engine, not the type/security checker."),
("S28", "DeepEval metrics introduction", "https://deepeval.com/docs/metrics-introduction", "official_documentation", "Explicit metrics and test cases; remote evaluator is not enabled by default."),
("S29", "OpenTelemetry metrics data model", "https://opentelemetry.io/docs/specs/otel/metrics/data-model/", "official_documentation", "Metric export format; private payloads excluded."),
("S30", "OpenAI Responses API reference", "https://developers.openai.com/api/reference/resources/responses/methods/create", "official_documentation", "Client-gateway compatibility target, not a claim that every API feature is implemented."),
("S31", "MP-SPDZ", "https://mp-spdz.readthedocs.io/en/latest/", "official_documentation", "Multi-protocol systems and benchmarking prior art."),
("S32", "HyCC: Compilation of Hybrid Protocols for Practical Secure Computation", "https://dl.acm.org/doi/10.1145/3243734.3243786", "primary_metadata_and_author_abstract", "Hybrid protocol compilation/selection prior art."),
("S33", "CrypTFlow: Secure TensorFlow Inference", "https://www.microsoft.com/en-us/research/publication/cryptflow-secure-tensorflow-inference/", "primary_abstract", "Secure ML compiler prior art."),
("S34", "EzPC: Easy Secure Multi-Party Computation", "https://www.microsoft.com/en-us/research/project/ezpc-easy-secure-multi-party-computation/", "official_project", "Compiler/framework prior art."),
("S35", "Practical attacks on quasi-abelian syndrome decoding and PCGs", "https://eprint.iacr.org/2025/892", "primary_abstract", "Parameter review required; faster broken parameters are never search candidates."),
("S36", "Factored Edge-Valued Binary Decision Diagrams", "https://link.springer.com/article/10.1023/A:1008691605584", "primary_link_in_supplied_report", "Established function compression; not a security construction."),
("S37", "Oblivious decision program evaluation", "https://ietresearch.onlinelibrary.wiley.com/doi/10.1049/iet-ifs.2012.0032", "primary_link_in_supplied_report", "Garbled decision-program precedent; custom potentials need independent composition analysis."),
("S38", "FlashAttention-2", "https://arxiv.org/abs/2307.08691", "primary_link_in_supplied_report", "Delayed-normalization scheduling precedent; fixed-point placement may change semantics."),
("S39", "Root Mean Square Layer Normalization", "https://arxiv.org/abs/1910.07467", "primary_link_in_supplied_report", "Normalization geometry basis for public range proofs."),
("S40", "Piranha: A GPU Platform for Secure Computation", "https://www.usenix.org/conference/usenixsecurity22/presentation/watson", "primary_link_in_supplied_report", "GPU secure-kernel precedent."),
("S41", "Oblivious Ciphertext Compression via Linear Codes", "https://eprint.iacr.org/2026/329", "primary_link_in_supplied_report", "Syndrome-compression overlap must be checked; cannot assert novel general compression."),
("S42", "Distributed Point Functions and Function Secret Sharing", "https://arxiv.org/abs/2607.27696", "primary_link_in_supplied_report", "Foundation/review for FSS offset-function and public-basis sharing."),
("S43", "MPCFormer", "https://arxiv.org/abs/2211.01452", "primary_link_in_supplied_report", "Distillation/model-changing MPC-friendly track, never an exact compiler rewrite."),
("S44", "One-Time Programs", "https://www.microsoft.com/en-us/research/publication/one-time-programs-2/", "primary_link_in_supplied_report", "Software erasure promises do not enforce one-use on copied evaluator state."),
]
methods = [
("masked.linear.v1", ["S06","S07"], "masked_linear", "full_model_reported", "adapted_method", "reported nine-run baseline; not rerun in this design task"),
("masked.verification.mixed_field.experimental.v1", ["S06"], "masked_linear", "algebra_reported", "adapted_method", "client model-dependent check setup and signed-bound assumptions; not full malicious protocol"),
("masked.public_bound_codec.v1", [], "masked_linear", "operator_reported", "adapted_method", "exact only with declared public bounds; prototype integration pending"),
("masked.syndrome_codec.experimental.v1", ["S41"], "masked_linear", "operator_reported", "novel_composition", "sparse overflow envelope, undetected out-of-domain collision; no automatic fallback"),
("masked.coded_corrections.experimental.v1", ["S41"], "masked_linear", "operator_reported", "novel_composition", "includes stored encoded corrections; online savings exclude HE preparation"),
("masked.prediction.experimental.v1", [], "masked_linear", "operator_reported", "novel_composition", "deliberately correlated synthetic data, not demonstrated real-model correlation"),
("prep.paillier.reference.v1", [], "he_hybrid", "operator_reported", "adapted_method", "actual small Paillier experiment; model-free variant obsolete in preferred model-aware setup"),
("shared.public_linear.v1", ["S08"], "two_worker_sharing", "region_reported", "adapted_method", "two online model replicas; comparison track only"),
("shared.immutable_kv.experimental.v1", ["S10"], "two_worker_sharing", "operator_reported", "novel_composition", "same immutable operand only; new left correlations still consumed"),
("shared.late_normalization.v1", ["S38"], "two_worker_sharing", "operator_reported", "adapted_method", "float identity; fixed-point graph must record moved rounding"),
("shared.spectral.experimental.v1", ["S18","S42"], "two_worker_sharing", "operator_reported", "novel_composition", "private coefficients cannot be exposed to one evaluator; range/rescaling/approximation limits"),
("shared.piecewise_fss.experimental.v1", ["S09","S42"], "two_worker_sharing", "operator_reported", "adapted_method", "custom shifted-polynomial fusion; not full FuseFSS reproduction"),
("shared.private_sampling.reference.v1", ["S08"], "two_worker_sharing", "operator_reported", "adapted_method", "finite random grid, secure comparisons and embedding scan; not complete model sampling"),
("garbled.public_linear.v1", ["S01"], "single_evaluator_garbling", "region_reported", "adapted_method", "arithmetic labels/CRT; no full transformer"),
("garbled.boolean_half_gates.v1", ["S03"], "single_evaluator_garbling", "operator_reported", "adapted_method", "Python research hashes are not automatically optimized/audited original artifact"),
("garbled.full_lut.v1", ["S01"], "single_evaluator_garbling", "region_reported", "adapted_method", "large disposable material; bounded hash format not formally reviewed"),
("garbled.weighted_path.experimental.v1", ["S01","S03","S36","S37"], "single_evaluator_garbling", "region_reported", "novel_composition", "source trade-off only; one-party security/composition unaudited"),
("garbled.redash_scaling.planned.v1", ["S02"], "single_evaluator_garbling", "not_implemented", "not_implemented", "implement source conversion/scaling before claiming reproduction"),
("garbled.logrow.planned.v1", ["S04"], "single_evaluator_garbling", "not_implemented", "not_implemented", "abstract/formula comparison only"),
("garbled.duty_free_bits.planned.v1", ["S05"], "single_evaluator_garbling", "not_implemented", "not_implemented", "respect direction and parameter assumptions"),
("compiler.geometric_bounds.experimental.v1", ["S39"], "protocol_independent_analysis", "operator_reported", "adapted_method", "unit-scale synthetic checks; real learned scales/approximation errors need sound inclusion"),
("compiler.weighted_functions.experimental.v1", ["S36"], "protocol_independent_analysis", "operator_reported", "adapted_method", "public graph compression reused; secret garbling instances not reused"),
("kernel.packed_weights.experimental.v1", ["S01","S40"], "native_kernel", "operator_reported", "adapted_method", "reference CPU layout only; no CUDA throughput claim"),
("kernel.kronecker.experimental.v1", [], "native_kernel", "operator_reported", "adapted_method", "exact but slower on tested CPU"),
("kernel.four_russians.experimental.v1", [], "native_kernel", "operator_reported", "adapted_method", "7–28x slower than tested VNNI implementation; preserve negative evidence"),
("prep.ring_pcg.planned.v1", ["S15","S35"], "preparation", "not_implemented", "not_implemented", "review exact correlation and current secure parameters; no performance claim"),
("prep.field_pcg.planned.v1", ["S16","S35"], "preparation", "not_implemented", "not_implemented", "odd-prime domain not power-of-two-ring domain"),
("nonlinear.curl.planned.v1", ["S17"], "research_comparison", "not_implemented", "not_implemented", "wavelet LUT with original privacy/numeric contract"),
("external.sigma.v1", ["S08"], "research_comparison", "not_implemented", "not_implemented", "pinned external artifact recipe to be added"),
("external.fusefss.v1", ["S09"], "research_comparison", "not_implemented", "not_implemented", "do not relabel a helper experiment as whole-system reproduction"),
("external.cryptogen.v1", ["S10"], "research_comparison", "not_implemented", "not_implemented", "HE/cache-aware external baseline, outside preferred profile"),
("external.post.v1", ["S11"], "research_comparison", "not_implemented", "not_implemented", "speculative baseline reports cost per accepted token"),
("external.gkm.v1", ["S12"], "research_comparison", "not_implemented", "not_implemented", "abstract-only source; obtain full paper/artifact before faithful implementation"),
("external.maverick.v1", ["S13"], "research_comparison", "not_implemented", "not_implemented", "next-token/logit throughput not assumed decode TPS"),
("external.mosaic.v1", ["S14"], "research_comparison", "not_implemented", "not_implemented", "different model-privacy and approximation objectives"),
("external.hycc.v1", ["S32"], "compiler_comparison", "not_implemented", "not_implemented", "mixed-protocol compiler prior art"),
("external.mp_spdz.v1", ["S31"], "compiler_comparison", "not_implemented", "not_implemented", "security/topology-matched comparison required"),
("external.cryptflow_ezpc.v1", ["S33","S34"], "compiler_comparison", "not_implemented", "not_implemented", "compiler/model semantic coverage differs"),
]
write_json("research_registry.json", {
    "schema_version": "pllm.research.registry.v1", "as_of": "2026-09-14",
    "scope": "Design inventory; source access is not evidence of a reproduced result. Prior experiments are source-reported and were not rerun in this task.",
    "sources": [{"id":i,"title":t,"url":u,"access":a,"caveat":c} for i,t,u,a,c in sources],
    "methods": [{"id":i,"source_ids":s,"family":f,"implementation_scope":sc,"fidelity":fi,"validation":"not_run" if sc=="not_implemented" else "source_reported", "integrated_runtime":False,"auto_eligible":False,"notes":n} for i,s,f,sc,fi,n in methods],
    "excluded_from_auto": ["weak_or_small_masks", "shared_exposed_fourier_coefficients", "mask_or_label_reuse_for_changed_input", "sparse_point_and_permute", "data_dependent_visible_fallback", "early_exit_weighted_path", "modular_inverse_as_fixed_point_division", "unreviewed_pcg_parameters"],
})

card = {
    "schema_version":"pllm.method.v1", "id":"garbled.weighted_path.experimental.v1", "version":"1.0-design",
    "summary":"Evaluate an exact discrete function using a fixed-length garbled weighted path and return arithmetic labels.",
    "protocol_families":["single_evaluator_garbling"], "source_ids":["S01","S03","S36","S37"],
    "operators":["frozen_unary_lut"], "accepts":["arithmetic_label.crt251x241"], "produces":["arithmetic_label.crt251x241"],
    "conversions":["arithmetic_to_bits.crt251x241.reference"],
    "party_requirements":["trusted_offline_preparation", "one_online_evaluator", "noncolluding_preparation_and_evaluator"],
    "material_lifetime":"one garbling instance per distinct semantic execution; same-input retries require policy",
    "evidence":{"source_access":"primary_full_text_accessed", "scope":"region", "fidelity":"novel_composition", "validation":"source_reported", "proof_applicability":"not_established", "implementation_audit":"none"},
    "known_limits":["no complete LLM", "Python scalar timings", "large disposable material", "conversion dominates some functions", "fixed-length traversal mandatory", "custom privacy composition unproved"],
    "reproduced_results":["Prior report: SiLU 302468 prepared bytes vs 210616 Boolean and 4113408 flat; different online trade-offs, not a universal winner."],
    "reproduction_recipe":"Import and pin PLLM_tenx_experiments.zip; rerun original script, then establish native operator parity. This design bundle does not run those experiments.",
    "auto_eligible":False,
}
MethodCard.model_validate(card)
write_json("docs/weighted_path.method.json", card)

paths = [
("I01", "/mnt/data/Pasted text.txt"),
("I02", "/mnt/data/pllm_revision/PLLM_revised.md"),
("I03", "/mnt/data/pllm_model_aware_lab/REPORT.md"),
("I04", "/mnt/data/pllm_tenx_lab/REPORT.md"),
("A01", "/mnt/data/PLLM_network_experiments.zip"),
("A02", "/mnt/data/PLLM_resident_shares_checks.zip"),
("A03", "/mnt/data/PLLM_frontier_experiments.zip"),
("A04", "/mnt/data/PLLM_adjacent_math_experiments.zip"),
("A05", "/mnt/data/PLLM_single_server_experiments.zip"),
("A06", "/mnt/data/PLLM_model_aware_experiments.zip"),
("A07", "/mnt/data/PLLM_tenx_experiments.zip"),
]
items=[]
for ident,path in paths:
    p=Path(path)
    entry={"id":ident,"source_filename":p.name,"availability":"mounted" if p.exists() else "not_mounted"}
    if p.exists():
        entry.update(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    items.append(entry)
items.append({"id":"I05","source_filename":"PLLM-Research-Portfolio-Round14.pdf","availability":"library_excerpts_only","sha256":None,"note":"Retrieved through Files; not materialized or copied into this bundle."})
write_json("source_inventory.json", {"schema_version":"pllm.source.inventory.v1","sources":items,"note":"Hashes identify supplied artifacts, not independent reproduction or code review. Original archives are not duplicated in this design bundle."})
print(f"Built {len(configs)} config examples, 3 schemas, {len(sources)} sources, {len(methods)} method records.")
