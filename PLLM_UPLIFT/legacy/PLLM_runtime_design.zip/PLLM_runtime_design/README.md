# PLLM runtime design package

This is an implementation specification and executable **configuration-contract prototype**. It is not a new PLLM runtime release, a benchmark, or a cryptographic proof. No model or prior cryptographic experiment was executed while producing this package.

## Read first

- `ARCHITECTURE.md`: component contracts, typed IR, defaults, compiler, benchmark and paper plan.
- `INTERFACES.md`: proposed API, CLI, artifacts, plugin lifecycle and state machine.
- `research_registry.json`: 44 source records and 38 method records with source/implementation scope separated.
- `source_inventory.json`: hashes of earlier mounted reports and experiment archives; those archives are not duplicated here.
- `docs/weighted_path.md` and `.method.json`: example user-facing method page and metadata.
- `configs/`: baseline, preferred target, and operator-search design examples.
- `schemas/`: generated JSON Schemas for experiments, method cards and results.

## Run the implemented part

Requires Python 3.11+.

```bash
python -m pip install -r requirements.txt
python validate_examples.py
python -m unittest -v test_contracts.py
```

The validator checks three example schemas and a small set of explicit policy constraints. It does not check operator coverage, generate proof certificates, compile a model, benchmark a kernel, or launch parties. Those are specified runtime components still to implement/integrate.

A valid target config is deliberately allowed to describe an unimplemented experiment. The **runtime preflight** must subsequently reject missing model/numeric artifacts, coverage, reviewed conversions, hardware support or resource budgets. `validation_results.json` lists these unresolved gates, rather than claiming execution readiness.

## Important configuration semantics

`qwen-local-baseline.yaml` identifies the model revision and archived graph from the original manuscript. The archived revision is source-provided, not independently fetched in this task. Its numerical manifest is an unresolved external artifact, not a guessed W8A8 recipe. Model and profile resolution must produce hashes or stop.

`single-evaluator-target.yaml` captures the desired minimal-client topology and enables experimental research components explicitly. There is no integrated full-Qwen benchmark for it in the supplied evidence. It must not fall back to client nonlinearities, HE, a second evaluator or plaintext.

`operator-search.yaml` defines a bounded discrete-function comparison. Even though earlier archives contain relevant Python experiments, this bundle does not include an integrated Rust backend for them. The fixture definition and table hash must be registered before a real runtime executes it.

The smoke workload intentionally uses a fixed output-token budget for throughput comparability. It does not recreate the original paper's natural-EOS timing rows unchanged. Preserve a separate historical reproduction recipe for that claim.

## Packaging intent

Retain distribution `pllm-inference`, import/CLI `pllm`, Python orchestration and a `pllm._native` PyO3 module built with maturin. The proposed API/CLI in `INTERFACES.md` are a target contract, not commands supplied by this package. Keep security-sensitive data out of JSON configuration and benchmark records.
