"""Check design configs, method cards and JSON Schemas; never runs inference."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from jsonschema import Draft202012Validator
from jsonschema.exceptions import ValidationError as SchemaValidationError
from pydantic import ValidationError
import yaml
from config_contracts import Experiment, MethodCard

ROOT = Path(__file__).resolve().parent


def validate(path: Path) -> dict:
    raw = yaml.safe_load(path.read_text())
    schema = json.loads((ROOT / "schemas/experiment.schema.json").read_text())
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(raw)
    config = Experiment.model_validate(raw)
    blockers = ["Runtime implementation is not included in this design bundle.", "Resolve and hash model, numerical manifest, implementation and hardware before execution."]
    if config.numeric.profile_origin == "archive_to_resolve":
        blockers.append("Recover the archived numerical manifest before claiming reproduction of revision 277d19f.")
    if config.privacy.family == "single_evaluator_garbling" and config.workload.scope == "full_model":
        blockers.append("No full-Qwen single-evaluator operator-coverage or sustainable-preparation result is established by the supplied experiments.")
    if config.privacy.allow_unreviewed_composition:
        blockers.append("Explicitly experimental composition; config validity does not establish privacy or production suitability.")
    return {"file": path.name, "schema_valid": True, "example_policy_checks_passed": True, "inference_executed": False, "execution_readiness": "not_established", "blockers": blockers}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="*", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    paths = args.paths or sorted((ROOT / "configs").glob("*.yaml"))
    results=[]
    for path in paths:
        try:
            results.append(validate(path))
        except (ValueError, ValidationError, SchemaValidationError, yaml.YAMLError, OSError) as exc:
            results.append({"file":str(path),"schema_valid":False,"error":str(exc),"inference_executed":False})
    card=json.loads((ROOT / "docs/weighted_path.method.json").read_text())
    MethodCard.model_validate(card)
    report={"kind":"design_contract_validation", "not_a_benchmark":True, "examples":results,"method_card_valid":True}
    text=json.dumps(report,indent=2)+"\n"
    if args.output:
        args.output.write_text(text)
    print(text,end="")
    return 0 if all(r.get("schema_valid") for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
