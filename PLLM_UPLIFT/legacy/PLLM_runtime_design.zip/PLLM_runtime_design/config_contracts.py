"""Executable design-contract validator, not the PLLM runtime or a security proof.

The method allowlists below cover the supplied examples. The intended runtime
loads versioned, independently reviewed capabilities from its plugin registry.
"""
from __future__ import annotations

from typing import Annotated, Literal, Self
from pydantic import BaseModel, ConfigDict, Field, model_validator

Positive = Annotated[int, Field(gt=0)]
Nonnegative = Annotated[int, Field(ge=0)]


class Record(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ModelSource(Record):
    id: str
    revision: str
    adapter: str
    trust_remote_code: Literal[False] = False
    fixture_kind: Literal["public_checkpoint", "synthetic_operator"]
    require_resolved_content_hashes: Literal[True] = True


class NumericPolicy(Record):
    profile: str
    profile_origin: Literal["archive_to_resolve", "declared_fixture", "new_profile_to_calibrate"]
    preserve_declared_graph: bool = True
    compare_original_checkpoint: bool = True
    permit_new_approximation: bool = False
    missing_certificate: Literal["reject"] = "reject"
    certificate: Literal["public_bound", "archived_numeric_manifest"]


class PrivacyPolicy(Record):
    family: Literal["masked_linear", "single_evaluator_garbling", "two_worker_sharing", "he_hybrid", "plaintext_reference"]
    adversary: Literal["semi_honest", "malicious", "none"]
    integrity: Literal["not_claimed", "local_linear_verification", "composed_active_security"]
    online_inference_workers: Positive
    preparation_phase: Literal["offline_only", "online_allowed", "absent"]
    client_model: Literal["none", "boundary_matrices", "full"]
    client_compute: Literal["encode_decode", "local_model_ops", "full_inference"]
    he: Literal["forbidden", "permitted"]
    leakage: list[str]
    non_collusion: list[list[str]]
    assurance: Literal["reference_experiments", "composition_reviewed", "audited"]
    allow_unreviewed_composition: bool = False
    fallback: Literal["reject"] = "reject"

    @model_validator(mode="after")
    def validate_topology(self) -> Self:
        if self.family == "single_evaluator_garbling":
            expected = (self.online_inference_workers == 1
                        and self.preparation_phase == "offline_only"
                        and self.client_model == "none"
                        and self.client_compute == "encode_decode"
                        and self.he == "forbidden")
            if not expected:
                raise ValueError("single_evaluator_garbling requires one online worker, offline Preparation, a model-free encode/decode client, and no HE")
        if self.family == "masked_linear":
            if self.client_model not in ("boundary_matrices", "full") or self.client_compute != "local_model_ops":
                raise ValueError("masked_linear.v1 requires explicit local client model operations and boundary matrices")
        if self.family == "two_worker_sharing" and self.online_inference_workers != 2:
            raise ValueError("two_worker_sharing requires two online workers")
        if self.family == "he_hybrid" and self.he != "permitted":
            raise ValueError("he_hybrid requires an explicit HE permission")
        if self.adversary == "malicious" and self.integrity != "composed_active_security":
            raise ValueError("malicious security cannot be selected without an actively secure composition contract")
        return self


class Party(Record):
    id: str
    role: Literal["client", "preparation", "inference"]
    device: str
    threads: Positive
    weights: Literal["none", "boundary_matrices", "full"]


class Execution(Record):
    launcher: Literal["local_processes", "ssh_agents", "inprocess_debug"]
    transport: Literal["binary_wss", "memory_debug"]
    local_tls: Literal["generated_test_ca", "external_credentials", "none_debug"]
    parties: list[Party]
    secret_export: Literal["forbidden"] = "forbidden"
    collect_payloads: Literal[False] = False
    unimplemented: Literal["reject"] = "reject"


class Selection(Record):
    mode: Literal["fixed", "enumerate", "pareto_beam"]
    methods: list[str]
    kernels: list[str]
    conversions: Literal["explicit_eligible_only"] = "explicit_eligible_only"
    region_policy: Literal["fixed_partition", "conversion_aware"]
    public_parameters: dict[str, list[int | float | str | bool]] = Field(default_factory=dict)
    trial_budget: Positive = 1
    search_data: Literal["public_calibration_only"] = "public_calibration_only"
    test_data_reuse: Literal["forbidden"] = "forbidden"


class Budget(Record):
    setup_bytes_limit: Positive
    peak_memory_bytes_per_party: Positive
    online_timeout_seconds: Positive
    total_trial_timeout_seconds: Positive
    setup_budget_exceeded: Literal["reject_before_allocation"] = "reject_before_allocation"


class Workload(Record):
    scope: Literal["operator", "region", "full_model"]
    prompt_tokens: list[Positive]
    output_tokens: list[Positive]
    concurrency: list[Positive]
    warmups: Nonnegative
    repetitions: Positive
    stop_policy: Literal["fixed_work_ignore_eos", "natural_eos"]
    dataset: str
    dataset_classification: Literal["public", "private_local"]
    crypto_seed_export: Literal[False] = False
    public_fixture_seed: int


class BenchmarkPolicy(Record):
    phases: list[Literal["compile", "prepare", "online", "supply_capacity"]]
    prep_online_policy: Literal["terminate_before_online", "no_request_dependency"]
    metrics: list[str]
    baselines: list[str]
    raw_samples: Literal[True] = True
    evidence_origin: Literal["integrated_runtime", "component_reference", "design_only"]
    claim: Literal["smoke", "operator_study", "publication"]


class Experiment(Record):
    schema_version: Literal["pllm.experiment.v1"] = "pllm.experiment.v1"
    name: str
    preset: Literal["baseline.masked_linear_cpu", "research.single_evaluator", "research.alternative"]
    model: ModelSource
    numeric: NumericPolicy
    privacy: PrivacyPolicy
    execution: Execution
    selection: Selection
    budgets: Budget
    workload: Workload
    benchmark: BenchmarkPolicy

    @model_validator(mode="after")
    def validate_composition(self) -> Self:
        parties = self.execution.parties
        ids = [p.id for p in parties]
        if len(ids) != len(set(ids)):
            raise ValueError("party IDs must be unique")
        clients = [p for p in parties if p.role == "client"]
        prep = [p for p in parties if p.role == "preparation"]
        inf = [p for p in parties if p.role == "inference"]
        if len(clients) != 1 or len(inf) != self.privacy.online_inference_workers:
            raise ValueError("party manifest does not match requested client/inference topology")
        if self.privacy.preparation_phase == "offline_only" and len(prep) != 1:
            raise ValueError("offline-only example requires exactly one Preparation party")
        if clients[0].weights != self.privacy.client_model:
            raise ValueError("client weight placement conflicts with privacy policy")
        if self.privacy.family in ("masked_linear", "single_evaluator_garbling"):
            if any(p.weights != "full" for p in prep + inf):
                raise ValueError("these model-aware presets require full weights at Preparation and Inference")
            if not any(set(pair) == {prep[0].id, inf[0].id} for pair in self.privacy.non_collusion):
                raise ValueError("model-aware presets require explicit Preparation/Inference non-collusion")
        if self.privacy.family == "single_evaluator_garbling":
            if self.preset != "research.single_evaluator":
                raise ValueError("garbling example must use the explicit single-evaluator research preset")
        method_families = {
            "masked.linear.v1": {"masked_linear"},
            "masked.public_bound_codec.v1": {"masked_linear"},
            "masked.syndrome_codec.experimental.v1": {"masked_linear"},
            "garbled.public_linear.v1": {"single_evaluator_garbling"},
            "garbled.boolean_half_gates.v1": {"single_evaluator_garbling"},
            "garbled.full_lut.v1": {"single_evaluator_garbling"},
            "garbled.weighted_path.experimental.v1": {"single_evaluator_garbling"},
            "shared.public_linear.v1": {"two_worker_sharing"},
            "shared.spectral.experimental.v1": {"two_worker_sharing"},
            "he.linear.reference.v1": {"he_hybrid"},
        }
        for method in self.selection.methods:
            if method not in method_families:
                raise ValueError(f"unknown method in design validator: {method}; register its capabilities first")
            if self.privacy.family not in method_families[method]:
                raise ValueError(f"method {method} is incompatible with {self.privacy.family}")
            if ".experimental." in method and not self.privacy.allow_unreviewed_composition:
                raise ValueError(f"experimental method {method} requires explicit unreviewed-composition permission")
        if self.execution.launcher != "inprocess_debug":
            if self.execution.transport != "binary_wss" or self.execution.local_tls == "none_debug":
                raise ValueError("separate-party examples require an authenticated transport")
        if self.benchmark.claim == "publication" and self.execution.launcher == "inprocess_debug":
            raise ValueError("in-process debug cannot claim a distributed publication benchmark")
        if self.numeric.preserve_declared_graph and self.numeric.permit_new_approximation:
            raise ValueError("new approximations must create a distinct numerical graph, not claim same-graph parity")
        if self.benchmark.claim == "publication" and self.workload.repetitions < 30:
            raise ValueError("publication preset requires at least 30 requests; tail estimates may need more")
        return self


class MethodEvidence(Record):
    source_access: Literal["primary_full_text_accessed", "primary_abstract", "metadata_only", "unresolved"]
    scope: Literal["not_implemented", "algebra", "operator", "region", "full_model", "multi_process"]
    fidelity: Literal["original_artifact", "faithful_reimplementation", "adapted_method", "novel_composition", "not_implemented"]
    validation: Literal["source_reported", "locally_rerun", "independently_confirmed", "not_run"]
    proof_applicability: Literal["not_established", "review_pending", "reviewed_for_this_composition"]
    implementation_audit: Literal["none", "partial", "independent"]


class MethodCard(Record):
    schema_version: Literal["pllm.method.v1"] = "pllm.method.v1"
    id: str
    version: str
    summary: str
    protocol_families: list[str]
    source_ids: list[str]
    operators: list[str]
    accepts: list[str]
    produces: list[str]
    conversions: list[str]
    party_requirements: list[str]
    material_lifetime: str
    evidence: MethodEvidence
    known_limits: list[str]
    reproduced_results: list[str]
    reproduction_recipe: str
    auto_eligible: bool


class RunIdentity(Record):
    run_id: str
    model_digest: str
    numeric_graph_digest: str
    plan_digest: str
    privacy_contract_digest: str
    workload_digest: str
    environment_digest: str
    implementation_commit: str


class ScalarMetric(Record):
    name: str
    value: float | None
    unit: str
    phase: Literal["compile", "prepare", "online", "supply", "quality", "all"]
    party: str | None = None
    unavailable_reason: str | None = None

    @model_validator(mode="after")
    def validate_missing(self) -> Self:
        if self.value is None and not self.unavailable_reason:
            raise ValueError("unavailable metrics require a reason, not a fabricated zero")
        return self


class TrafficRecord(Record):
    sender: str
    receiver: str
    phase: Literal["compile", "prepare", "online", "supply"]
    payload_bytes: Nonnegative
    transport_bytes: Nonnegative | None
    counted_at: Literal["sender"] = "sender"


class RunResult(Record):
    schema_version: Literal["pllm.result.v1"] = "pllm.result.v1"
    identity: RunIdentity
    status: Literal["complete", "unsupported", "budget_rejected", "failed", "timed_out"]
    evidence_origin: Literal["integrated_runtime", "component_reference", "external_artifact", "paper_reported", "analytic_estimate"]
    metrics: list[ScalarMetric]
    traffic: list[TrafficRecord]
    requested_tokens: Nonnegative
    completed_tokens: Nonnegative
    run_sample_paths: list[str]
    failures: list[str]
    secret_data_exported: Literal[False] = False
    research_source_ids: list[str]
