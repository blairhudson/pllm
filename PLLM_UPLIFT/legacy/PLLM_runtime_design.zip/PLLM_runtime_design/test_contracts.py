"""Regression tests for example config policies, not cryptographic tests."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import unittest
import yaml
from jsonschema import Draft202012Validator
from pydantic import ValidationError
from config_contracts import Experiment, ScalarMetric

ROOT=Path(__file__).resolve().parent
BASE=yaml.safe_load((ROOT/"configs/qwen-local-baseline.yaml").read_text())
TARGET=yaml.safe_load((ROOT/"configs/single-evaluator-target.yaml").read_text())


class Contracts(unittest.TestCase):
    def reject(self, value):
        with self.assertRaises(ValidationError):
            Experiment.model_validate(value)

    def test_all_examples(self):
        schema=json.loads((ROOT/"schemas/experiment.schema.json").read_text())
        for file in (ROOT/"configs").glob("*.yaml"):
            data=yaml.safe_load(file.read_text())
            Experiment.model_validate(data)
            Draft202012Validator(schema).validate(data)

    def test_schemas_well_formed(self):
        for file in (ROOT/"schemas").glob("*.json"):
            Draft202012Validator.check_schema(json.loads(file.read_text()))

    def test_no_second_worker_in_target(self):
        x=copy.deepcopy(TARGET); x["privacy"]["online_inference_workers"]=2; self.reject(x)

    def test_no_he_in_target(self):
        x=copy.deepcopy(TARGET); x["privacy"]["he"]="permitted"; self.reject(x)

    def test_no_online_preparation_in_target(self):
        x=copy.deepcopy(TARGET); x["privacy"]["preparation_phase"]="online_allowed"; self.reject(x)

    def test_no_hidden_client_model_in_target(self):
        x=copy.deepcopy(TARGET); x["privacy"]["client_model"]="full"; self.reject(x)

    def test_masked_baseline_cannot_claim_thin_client(self):
        x=copy.deepcopy(BASE); x["privacy"]["client_compute"]="encode_decode"; self.reject(x)

    def test_no_shared_spectral_in_single_evaluator(self):
        x=copy.deepcopy(TARGET); x["selection"]["methods"].append("shared.spectral.experimental.v1"); self.reject(x)

    def test_no_syndrome_codec_on_garbled_labels(self):
        x=copy.deepcopy(TARGET); x["selection"]["methods"].append("masked.syndrome_codec.experimental.v1"); self.reject(x)

    def test_experimental_requires_permission(self):
        x=copy.deepcopy(TARGET); x["privacy"]["allow_unreviewed_composition"]=False; self.reject(x)

    def test_no_fake_malicious_security(self):
        x=copy.deepcopy(BASE); x["privacy"]["adversary"]="malicious"; self.reject(x)

    def test_no_unknown_knobs(self):
        x=copy.deepcopy(BASE); x["magic_speedup"]=10; self.reject(x)

    def test_no_plaintext_fallback(self):
        x=copy.deepcopy(BASE); x["privacy"]["fallback"]="plaintext"; self.reject(x)

    def test_no_unregistered_method(self):
        x=copy.deepcopy(BASE); x["selection"]["methods"].append("unknown.fast.v1"); self.reject(x)

    def test_no_duplicate_party_ids(self):
        x=copy.deepcopy(BASE); x["execution"]["parties"][1]["id"]="client"; self.reject(x)

    def test_no_missing_noncollusion(self):
        x=copy.deepcopy(BASE); x["privacy"]["non_collusion"]=[]; self.reject(x)

    def test_no_secret_payload_logging(self):
        x=copy.deepcopy(BASE); x["execution"]["collect_payloads"]=True; self.reject(x)

    def test_no_approximation_as_exact_rewrite(self):
        x=copy.deepcopy(BASE); x["numeric"]["permit_new_approximation"]=True; self.reject(x)

    def test_no_missing_metric_as_zero(self):
        with self.assertRaises(ValidationError):
            ScalarMetric(name="gpu_energy",value=None,unit="J",phase="online")
        m=ScalarMetric(name="gpu_energy",value=None,unit="J",phase="online",unavailable_reason="device has no supported sensor")
        self.assertIsNone(m.value)

    def test_no_tiny_sample_publication(self):
        x=copy.deepcopy(BASE); x["benchmark"]["claim"]="publication"; self.reject(x)

    def test_transport_boundary(self):
        x=copy.deepcopy(BASE); x["execution"]["local_tls"]="none_debug"; self.reject(x)


if __name__=="__main__":
    unittest.main()
