# PLLM revision: decisions, corrections, and implementation priorities

13 September 2026

## Recommended direction

Keep the existing masking identity. Change the claim and strengthen the runtime around it.

The revised manuscript is **PLLM: One-Time Preprocessing and Local Verification for Private LLM Inference**. Its design separates reusable verification setup, expendable privacy preprocessing, and online execution. The two proposed protocol changes are a client-side field check of reconstructed integer products and client-authoritative assignment of privacy records before any transmission.

The revised manuscript is a design paper with a reported baseline experiment, not a claim that these changes have already been integrated into PLLM. The only newly executed work is the included mathematical and abstract-state test program. No production repository, benchmark archive, model execution, or revision 277d19f was independently inspected or reproduced.

## Corrections to the first review

**Add Gupta–Katz–Miers.** Their September 2026 preprint, *Private and Verifiable Outsourcing of Open-Weight LLM Inference*, is a close comparison that the first review missed. Its official abstract describes a client using two malicious, non-colluding servers and model-owner verification information. The full PDF was unavailable during this review; the revision does not infer details about its server availability, preprocessing, or key-generation assumptions from the abstract.

**Do not turn Maverick's throughput into sustained decode speed.** Its evaluated end-to-end workload takes an eight-token prompt to next-token logits. Aggregate prompt-token throughput and separately simulated network effects are not interchangeable with sustained autoregressive decoding. Its verification and delegation contributions remain important comparisons.

**Do not assume 96 stages means 96 sequential round trips.** Stage fusion, parallelism, and scheduling determine the critical path. The original stage manifest was not supplied. The evaluated Qwen configuration has 24 layers, so the count is also compatible with existing grouping; that is not evidence of the actual grouping. Do not sell QKV or gate/up fusion as an unimplemented novelty without inspecting the graph.

**Do not assign all 432.71 MB to online traffic.** The original client I/O aggregate lacks direction and phase breakdowns. A hypothetical transfer-time calculation is not a measured WAN result. The revision retains the values with their original accounting labels.

**Use at-most-one-input assignment, not exactly-once transmission.** An identical retransmission is not mask reuse for a distinct activation. The client must prevent reassignment even when the service claims that the earlier request was never consumed.

**Retained masks are not alone sufficient for disclosure.** The matching online transcript is also needed. Static non-collusion and later-compromise/erasure assumptions should be separate. Retained seeds and snapshots can regenerate masks.

**Processed length may be exact leakage.** Without padding, tensor row counts may disclose exact prompt and execution lengths. “Approximate sequence length” is not a safe universal description.

## Priority 1 — Specify and implement the verifier

Keep masked computation in Z/(2^k) for k = 16, 24, or 32. Verify the canonical reconstructed signed integer product in the prime field p = 2^61 − 1. For each stage, privately precompute b_j = W^T a_j using signed authenticated W. Accept y only when a_j^T y = b_j^T x modulo p for all checks.

The no-wrap bound must be a compiler-checked public invariant, not an empirical observation. The client must apply verification before dequantization, dependent computation, KV-cache updates, or release of results. A wrong ring result must never be accepted merely because a field check was incorrectly evaluated on unsigned representations.

Use three independent full-field challenge vectors as a concrete starting point, with an explicit check budget and verifier epoch. The manuscript derives an ideal false-acceptance bound below 2^-150 over at most 2^32 checks. This is not the complete system's security level. Uniform challenge generation, private state, fail-stop behaviour, generic failures, a correct bound, and no secret-dependent verification leakage are required. Production parameter selection still needs review.

The benefit is no additional wire messages, wider wire coefficients, or server matrix work for verification. The cost is client setup, field operations, memory, and a verification dependency before advancing. Measure those costs. Do not call the verifier free, a novel Freivalds primitive, publicly verifiable, or a substitute for non-collusion.

**Acceptance gates:** bit-exact integer reference agreement at every stage and ring width; explicit overflow rejection; signed/unsigned negative controls; reordered, truncated, stale, and corrupt response rejection; no dependent model-state change on failed verification; measured setup, memory, and per-token overhead.

## Priority 2 — Make the client own freshness

Define a globally scoped identity from protocol version, fresh client session epoch, model/stage digest, and row index. Domain-separate masks and tickets. Keep verifier secrets independent from privacy roots and never give the verifier secrets to Preparation.

Bind a record to a frozen request before network transmission. No response, timeout, reconnect, cancellation, delayed acknowledgement, duplicate preparation delivery, or restored model checkpoint may cause reassignment. Either retry exactly the frozen request or retire the record and use a fresh record for a new activation. Server-side atomics become a second safeguard, not the security authority.

Document the atomicity and durability boundary. Multiple processes need one allocator. Restoring a whole client snapshot is not covered by ordinary crash recovery. Specify an external monotonic state mechanism or exclude arbitrary rollback and clones. Do not claim that a ticket or process restart alone establishes global freshness.

**Acceptance gates:** fault injection immediately before and after assignment, send, acknowledgement, verification, and retirement; concurrent allocations; duplicate response delivery; client and server restart; delayed preparation batches; cancellation during packed prefill; divergent retry after an ambiguous timeout; explicit snapshot/clone threat-model tests.

## Priority 3 — Replace the evaluation, not just its adjectives

Run five paths: an unmasked local integer reference; the same remote partition without masking; the existing masked path; the proposed verified path; and an optimised local model engine. The first four isolate costs. The fifth establishes the user's practical alternative.

Retain Qwen2.5-0.5B for reproducibility, and add a materially larger public model, preferably a roughly 4B model initially. Use matched prompt and generation budgets. Include short and long prompts, at least 128 generated tokens for a sustained decode case, multiple independent prompts, cold setup, ready inventory, and depleted inventory. Choose repetitions and uncertainty reporting from observed variance rather than presenting three runs as a tail-latency study.

Report request-to-first-token, ready-to-first-token, request-to-completion, per-token distributions, client memory/CPU, verifier setup/state, link-direction bytes, critical-path round count, prepared/consumed/retired rows, and steady-state preparation capacity. Match the integer reference exactly before evaluating logits, perplexity, and task quality against quantized and floating-point references.

Use controlled network conditions such as 1/10/25/50/100 ms RTT and 100 Mbit/s, 1 Gbit/s, and a faster local link, then validate a useful point on physically separate hosts. These are proposed test conditions, not claimed results. Measure a performance crossover rather than assuming it exists.

## Priority 4 — Make a narrower, testable novelty claim

| Candidate claim | Position after further research |
|:--|:--|
| A new additive masking identity | Reject; not supported |
| First offline private linear outsourcing | Reject; Slalom and subsequent work |
| First outsourced preprocessing | Reject; Carnival and other preprocessing literature |
| First private, verifiable open-weight inference | Reject; close contemporary work |
| First private speculative decoding | Reject; POST already studies it |
| Compact ring computation checked through a bounded integer lift into a larger field | A specific design choice; not established as a first-ever technique |
| Client-enforced lifetime management across retries, verification, and model-state rollback | A concrete systems contribution candidate; needs implementation evidence |
| Quantified crossover after accounting for verification, client state, bytes, and replenishment | A valuable experimental contribution if the measured result supports it |

The strongest eventual paper combines the last three. A useful negative result is also publishable evidence: for example, demonstrating that a class of remote deployments loses to local inference because of sequential interaction or preprocessing demand. Do not hide that result behind online-only timing.

## Priority 5 — Explore inventory-aware speculation only after the core is measured

A small local drafter could improve work per round trip by batching target evaluation. Standard speculative decoding and POST are the starting point. The possible additional contribution is a scheduler that accounts for remaining one-time material, replenishment rates, bytes, and expected accepted tokens.

Count all target-evaluated speculative rows as spent, including rejected candidates. Optimise measured cost per accepted token, not just drafter agreement. Keep model rollback separate from allocation rollback. Adaptive block sizes and acceptance-dependent traffic need explicit leakage treatment. The revision leaves this as future work because there is no implementation or performance evidence yet.

## Changes deliberately not recommended

Do not switch every wire value to a 61-bit field just to reuse a familiar proof. That sacrifices the compact representation unnecessarily for this bounded-integer setting.

Do not introduce sparse, low-rank, reused, or linearly recombined masks solely to shrink traffic. Their privacy needs a formal assumption and proof. Maverick's reported attack on a vector-space instantiation of Carnival is a reason to analyse a specific construction carefully, not a claim that all Carnival variants are broken.

Do not add multiple preparation services merely to claim novelty. Additive sharing can alter the trust threshold, but also changes preprocessing work, traffic, and operations. It is a different trust option, not a demonstrated performance improvement.

Do not replace the honest-but-curious qualifier with “malicious secure” because matrix checks were added. Correctness checks and an actively secure end-to-end privacy theorem are different claims.

## Wording and framing

The rewrite uses inputs, generated outputs, intermediate activations, matrix multiplications, preprocessing records, configuration digests, and protocol audit counters. It removes customer language, language custody, protected exchange, privacy telemetry, retained current-runtime, and claims of worldwide marketplace practicality.

The substantive opening becomes: a public model, a private input, a client capable of local stateful computation, and a precise decision about outsourcing matrix work. The conclusion is a measured trust-and-cost boundary rather than an inference-market forecast.

## Evidence and source boundary

Original implementation and latency statements come only from the supplied 11 September manuscript. The new reference results come from the accompanying executable program. Literature comparisons use primary papers and official publication pages available on 13 September 2026. The bibliography is included in the manuscript package. The GKM comparison is explicitly abstract-only; novelty is not claimed against an unread full protocol.
