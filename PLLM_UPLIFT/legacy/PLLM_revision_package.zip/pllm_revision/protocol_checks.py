#!/usr/bin/env python3
"""Executable mathematical checks for the PLLM manuscript revision.

Standard-library only. This is a deterministic test harness, NOT a cryptographic
implementation, production runtime, benchmark, or validation of revision 277d19f.
The seeded PRNG makes test cases reproducible; deployments require a CSPRNG/KDF.
Run: python protocol_checks.py --output reference_results.json
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import random
from collections import Counter, deque
from dataclasses import dataclass, replace
from fractions import Fraction
from pathlib import Path

FIELD = (1 << 61) - 1


def matvec(w: list[list[int]], x: list[int]) -> list[int]:
    if not w or not x or any(len(row) != len(x) for row in w):
        raise ValueError("Incompatible or empty matrix/vector")
    return [sum(a * b for a, b in zip(row, x)) for row in w]


def center(value: int, q: int) -> int:
    value %= q
    return value if value < q // 2 else value - q


def masked_product(w: list[list[int]], x: list[int], q: int,
                   rng: random.Random) -> list[int]:
    r = [rng.randrange(q) for _ in x]
    s = [rng.randrange(q) for _ in w]
    c = [(wr - si) % q for wr, si in zip(matvec(w, r), s)]
    u = [(xi - ri) % q for xi, ri in zip(x, r)]
    v = [(wu + ci) % q for wu, ci in zip(matvec(w, u), c)]
    return [center(vi + si, q) for vi, si in zip(v, s)]


def verifier_setup(w: list[list[int]], repetitions: int,
                   rng: random.Random) -> tuple[list[list[int]], list[list[int]]]:
    # W is the SIGNED integer matrix, not its unsigned wire representation.
    challenges = [[rng.randrange(FIELD) for _ in w]
                  for _ in range(repetitions)]
    projections = [[sum(a * row[j] for a, row in zip(t, w)) % FIELD
                    for j in range(len(w[0]))] for t in challenges]
    return challenges, projections


def verify(x: list[int], y: list[int], q: int,
           state: tuple[list[list[int]], list[list[int]]]) -> bool:
    # Check the reconstructed signed y, not the masked modular response.
    if any(not (-q // 2 <= value < q // 2) for value in y):
        return False
    challenges, projections = state
    for t, h in zip(challenges, projections):
        if len(t) != len(y) or len(h) != len(x):
            return False
        lhs = sum(a * b for a, b in zip(t, y)) % FIELD
        rhs = sum(a * b for a, b in zip(h, x)) % FIELD
        if lhs != rhs:
            return False
    return True


def transcript_check() -> dict[str, int]:
    # Enumerate all scalar W,x,r,s over Z_8, including non-invertible W.
    q = 8
    assignments = 0
    for w in range(q):
        expected = None
        for x in range(q):
            observed = Counter()
            for r, s in itertools.product(range(q), repeat=2):
                observed[((x - r) % q, (w * r - s) % q)] += 1
                assignments += 1
            assert len(observed) == q * q
            assert set(observed.values()) == {1}
            if expected is not None:
                assert observed == expected
            expected = observed
    return {"ring": q, "weight_input_cases": q * q,
            "mask_assignments_enumerated": assignments}


def soundness_check() -> dict[str, object]:
    q, p = 16, 17
    error = (8, 0)
    ring_pass = sum(sum(a * b for a, b in zip(t, error)) % q == 0
                    for t in itertools.product(range(q), repeat=2))
    field_pass = sum(sum(a * b for a, b in zip(t, error)) % p == 0
                     for t in itertools.product(range(p), repeat=2))
    assert Fraction(ring_pass, q * q) == Fraction(1, 2)
    assert Fraction(field_pass, p * p) == Fraction(1, p)
    two_pass = 0
    for t in itertools.product(range(p), repeat=4):
        two_pass += ((t[0] * error[0] + t[1] * error[1]) % p == 0
                     and (t[2] * error[0] + t[3] * error[1]) % p == 0)
    assert Fraction(two_pass, p**4) == Fraction(1, p**2)
    # Too small a verification field permits integer-error aliases.
    assert all((a * 7) % 7 == 0 for a in range(7))
    # Lucas-Lehmer test; 61 is prime, and this establishes FIELD is prime.
    residue = 4
    for _ in range(61 - 2):
        residue = (residue * residue - 2) % FIELD
    assert residue == 0
    return {
        "toy_ring": q, "toy_field": p, "error": list(error),
        "ring_one_check": {"accepted": ring_pass, "total": q**2},
        "field_one_check": {"accepted": field_pass, "total": p**2},
        "field_two_checks": {"accepted": two_pass, "total": p**4},
        "small_field_alias_negative_control": "detected: q=16, p=7, error=7",
        "verification_field": FIELD, "lucas_lehmer_residue": residue,
    }


def arithmetic_check() -> dict[str, object]:
    rng = random.Random(20260913)
    valid = corrupted = 0
    per_width = {}
    for bits in (16, 24, 32):
        q = 1 << bits
        for _ in range(500):
            n, m = rng.randint(1, 24), rng.randint(1, 8)
            # This public bound deliberately fits even the smallest wire ring.
            w = [[rng.randint(-15, 15) for _ in range(n)] for _ in range(m)]
            x = [rng.randint(-31, 31) for _ in range(n)]
            bound = 31 * max(sum(abs(a) for a in row) for row in w)
            assert bound < q // 2
            reference = matvec(w, x)
            y = masked_product(w, x, q, rng)
            assert y == reference
            state = verifier_setup(w, 3, rng)
            assert verify(x, y, q, state)
            valid += 1
            # Include the half-modulus error that defeats the field-sized ring bound.
            for delta in (1, q // 2, rng.randrange(1, q)):
                bad = y.copy()
                index = rng.randrange(m)
                bad[index] = center(bad[index] + delta, q)
                assert bad != y
                assert not verify(x, bad, q, state)
                corrupted += 1
            # Canonical signed decoding is part of the accepted relation.
            bad_encoding = y.copy()
            bad_encoding[0] += q
            assert not verify(x, bad_encoding, q, state)
        per_width[str(bits)] = 500
    # No-wrap bound is necessary for integer correctness.
    assert center(8, 16) == -8
    overflow_state = verifier_setup([[8]], 3, rng)
    assert not verify([1], [-8], 16, overflow_state)
    # Explicit illustration of input-mask reuse leaking an activation difference.
    x1, x2, r, q = 5, -3, 11, 16
    u1, u2 = (x1 - r) % q, (x2 - r) % q
    assert (u1 - u2) % q == (x1 - x2) % q
    return {
        "valid_products_checked": valid, "cases_by_wire_bits": per_width,
        "corrupted_products_rejected": corrupted,
        "noncanonical_results_rejected": valid,
        "wraparound_negative_control": "detected: 8 mod 16 decodes to -8",
        "mask_reuse_negative_control": "detected: u1-u2 = x1-x2 mod q",
        "seed": 20260913,
    }


@dataclass(frozen=True)
class State:
    """One-row abstract client allocator. Ledger durability is an assumption."""
    status: str = "ready"
    assigned: int | None = None
    sent: frozenset[int] = frozenset()


def next_states(state: State, safe: bool) -> list[tuple[str, State]]:
    result = []
    if state.status == "ready":
        for value in (0, 1):
            result.append((f"bind({value})", replace(state, status="bound", assigned=value)))
    elif state.status == "bound":
        assert state.assigned is not None
        result.append(("send", replace(state, status="inflight",
                                       sent=state.sent | {state.assigned})))
    elif state.status == "inflight":
        result.append(("retry-identical", state))
        result.append(("accept", replace(state, status="done")))
        result.append(("timeout", replace(state, status="retired" if safe else "ready",
                                            assigned=state.assigned if safe else None)))
    if state.status not in ("retired", "done"):
        result.append(("crash", replace(state, status="retired")))
        result.append(("cancel", replace(state, status="retired")))
    return result


def explore(safe: bool) -> dict[str, object]:
    root = State()
    seen = {root}
    queue = deque([(root, [])])
    edges = 0
    while queue:
        state, path = queue.popleft()
        if len(state.sent) > 1:
            return {"safe": False, "states_visited": len(seen),
                    "transitions_examined": edges, "counterexample": path}
        for action, child in next_states(state, safe):
            edges += 1
            if child not in seen:
                seen.add(child)
                queue.append((child, path + [action]))
    return {"safe": True, "states_visited": len(seen), "transitions_examined": edges}


def lifecycle_check() -> dict[str, object]:
    safe, unsafe = explore(True), explore(False)
    assert safe["safe"] is True
    assert unsafe["safe"] is False
    return {"client_bind_before_send": safe,
            "recycle_after_timeout_negative_control": unsafe,
            "scope": "finite one-row/two-input model; not the production runtime; no rollback/clones"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    results = {
        "artifact": "PLLM revision mathematical and abstract-state checks",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Not production cryptography, LLM benchmarking, or a check of PLLM revision 277d19f",
        "transcript_privacy": transcript_check(),
        "verification_soundness": soundness_check(),
        "integer_arithmetic": arithmetic_check(),
        "lifecycle": lifecycle_check(),
        "all_checks_passed": True,
    }
    text = json.dumps(results, indent=2) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
