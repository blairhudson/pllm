# PLLM revised manuscript package

## Contents

- `PLLM_revised.pdf`: typeset revised design manuscript.
- `PLLM_revised.md`: editable Markdown source, with Pandoc citations.
- `PLLM_revised.tex`: generated, self-contained LaTeX source with rendered references.
- `references.bib`: primary-source bibliography.
- `revision_notes.md`: corrections to the first review and prioritised implementation/evaluation gates.
- `protocol_checks.py`: standard-library mathematical and abstract-state tests.
- `reference_results.json`: the executed reference test results, including a source hash.
- `build.sh`: reruns the tests and regenerates LaTeX and PDF.

The manuscript explicitly separates the earlier author-reported PLLM measurements from proposed verification and lifecycle extensions. The reference test program is not the production PLLM runtime or a cryptographic implementation. It uses a deterministic PRNG for reproducible test cases only.

## Run the reference checks

```sh
python3 protocol_checks.py --output reference_results.json
```

No third-party Python packages are required. Do not run Python with optimisations that disable assertions (`-O`), because these are assertion-based tests.

## Build the manuscript

Install Pandoc and a LaTeX distribution with XeLaTeX, microtype, and fvextra, then run from this directory:

```sh
sh build.sh
```

The generated `.tex` has resolved references and can also be compiled independently with XeLaTeX. The package contains no production-code modifications, new model benchmarks, or claims that the proposed extension is already deployed.
