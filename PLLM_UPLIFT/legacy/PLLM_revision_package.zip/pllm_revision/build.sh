#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 protocol_checks.py --output reference_results.json
pandoc PLLM_revised.md --standalone --citeproc --number-sections \
  --pdf-engine=xelatex -o PLLM_revised.tex
pandoc PLLM_revised.md --standalone --citeproc --number-sections \
  --pdf-engine=xelatex -o PLLM_revised.pdf
