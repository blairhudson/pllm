import numpy as np
from scipy.optimize import linprog
from pathlib import Path
import json
R=8.;x=np.linspace(0,R,4097); y=.5*x*np.tanh(x/2)
v=np.arange(-8192,8192)/1024.; t=.5*v*np.tanh(v/2)
rows=[]
for period in (16.,32.,64.):
 for M in (4,6,8,10,12,16):
  A=np.column_stack([np.ones_like(x),x*x]+[np.cos(2*np.pi*j*x/period) for j in range(1,M+1)])
  V=np.column_stack([np.ones_like(v),v*v]+[np.cos(2*np.pi*j*v/period) for j in range(1,M+1)])
  c=np.linalg.lstsq(A,y,rcond=1e-13)[0]
  row=dict(period=period,modes=M,fit='lstsq',error=float(np.max(abs(V@c-t))),coeff_l1=float(np.sum(abs(c))),max_coeff=float(np.max(abs(c))),condition=float(np.linalg.cond(A)),coeff=c.tolist())
  rows.append(row)
  # Scale residual constraints so small errors are not lost in the solver tolerance.
  E=1e5
  obj=np.r_[np.zeros(A.shape[1]),1.]
  cons=np.vstack([np.c_[E*A,-np.ones(len(x))],np.c_[-E*A,-np.ones(len(x))]])
  b=np.r_[E*y,-E*y]
  r=linprog(obj,A_ub=cons,b_ub=b,bounds=[(None,None)]*A.shape[1]+[(0,None)],method='highs',options={'dual_feasibility_tolerance':1e-8,'primal_feasibility_tolerance':1e-8})
  if r.success:
   c=r.x[:-1]
   row=dict(period=period,modes=M,fit='minimax_grid',error=float(np.max(abs(V@c-t))),coeff_l1=float(np.sum(abs(c))),max_coeff=float(np.max(abs(c))),condition=float(np.linalg.cond(A)),coeff=c.tolist())
   rows.append(row)
  print(period,M,[(z['fit'],z['error'],z['max_coeff']) for z in rows[-2:]],flush=True)
Path(__file__).with_name('basis_screen.json').write_text(json.dumps(rows,indent=2))
