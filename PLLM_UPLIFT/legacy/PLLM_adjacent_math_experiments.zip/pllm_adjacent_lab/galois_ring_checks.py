"""Exact small Galois-ring checks. This is NOT a correlation generator.

GR(2**k, 2) = Z_(2**k)[w] / (w*w + w + 1).
The polynomial reduces to an irreducible polynomial modulo two.
Each element is the pair (a, b) representing a+b*w.
"""
from __future__ import annotations
import json
import random
from pathlib import Path

Pair = tuple[int, int]

def add(x: Pair, y: Pair, q: int) -> Pair:
    return ((x[0]+y[0]) % q, (x[1]+y[1]) % q)

def mul(x: Pair, y: Pair, q: int) -> Pair:
    a, b = x
    c, d = y
    return ((a*c-b*d) % q, (a*d+b*c-b*d) % q)

def sigma(x: Pair, q: int) -> Pair:
    a, b = x
    return ((a-b) % q, -b % q)

def trace(x: Pair, q: int) -> int:
    y = add(x, sigma(x, q), q)
    assert y[1] == 0
    return y[0]

def check_pair(x: Pair, y: Pair, q: int) -> None:
    assert sigma(sigma(x,q),q) == x
    assert sigma(add(x,y,q),q) == add(sigma(x,q),sigma(y,q),q)
    assert sigma(mul(x,y,q),q) == mul(sigma(x,q),sigma(y,q),q)
    assert mul(x,sigma(x,q),q)[1] == 0
    inv3=pow(3,-1,q)
    beta0=(inv3,-inv3 % q)
    beta1=(-inv3 % q,-2*inv3 % q)
    assert trace(mul(x,beta0,q),q)==x[0]
    assert trace(mul(x,beta1,q),q)==x[1]

def main() -> None:
    rng=random.Random(20260913)
    rows=[]
    q=16
    # Exhaustively check every pair of extension-ring elements.
    pairs=0
    for a in range(q):
        for b in range(q):
            for c in range(q):
                for d in range(q):
                    check_pair((a,b),(c,d),q)
                    pairs+=1
    rows.append({'base_bits':4,'checked_pairs':pairs,'method':'exhaustive'})
    for k in (8,16,32,64):
        q=1<<k
        for _ in range(2000):
            x=(rng.randrange(q),rng.randrange(q))
            y=(rng.randrange(q),rng.randrange(q))
            check_pair(x,y,q)
        rows.append({'base_bits':k,'checked_pairs':2000,'method':'seeded random fixtures'})
    # In characteristic 2**k, Frobenius is not ordinary element squaring.
    x=(1,1);q=256
    assert sigma(x,q) != mul(x,x,q)
    # The Walsh-Hadamard transform is invertible over an odd prime field,
    # but the same length-8 transform has a kernel modulo 2**8.
    h=[[1]]
    for _ in range(3):
        h=[r+r for r in h]+[r+[-v for v in r] for r in h]
    v=[128,128]+[0]*6
    assert all(sum(a*b for a,b in zip(row,v,strict=True)) % 256 == 0 for row in h)
    p=257
    for i in range(8):
        for j in range(8):
            assert sum(h[i][k]*h[k][j] for k in range(8)) % p == (8 if i==j else 0)
    assert pow(8,-1,p)*8 % p == 1
    result={
        'scope':'Galois-ring arithmetic and trace-coordinate extraction only; no PCG, OLE, triples, seed security or timing claim.',
        'ring':'Z_(2**k)[w] / (w**2+w+1)',
        'cases':rows,
        'total_checked_pairs':sum(row['checked_pairs'] for row in rows),
        'frobenius_is_not_naive_square':{'base_modulus':q,'element':x,'automorphism':sigma(x,q),'square':mul(x,x,q)},
        'walsh_domain_check':{'length':8,'prime_field_modulus':257,'inverse_exists_in_field':True,'power_of_two_modulus':256,'nonzero_kernel_vector':v,'warning':'The odd-prime-field WHT-PCG cannot be transplanted directly into Z_(2**k).'},
        'dual_basis':'beta0=(1-w)/3, beta1=(-1-2w)/3; 3 is invertible modulo 2**k',
    }
    output=Path(__file__).with_name('galois_results.json')
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
