"""Research references only: exact algebra/numerical checks, not audited MPC.

Reuses the previous turn's spectral gate with explicitly changed public specs.
Protocol secrets use os.urandom. Test fixtures use reproducible numpy randomness.
"""
from __future__ import annotations
import hashlib
import json
import math
import os
import platform
import struct
from collections import Counter
from pathlib import Path
from time import perf_counter
import numpy as np
import scipy
import baseline_spectral as sg

HERE=Path(__file__).resolve().parent

def improved_specs():
    rows=json.loads((HERE/'basis_screen.json').read_text())
    out=[]
    for modes in (8,10,12):
        row=next(r for r in rows if r['period']==16 and r['modes']==modes and r['fit']=='minimax_grid')
        vals=row['coeff'];c0,a=vals[:2];co=(c0,*vals[2:])
        for fractional in (44,46):
            p=(round(c0*(1<<fractional)),1<<(fractional-sg.F-1),round(a*(1<<(fractional-2*sg.F))))
            out.append((f'minimax_{modes}_out{fractional}',fractional,sg.PublicSpec(modes,a,co,p)))
    return out

def expand(seed:bytes,context:bytes,count:int):
    stream=hashlib.shake_256(b'PLLM-ONE-SIDED-SHARES-v1\0'+struct.pack('<I',len(context))+context+seed).digest(count*8)
    return struct.unpack('<'+'Q'*count,stream)

def compact_keys(spec, record_id:int):
    # Dealer first makes the desired correlated values. Worker A receives one
    # seed for independent pseudorandom additive shares, NOT the mask seed.
    ordinary=sg.gen(spec)
    def flat(k):return (k.rshare,k.sshare)+k.a+k.b
    total=tuple((a+b)&sg.MASK for a,b in zip(flat(ordinary[0]),flat(ordinary[1]),strict=True))
    seed=os.urandom(32);ctx=struct.pack('<QII',record_id,spec.modes,sg.OUT)
    a=expand(seed,ctx,len(total));b=tuple((v-u)&sg.MASK for v,u in zip(total,a,strict=True))
    n=len(ordinary[0].a)
    def key(z):return sg.Key(z[0],z[1],tuple(z[2:2+n]),tuple(z[2+n:]))
    return (key(a),key(b)),len(seed)+8*len(b)

def numerical_experiments():
    rng=np.random.default_rng(60319);profiles=[]
    specs=[('previous_baseline_12_out44',44,sg.make_spec(12))]+improved_specs()
    for label,fractional,spec in specs:
        sg.OUT=fractional;sg.T=fractional//2
        stats=sg.numeric_grid(spec,phases=64)
        correct=0;maxerr=0.;compact_bytes=None
        for case in range(256):
            # Include close-to-boundary and zero fixtures in addition to random.
            if case<4:x,u=[(-8192,-8192),(8191,8191),(0,8191),(8191,-8192)][case]
            else:x,u=map(int,rng.integers(-8192,8192,size=2))
            keys,compact_bytes=compact_keys(spec,case)
            xs,us=sg.split(x),sg.split(u)
            d=sum(xs[i]-keys[i].rshare for i in (0,1))&sg.MASK
            e=sum(us[i]-keys[i].sshare for i in (0,1))&sg.MASK
            got=sg.center(sum(k.eval(spec,d,e) for k in keys))
            r=sum(k.rshare for k in keys)&sg.MASK
            base=spec.p[0]+spec.p[1]*x+spec.p[2]*x*x
            for j,c in enumerate(spec.coefficients[1:],1):
                pr=2*np.pi*j*(r%sg.PERIOD)/sg.PERIOD
                pd=2*np.pi*j*(d%sg.PERIOD)/sg.PERIOD
                ca=round(c*np.cos(pr)*(1<<sg.T));sa=round(-c*np.sin(pr)*(1<<sg.T))
                cb=round(np.cos(pd)*(1<<sg.T));sb=round(np.sin(pd)*(1<<sg.T))
                base+=ca*cb+sa*sb
            assert got==u*base,(label,case,got,u*base)
            assert abs(got)<sg.Q//2
            correct+=1
            expected=(u/(1<<sg.F))*sg.silu(x/(1<<sg.F))
            err=float(abs(got/(1<<(fractional+sg.F))-expected))
            maxerr=max(maxerr,err)
        stats.update(label=label,modes=spec.modes,numerator_fraction_bits=fractional,
            basis_fraction_bits=sg.T,correct_modular_fused_cases=correct,
            observed_fused_max_error=maxerr,
            ordinary_record_bytes=sum(len(k.to_bytes()) for k in keys),
            one_sided_seeded_record_bytes=compact_bytes,
            online_payload_bytes=32,opening_rounds_before_rescaling=1,
            public_spec={'quadratic':spec.quadratic,'coefficients':spec.coefficients,'integer_polynomial':spec.p})
        profiles.append(stats)
        print(label,stats['max_silu_absolute_error'],compact_bytes,flush=True)
    return profiles

def cyclic_ranks():
    # Over F_65537, the 256-point DFT is invertible. Hence nonzero DFT
    # coefficients give the EXACT rank of the cyclic translation matrix.
    n=256;p=65537;root=pow(3,(p-1)//n,p)
    assert pow(root,n,p)==1 and pow(root,n//2,p)!=1
    powers=np.array([pow(root,k,p) for k in range(n)],dtype=np.int64)
    idx=np.arange(n);F=powers[(idx[:,None]*idx[None,:])%n]
    signed=np.where(idx<n//2,idx,idx-n)
    def cosmode(j):return (powers[(j*idx)%n]+powers[(-j*idx)%n])%p
    functions={
        'constant':np.ones(n,dtype=np.int64),
        'one_character_pair':cosmode(3),
        'four_character_pairs_plus_constant':(np.ones(n,dtype=np.int64)+sum(cosmode(j) for j in (1,3,7,11)))%p,
        'integer_relu_table':np.maximum(signed,0)%p,
        'integer_silu_table':np.rint(sg.silu(signed/16.)*128).astype(np.int64)%p,
        'floor_by_16_table':(signed//16)%p,
    }
    rows=[]
    for name,f in functions.items():
        transform=F@f%p;rank=int(np.count_nonzero(transform))
        rows.append({'function':name,'exact_cyclic_translation_rank':rank,'domain_size':n,'output_prime':p})
    # Three-point identity refutes a separated local additive implementation
    # of a square. This is NOT a general communication lower bound for MPC.
    assert (2**2-1**2-1**2+0**2)==2
    return rows

def stochastic_narrowing():
    cases=0;variance_error=0.;checked=0;old_ring_fail=0;old_ring_cases=0
    for k,f in ((6,2),(8,4),(10,3)):
        q=1<<k;s=1<<f;qp=q//s
        for x in range(q):
            counts=Counter()
            for a in range(q):
                b=(x-a)%q
                va=((a+s-1)//s)%qp;vb=(b//s)%qp
                got=(va+vb)%qp
                expected=(x//s+int(0<(a%s)<=(x%s)))%qp
                assert got==expected
                counts[got]+=1;cases+=1
            lo=x//s;rem=x%s
            assert counts[lo]==q*(s-rem)//s
            if rem:assert counts[(lo+1)%qp]==q*rem//s
            checked+=1
            # Exclude output modular boundary when measuring ordinary expectation.
            if lo+1<qp:
                mean=sum(v*c for v,c in counts.items())/q
                assert mean==x/s
                var=sum(c*(v-mean)**2 for v,c in counts.items())/q
                variance_error=max(variance_error,abs(var-(rem/s)*(1-rem/s)))
        # Naively reinterpreting narrowed shares in the old ring is NOT a lift.
        for x in range(q//4):
            for a in range(q):
                b=(x-a)%q;va=((a+s-1)//s)%qp;vb=(b//s)%qp
                target=(va+vb)%qp
                old_ring_fail+=int((va+vb)%q!=target);old_ring_cases+=1
    return dict(exhaustive_share_pairs=cases,exact_distribution_inputs=checked,
        variance_formula_max_error=variance_error,online_bytes=0,online_rounds=0,
        output_ring='2^(k-f), NOT the original 2^k',
        naive_lift_failures=old_ring_fail,naive_lift_cases=old_ring_cases,
        warning='Unbiased marginal rounding under a fresh uniform sharing only. Rounding depends on input-sharing randomness: this is not a proof of standard or composable stochastic-truncation security. Correlated intermediate shares require a conditional distribution argument; output-ring lifting remains extra work.')

def mask_and_arithmetic_counterexamples():
    # Projective inversion returns residues, not rounded real fixed point.
    p=65537;scale=256;den=3*scale
    residue=scale*scale*pow(den,-1,p)%p
    centered=residue-p if residue>p//2 else residue
    assert centered!=round(scale/3)
    # Unit multiplication preserves 2-adic valuation: 2 vs 4 remain disjoint.
    q=256;units=np.arange(1,q,2,dtype=int)
    support2=set(map(int,2*units%q));support4=set(map(int,4*units%q))
    assert support2.isdisjoint(support4)
    # Public low rank masks annihilate to an exactly revealed linear statistic.
    rng=np.random.default_rng(404)
    q=1<<16;n=12;rank=4
    U=np.vstack([np.eye(rank,dtype=np.int64),rng.integers(-5,6,size=(n-rank,rank))])
    a=rng.integers(0,q,size=rank);x=rng.integers(-100,100,size=n)
    pad=U@a%q;opened=(x-pad)%q
    # Lower row minus its known combination of top rows cancels every mask.
    v=np.r_[-U[rank,:],1,np.zeros(n-rank-1,dtype=int)]
    assert np.all(v@U==0)
    assert int(v@opened%q)==int(v@x%q)
    return dict(modular_inverse={'prime':p,'scale':scale,'encoded_denominator':den,'actual_centered_residue':centered,'desired_fixed_point_rounded_value':round(scale/3)},
        multiplicative_unit_masks={'ring':256,'secret_a':2,'secret_b':4,'supports_disjoint':True},
        public_low_rank_mask={'dimension':n,'rank':rank,'revealed_linear_statistic':int(v@x%q)})

def main():
    start=perf_counter()
    result=dict(scope='New scalar-gate/numerical/algebra reference experiments; no GPU/network/LLM inference or PCG implementation.',
        environment={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
        spectral_profiles=numerical_experiments(),cyclic_translation_ranks=cyclic_ranks(),
        local_stochastic_narrowing=stochastic_narrowing(),
        negative_controls=mask_and_arithmetic_counterexamples())
    result['wall_seconds']=perf_counter()-start
    (HERE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='spectral_profiles'},indent=2))
if __name__=='__main__':main()
