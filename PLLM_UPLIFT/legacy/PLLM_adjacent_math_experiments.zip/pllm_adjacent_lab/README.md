# PLLM: adjacent mathematics experiments

Research snapshot: 13 September 2026.

Read **REPORT.md** for the findings, limitations, sources, and protocol proposals.

## Run

Python 3.13 was used. A fresh environment with the captured package versions:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python experiments.py
python galois_ring_checks.py
```

`experiments.py` uses the included `basis_screen.json`. To repeat the approximation search before the experiments:

```sh
python screen_basis.py
python experiments.py
```

No network, GPU, model weights, private user data, or external credentials are needed.
The program validates the arithmetic in one process; it does not isolate protocol roles.
Protocol records use fresh operating-system randomness, so their sampled fused-gate errors vary slightly between executions. Approximation grids and synthetic fixtures are deterministic.

## Contents

- `baseline_spectral.py`: previous experiment's spectral gate, copied unchanged as a comparison/reference.
- `screen_basis.py`, `basis_screen.json`: approximation search and captured public coefficients.
- `experiments.py`, `results.json`, `run_log.txt`: new seeded records, approximation tests, exact cyclic translation-rank diagnostics, stochastic narrowing, and negative controls.
- `galois_ring_checks.py`, `galois_results.json`, `galois_run_log.txt`: extension-ring automorphism/trace checks and a Walsh-transform domain counterexample.
- `SHA256SUMS.json`: hashes of the other delivered files.

The code does **not** implement a cryptographic PCG, secure ring lifting, complete secure truncation, maliciously secure inference, or a whole model. It has no constant-time or cryptographic audit. Timing from these small reference scripts is not an inference-performance result.
