"""Unaudited functional reference: model-aware, single-evaluator arithmetic garbling.
This is a small-field circuit experiment, not a production cryptosystem.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import os
from typing import Callable
import numpy as np

P = 251
LANES = 18

def derive(root: bytes, domain: bytes, shape: tuple[int, ...]) -> np.ndarray:
    """Domain-separated expansion with rejection sampling (no modulo bias)."""
    n = int(np.prod(shape)); size = n * 2 + 64
    while True:
        raw = np.frombuffer(hashlib.shake_256(b'PLLM-model-aware-v1' + root + domain).digest(size), dtype=np.uint8)
        good = raw[raw < P]
        if good.size >= n:
            return good[:n].astype(np.int64).reshape(shape)
        size *= 2

def delta_from(root: bytes) -> np.ndarray:
    d = derive(root, b'delta', (LANES,)); d[-1] = 1
    return d

def encode(base: np.ndarray, x: np.ndarray | int, delta: np.ndarray) -> np.ndarray:
    return (base + np.asarray(x, dtype=np.int64)[..., None] * delta) % P

def packed(x: np.ndarray) -> bytes:
    return np.asarray(x, dtype=np.uint8).tobytes()

def signed(x: int) -> int:
    return x if x <= P // 2 else x - P

def quant_relu(x: int) -> int:
    return min(7, max(0, int(x)) // 4)

def xor(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b, strict=True))

def seal(key: bytes, gate: bytes, out: bytes) -> bytes:
    tag = hashlib.sha256(b'tag-v1' + gate + out).digest()[:16]
    return xor(out + tag, hashlib.shake_256(b'pad-v1' + gate + key).digest(len(out) + 16))

def unseal(key: bytes, gate: bytes, ciphertext: bytes) -> np.ndarray:
    raw = xor(ciphertext, hashlib.shake_256(b'pad-v1' + gate + key).digest(len(ciphertext)))
    out, tag = raw[:-16], raw[-16:]
    if hashlib.sha256(b'tag-v1' + gate + out).digest()[:16] != tag:
        raise ValueError('invalid label or row')
    a = np.frombuffer(out, dtype=np.uint8).astype(np.int64)
    if a.shape != (LANES,) or np.any(a >= P):
        raise ValueError('invalid output representation')
    return a

class Gate:
    def __init__(self, base_in: np.ndarray, base_out: np.ndarray, delta: np.ndarray,
                 func: Callable[[int], int], domain: range, hashed: bool):
        self.identifier = os.urandom(16)
        self.hashed = hashed
        self.rows: dict[bytes | int, bytes] = {}
        if not hashed and len(domain) != P:
            raise ValueError('sparse point-and-permute exposes domain translation')
        for x in domain:
            label = encode(base_in, x, delta)
            key = packed(label)
            address = self.address(key) if hashed else int(label[-1])
            if address in self.rows:
                raise ValueError('duplicate input residue or hash collision')
            self.rows[address] = seal(key, self.identifier, packed(encode(base_out, func(x), delta)))

    def address(self, key: bytes) -> bytes:
        return hashlib.sha256(b'address-v1' + self.identifier + key).digest()[:16]

    def evaluate(self, label: np.ndarray) -> np.ndarray:
        if label.shape != (LANES,) or np.any(label < 0) or np.any(label >= P):
            raise ValueError('bad label')
        key = packed(label)
        address = self.address(key) if self.hashed else int(label[-1])
        try:
            return unseal(key, self.identifier, self.rows[address])
        except KeyError as e:
            raise ValueError('label not in prepared domain') from e

    @property
    def nbytes(self) -> int:
        # Exact length of the reference serialization: 16-byte gate ID +
        # 4-byte row count + 1-byte format + fixed-size records. For hashed
        # format the address is explicit; full format has implicit indices.
        return 21 + len(self.rows) * (LANES + 16 + (16 if self.hashed else 0))

    def serialize(self) -> bytes:
        header = self.identifier + len(self.rows).to_bytes(4, 'little') + bytes([self.hashed])
        if self.hashed:
            return header + b''.join(k + self.rows[k] for k in sorted(self.rows))
        return header + b''.join(self.rows[i] for i in range(P))

@dataclass
class Client:
    root: bytes
    width: int
    depth: int
    lower: int = -4
    upper: int = 4
    used: bool = False

    def encode(self, x: np.ndarray) -> np.ndarray:
        if self.used:
            raise ValueError('one-time circuit already assigned')
        if x.shape != (self.width,) or np.any(x < self.lower) or np.any(x > self.upper):
            raise ValueError('input outside public domain')
        self.used = True
        return encode(derive(self.root, b'input', (self.width, LANES)), x, delta_from(self.root))

    def decode(self, labels: np.ndarray) -> np.ndarray:
        base = derive(self.root, f'layer/{self.depth-1}/out'.encode(), labels.shape)
        value = (labels[:, -1] - base[:, -1]) % P
        if not np.array_equal(labels, encode(base, value, delta_from(self.root))):
            raise ValueError('incorrect output labels')
        return value

@dataclass
class Evaluator:
    weights: list[np.ndarray]
    tables: list[list[list[Gate]]]

    def evaluate(self, labels: np.ndarray) -> np.ndarray:
        for weight, stage in zip(self.weights, self.tables, strict=True):
            labels = weight @ labels % P
            for gates in stage:
                labels = np.stack([gate.evaluate(label) for gate, label in zip(gates, labels, strict=True)])
        return labels

def prepare(weights: list[np.ndarray], variant: str) -> tuple[Client, Evaluator, dict]:
    if variant not in {'full_separate', 'full_fused', 'bounded_hashed'}:
        raise ValueError('unknown variant')
    root = os.urandom(32); delta = delta_from(root)
    width = weights[0].shape[1]
    current = derive(root, b'input', (width, LANES))
    lower = np.full(width, -4); upper = np.full(width, 4)
    tables = []; bytes_total = 0; row_total = 0; manifest = []
    for i, W in enumerate(weights):
        # Both weights and secret bases are local to Preparation. No OT or HE.
        mapped = W @ current % P
        lo = np.maximum(W, 0) @ lower + np.minimum(W, 0) @ upper
        hi = np.maximum(W, 0) @ upper + np.minimum(W, 0) @ lower
        if np.any(lo < -(P // 2)) or np.any(hi > P // 2):
            raise ValueError('public integer bound exceeds small field')
        output = derive(root, f'layer/{i}/out'.encode(), (W.shape[0], LANES))
        if variant == 'full_separate':
            middle = derive(root, f'layer/{i}/middle'.encode(), output.shape)
            stage = [
                [Gate(b, c, delta, lambda x: max(0, signed(x)), range(P), False)
                 for b, c in zip(mapped, middle, strict=True)],
                [Gate(b, c, delta, lambda x: min(7, x // 4), range(P), False)
                 for b, c in zip(middle, output, strict=True)],
            ]
        else:
            stage = [[Gate(b, c, delta,
                           quant_relu if variant == 'bounded_hashed' else lambda x: quant_relu(signed(x)),
                           range(int(l), int(h)+1) if variant == 'bounded_hashed' else range(P),
                           variant == 'bounded_hashed')
                      for b, c, l, h in zip(mapped, output, lo, hi, strict=True)]]
        for gs in stage:
            for g in gs:
                serialized = g.serialize()
                assert len(serialized) == g.nbytes
                bytes_total += len(serialized); row_total += len(g.rows)
        tables.append(stage)
        lower = np.array([quant_relu(v) for v in lo])
        upper = np.array([quant_relu(v) for v in hi])
        manifest.append({'input_lo':lo.tolist(), 'input_hi':hi.tolist(), 'output_lo':lower.tolist(), 'output_hi':upper.tolist()})
        current = output
    c = {'variant': variant, 'depth':len(weights), 'width':width,
         'garbled_bytes': bytes_total, 'garbled_rows':row_total,
         'client_secret_seed_bytes':32, 'all_setup_payload_bytes':bytes_total+32,
         'prep_inference_matrix_protocol_bytes':0, 'offline_ots':0, 'he_calls':0,
         'online_prep_calls':0, 'intermediate_online_messages':0,
         'online_input_bytes':width*LANES, 'online_output_bytes':weights[-1].shape[0]*LANES,
         'public_manifest':manifest}
    return Client(root,width,len(weights)), Evaluator(weights,tables), c

def reference(weights: list[np.ndarray], x: np.ndarray) -> np.ndarray:
    for W in weights:
        x = np.array([quant_relu(t) for t in W @ x], dtype=np.int64)
    return x
