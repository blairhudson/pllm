"""Exact packed-weight reference and negative controls; no GPU performance claim."""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
from model_garbling import prepare, P

def pack_int4(w):
    if w.ndim!=2 or w.shape[1]%2 or np.any(w < -8) or np.any(w > 7):
        raise ValueError('expected even-width signed INT4 matrix')
    v=(w.astype(np.int16)&15).astype(np.uint8)
    return v[:,::2] | (v[:,1::2]<<4)

def unpack_int4(p):
    a=np.empty((p.shape[0],p.shape[1]*2),dtype=np.int8)
    a[:,::2]=(p&15).astype(np.int8)
    a[:,1::2]=(p>>4).astype(np.int8)
    return np.where(a>=8,a-16,a).astype(np.int8)

def matmul_packed(packed, labels, moduli, tile=128):
    # A reference for decoding a weight tile once for all encoded components.
    # NumPy does not provide the proposed fused GPU kernel.
    out=np.zeros((packed.shape[0],labels.shape[1]),dtype=np.int64)
    for start in range(0,labels.shape[0],tile):
        end=min(start+tile,labels.shape[0])
        weight=unpack_int4(packed[:,start//2:end//2]).astype(np.int32)
        centered=np.where(labels[start:end] > moduli[None,:]//2,
                          labels[start:end]-moduli[None,:],labels[start:end]).astype(np.int32)
        assert np.max(np.abs(centered))<=127
        part=weight@centered
        assert (end-start)*8*127<2**31
        out+=part.astype(np.int64)
    return out%moduli[None,:]

def main():
    rng=np.random.default_rng(713151);records=[];coords=0
    for m,n in [(32,128),(64,896),(64,2048),(32,4096)]:
        for residues in [2,3]:
            for trial in range(4):
                primes=np.repeat([251,241,239][:residues],18)
                W=rng.integers(-7,8,(m,n),dtype=np.int64)
                labels=np.column_stack([rng.integers(p,size=n) for p in primes]).astype(np.int64)
                packed=pack_int4(W)
                assert packed.nbytes==m*n//2
                assert np.array_equal(unpack_int4(packed),W)
                got=matmul_packed(packed,labels,primes)
                assert np.array_equal(got,(W@labels)%primes[None,:]);coords+=got.size
                records.append({'m':m,'n':n,'residues':residues,'trial':trial,
                                'stored_weight_bytes':packed.nbytes,'same_as_native_int4_storage':True,
                                'exact_label_coordinates':got.size})
    model_rejections=0
    for trial in range(48):
        weights=[rng.integers(-2,3,(8,8),dtype=np.int64) for _ in range(2)]
        c,e,info=prepare(weights,'bounded_hashed')
        encoded=c.encode(rng.integers(-4,5,8,dtype=np.int64))
        # Inference substitutes a coefficient AFTER Preparation compiled the original.
        e.weights=[w.copy() for w in e.weights]
        e.weights[0][0,0]+=1
        try:
            c.decode(e.evaluate(encoded));raise AssertionError('altered weight unexpectedly accepted')
        except ValueError:model_rejections+=1
    r={'packed_cases':len(records),'exact_coordinates':coords,'records':records,
       'model_substitutions_tested':48,'model_substitutions_rejected':model_rejections,
       'roofline_hypothesis':{'dense_int8_peak_ops_s':1979e12,'memory_peak_bytes_s':3.35e12,
                              'spec_context':'H100 SXM advertised INT8 figure divided by two to remove sparsity multiplier; ideal ceiling only',
                              'ops_per_weight_36_components':72,'weight_storage_bytes_per_weight':0.5,
                              'weight_only_arithmetic_intensity_ops_byte':144,
                              'required_fraction_dense_peak_at_full_bandwidth':144*3.35e12/1979e12,
                              'with_64_padded_components_required_fraction':256*3.35e12/1979e12,
                              'measured_gpu_performance':False},
       'scope':'packed layout and tile arithmetic checked, NOT a fused GPU implementation; corruption rejection is not a malicious-security proof'}
    Path(__file__).with_name('packed_results.json').write_text(json.dumps(r,indent=2))
    print({k:v for k,v in r.items() if k!='records'})
if __name__=='__main__':main()
