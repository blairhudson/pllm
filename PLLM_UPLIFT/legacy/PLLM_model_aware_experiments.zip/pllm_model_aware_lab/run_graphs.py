import json, time, platform
from pathlib import Path
import numpy as np
from model_garbling import *

def main():
    rng = np.random.default_rng(20260914)
    records=[]; exact=0; reuses=0; forged=0
    for depth in [2,4,8]:
        for trial in range(12):
            W=[rng.integers(-2,3,(8,8),dtype=np.int64) for _ in range(depth)]
            x=rng.integers(-4,5,8,dtype=np.int64)
            expect=reference(W,x)
            for variant in ['full_separate','full_fused','bounded_hashed']:
                start=time.perf_counter();client,evaluator,c=prepare(W,variant);prep=time.perf_counter()-start
                labels=client.encode(x)
                start=time.perf_counter();actual=client.decode(evaluator.evaluate(labels));online=time.perf_counter()-start
                assert np.array_equal(actual,expect);exact+=1
                try:client.encode(x);raise AssertionError('reuse accepted')
                except ValueError:reuses+=1
                # Corruption detection is a functional negative control, not a security proof.
                first=(W[0]@labels)%P
                bad=first[0].copy();bad[0]=(bad[0]+1)%P
                try:evaluator.tables[0][0][0].evaluate(bad);raise AssertionError('forgery accepted')
                except ValueError:forged+=1
                c.update(trial=trial,prep_seconds=prep,online_seconds=online,exact=True)
                records.append(c)
    # Direct setup on the original full-field ReLU fixture, to compare with last round.
    original=[]
    for depth in [2,4,8]:
        tables=depth*4*(16+P*(LANES+16))
        client_unseeded=(4+1+4)*LANES
        old={2:114914,4:229666,8:459170}[depth]
        original.append({'depth':depth,'previous_recorded_setup':old,
                         'same_original_gate_layout_local_setup':tables+client_unseeded,
                         'local_setup_plus_client_seed':tables+32,
                         'note':'algebraic accounting using original serialized layout; original OT timings not rerun'})
    result={'exact_graphs':exact,'exact_linear_stages':sum(r['depth'] for r in records),
            'reuse_rejections':reuses,'corrupt_labels_rejected':forged,
            'records':records,'original_layout_comparison':original,
            'environment':{'python':platform.python_version(),'numpy':np.__version__,'machine':platform.machine(),'gpu':False},
            'scope':'synthetic bounded fixed-point ReLU/rescale graphs; no full LLM; unaudited garbling'}
    Path(__file__).with_name('graph_results.json').write_text(json.dumps(result,indent=2))
    for depth in [2,4,8]:
        print('depth',depth)
        for v in ['full_separate','full_fused','bounded_hashed']:
            rs=[r for r in records if r['depth']==depth and r['variant']==v]
            print(v,round(np.mean([r['all_setup_payload_bytes'] for r in rs])), 'prep',np.median([r['prep_seconds'] for r in rs]),'online',np.median([r['online_seconds'] for r in rs]))
    print('graphs',exact,'stages',result['exact_linear_stages'])
if __name__=='__main__':main()
