"""Model-aware support bounds and explicit failures of unsafe shortcuts."""
from __future__ import annotations
import hashlib, json, math
from pathlib import Path
import numpy as np
from model_garbling import P, LANES, derive, delta_from, encode

def ceil_sqrt(x: int) -> int:
    a=math.isqrt(int(x));return a+(a*a<x)

def crt_count(bound: int) -> int:
    prod=1
    for i,p in enumerate([251,241,239,233,229,227],1):
        prod*=p
        if prod>2*bound:return i
    raise ValueError('unsupported bound')

def bounds(rng):
    result=[];checks=0
    for d in [64,256,896,4096]:
        m=256;S=4
        W=rng.integers(-7,8,(m,d),dtype=np.int64)
        one=np.abs(W).sum(axis=1);two=(W*W).sum(axis=1)
        a=(ceil_sqrt(4*S*S*d)+2)//2
        box=one*a
        ball=np.array([(ceil_sqrt(4*S*S*d*int(v))+int(u)+1)//2 for u,v in zip(one,two)])
        z=rng.normal(size=(128,d));z*=np.sqrt(d)/np.linalg.norm(z,axis=1,keepdims=True)
        x=np.rint(S*z).astype(np.int64)
        y=x@W.T
        assert np.all(np.abs(y)<=ball[None,:]);checks+=y.size
        # Inputs near row-wise extremal directions, not just typical draws.
        boundary=np.sqrt(d)*W[:32].astype(float)/np.linalg.norm(W[:32],axis=1,keepdims=True)
        yb=np.sum(np.rint(S*boundary).astype(np.int64)*W[:32],axis=1)
        assert np.all(np.abs(yb)<=ball[:32]);checks+=len(yb)
        cb=np.array([crt_count(int(b)) for b in box]);cs=np.array([crt_count(int(b)) for b in ball])
        result.append({'dimension':d,'rows':m,'input_scale':S,'input_coordinate_bound':a,
                       'box_bound_median':float(np.median(box)),'ball_bound_median':float(np.median(ball)),
                       'bound_improvement_median':float(np.median(box/ball)),
                       'box_crt_residues':{str(k):int(sum(cb==k)) for k in np.unique(cb)},
                       'ball_crt_residues':{str(k):int(sum(cs==k)) for k in np.unique(cs)},
                       'mean_residue_reduction':float(1-cs.sum()/cb.sum()),
                       'boundary_fraction_of_bound_min':float(min(yb/ball[:32])),
                       'boundary_fraction_of_bound_max':float(max(yb/ball[:32]))})
    return {'rows':result,'checked_integer_products':checks,
            'scope':'synthetic public matrices; exact integer conservative bounds given normalized input L2 envelope; no downloaded model, no CRT garbling execution'}

def reachable(weights, alphabet):
    # Exact set-valued convolution; practical only for small coefficient/activation fixtures.
    s={0}
    for w in weights:
        s={x+int(w)*a for x in s for a in alphabet}
    return s

def supports(rng):
    rows=[]
    for d in [4,16,64,128]:
        for mult in [1,4]:
            densities=[];sizes=[];intervals=[]
            for _ in range(12):
                w=rng.integers(-7,8,d)*mult
                s=reachable(w,range(4));width=max(s)-min(s)+1
                densities.append(len(s)/width);sizes.append(len(s));intervals.append(width)
            rows.append({'dimension':d,'weight_multiplier':mult,'mean_support_density':float(np.mean(densities)),
                         'mean_support_size':float(np.mean(sizes)),'mean_interval_size':float(np.mean(intervals))})
    return rows

def sparse_color_attack(rng):
    # Any nonempty proper cyclic interval has one unique translation in a prime field.
    exact=0;count=0
    for width in [1,7,31,63,127,250]:
        D=set(range(width))
        for _ in range(32):
            shift=int(rng.integers(P));x=int(rng.integers(width))
            exposed={(d+shift)%P for d in D}
            candidates=[b for b in range(P) if {(d+b)%P for d in D}==exposed]
            assert candidates==[shift]
            observed_color=(x+shift)%P
            recovered=(observed_color-candidates[0])%P
            assert recovered==x;exact+=1;count+=1
    return {'attempts':count,'exact_inputs_recovered':exact,
            'attack':'exposed sparse point-and-permute indices identify the hidden cyclic shift'}

def reuse_attack(rng):
    exact=0
    for trial in range(256):
        root=hashlib.sha256(f'attack fixture {trial}'.encode()).digest()
        d=delta_from(root);base=derive(root,b'base',(LANES,))
        x=int(rng.integers(P));y=(x+int(rng.integers(1,P)))%P
        a=encode(base,x,d);b=encode(base,y,d)
        difference=(a-b)%P
        recovered=difference*pow(int(difference[-1]),-1,P)%P
        assert np.array_equal(recovered,d);exact+=1
    return {'distinct_input_label_pairs':256,'secret_offsets_recovered':exact,
            'scope':'unsafe reuse of the SAME affine wire base across different values; not ordinary fanout of one immutable label'}

def permutation_attack(rng):
    # Monomial re-encoding, with altered weights. Negative control, not garbling.
    exact=0
    for d in [8,16,32,64]:
        for _ in range(16):
            W=rng.normal(size=(d,d))
            rows=rng.permutation(d);cols=rng.permutation(d)
            transformed=W[rows][:,cols]
            # Permutation-independent sorted row signatures are unique here.
            sr=np.sort(W,axis=1);st=np.sort(transformed,axis=1)
            recovered_rows=np.array([int(np.argmin(np.max(np.abs(sr-r),axis=1))) for r in st])
            assert np.array_equal(recovered_rows,rows)
            rowaligned=transformed[np.argsort(recovered_rows)]
            recovered_cols=np.array([int(np.argmin(np.max(np.abs(W-c[:,None]),axis=0))) for c in rowaligned.T])
            assert np.array_equal(recovered_cols,cols);exact+=1
    return {'transformed_weight_fixtures':64,'both_secret_permutations_recovered':exact,
            'scope':'pure independent input/output permutations of known public W; does NOT cover every dense secret basis or scaling scheme'}

def lane_collapse_attack(rng):
    recovered=0
    for trial in range(256):
        root=hashlib.sha256(f'lane collapse {trial}'.encode()).digest()
        delta=delta_from(root)
        j=next(j for j in range(LANES-1) if delta[j] != 0)
        # Public slopes sufficient to rebuild every coordinate from coordinate j.
        slopes=delta*pow(int(delta[j]),-1,P)%P
        # The fixed point-and-permute component makes the hidden scale public.
        recovered_scalar=pow(int(slopes[-1]),-1,P)
        reconstructed=slopes*recovered_scalar%P
        assert np.array_equal(reconstructed,delta);recovered+=1
    return {'attempts':256,'secret_offsets_recovered':recovered,
            'scope':'public affine reconstruction from one scalar coordinate with fixed permutation offset; not every succinct encoding'}

def main():
    rng=np.random.default_rng(148761)
    r={'rms_envelope':bounds(rng),'integer_support':supports(rng),
       'sparse_index_attack':sparse_color_attack(rng),'wire_reuse_attack':reuse_attack(rng),
       'permuted_model_attack':permutation_attack(rng),'single_lane_reconstruction_attack':lane_collapse_attack(rng)}
    Path(__file__).with_name('math_results.json').write_text(json.dumps(r,indent=2))
    print(json.dumps(r,indent=2))
if __name__=='__main__':main()
