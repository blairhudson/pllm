from pathlib import Path
import hashlib,json,statistics,platform
p=Path(__file__).parent
g=json.loads((p/'graph_results.json').read_text());m=json.loads((p/'math_results.json').read_text());c=json.loads((p/'crt_results.json').read_text());k=json.loads((p/'packed_results.json').read_text())
summary={'graph_exact':g['exact_graphs'],'graph_stages':g['exact_linear_stages'],'graphs':[],
         'math_checked_integer_products':m['rms_envelope']['checked_integer_products'],
         'crt_label_coordinates':c['checked_label_coordinates'],'packed_label_coordinates':k['exact_coordinates'],
         'scope':'single-process reference; synthetic public weights; no full LLM, GPU, or security proof'}
for depth in [2,4,8]:
    vals={v:statistics.mean(r['all_setup_payload_bytes'] for r in g['records'] if r['depth']==depth and r['variant']==v)
          for v in ['full_separate','full_fused','bounded_hashed']}
    summary['graphs'].append({'depth':depth,**vals,
        'sparse_reduction_vs_fused':1-vals['bounded_hashed']/vals['full_fused'],
        'combined_reduction_vs_separate':1-vals['bounded_hashed']/vals['full_separate']})
summary['attacks']={s:m[s] for s in ['sparse_index_attack','wire_reuse_attack','permuted_model_attack','single_lane_reconstruction_attack']}
summary['model_weight_tests_rejected']=k['model_substitutions_rejected']
(p/'summary_results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
