"""CPU arithmetic microbenchmark with real residue labels, not a transformer benchmark."""
from __future__ import annotations
import json, math, os, platform, statistics, time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits, threadpool_info
from model_garbling import LANES

def ceil_sqrt(v):
    x=math.isqrt(int(v));return x+(x*x<v)

def reconstruct(residues, primes):
    product=math.prod(primes)
    value=np.zeros(residues[0].shape,dtype=np.int64)
    for r,p in zip(residues,primes):
        part=product//p
        value=(value+r*(part*pow(part,-1,p)))%product
    return np.where(value>product//2,value-product,value)

def make_labels(rng,x,primes):
    ins=[];bases=[];deltas=[]
    for p in primes:
        b=rng.integers(0,p,(len(x),LANES),dtype=np.int64)
        d=rng.integers(0,p,LANES,dtype=np.int64);d[-1]=1
        ins.append((b+x[:,None]*d)%p);bases.append(b);deltas.append(d)
    return np.concatenate(ins,axis=1).astype(np.float32),bases,deltas

def main():
    # Reproducible synthetic masks ONLY for kernel checks, not deployment keys.
    rng=np.random.default_rng(123141);rows=[];checked=0
    with threadpool_limits(limits=4):
        for n in [896,2048,4096]:
            W=rng.integers(-7,8,(n,n),dtype=np.int8).astype(np.float32)
            z=rng.normal(size=n);z*=np.sqrt(n)/np.linalg.norm(z);x=np.rint(z).astype(np.int64)
            wi=W.astype(np.int64)
            one=np.abs(wi).sum(axis=1);two=(wi*wi).sum(axis=1)
            ball=max((ceil_sqrt(4*n*int(b))+int(a)+1)//2 for a,b in zip(one,two))
            assert 2*ball<251*241
            expected=wi@x
            modes={};data={}
            for count in [2,3]:
                ps=[251,241,239][:count]
                X,bases,deltas=make_labels(rng,x,ps)
                mods=np.repeat(np.array(ps,dtype=np.float32),LANES)[None,:]
                def run(X=X,mods=mods):return np.remainder(W@X,mods)
                actual=run().astype(np.int64)
                rs=[]
                for j,(p,b,d) in enumerate(zip(ps,bases,deltas)):
                    mapped=(wi@b)%p
                    out=actual[:,j*LANES:(j+1)*LANES]
                    semantic=(out[:,-1]-mapped[:,-1])%p
                    assert np.array_equal(out,(mapped+semantic[:,None]*d)%p)
                    rs.append(semantic);checked+=out.size
                assert np.array_equal(reconstruct(rs,ps),expected)
                modes[str(count)+'_residues']=run
                data[str(count)+'_residues']={'lanes':count*LANES,'model_specific_integer_bound':int(ball)}
            xf=x.astype(np.float32)
            modes['scalar_integer_float32']=lambda:W@xf
            assert np.array_equal(modes['scalar_integer_float32']().astype(np.int64),expected)
            samples={k:[] for k in modes}
            for f in modes.values():
                for _ in range(3):f()
            for _ in range(15):
                for k in rng.permutation(list(modes)):
                    st=time.perf_counter();modes[k]();samples[k].append(time.perf_counter()-st)
            med={k:float(statistics.median(v)) for k,v in samples.items()}
            rows.append({'dimension':n,'sample_seconds':samples,'median_seconds':med,
                         'two_vs_three_speedup':med['3_residues']/med['2_residues'],
                         'two_residue_over_scalar':med['2_residues']/med['scalar_integer_float32'],
                         'variants':data,'input_bits':'rounded normalized synthetic vector; same integer graph for both CRT representations'})
    result={'rows':rows,'checked_label_coordinates':checked,'all_reconstructed_products_exact':True,
            'environment':{'python':platform.python_version(),'numpy':np.__version__,'machine':platform.machine(),'threadpools':threadpool_info(),'threads':4,'gpu':False},
            'scope':'includes FP32 exact-integer public matmul and residue reduction; excludes garbled nonlinearities, setup, wire serialization, and native low-bit model kernels'}
    Path(__file__).with_name('crt_results.json').write_text(json.dumps(result,indent=2))
    for r in rows:print(r['dimension'],r['median_seconds'],'CRT speedup',r['two_vs_three_speedup'],'vs scalar',r['two_residue_over_scalar'])
    print('exact coords',checked)
if __name__=='__main__':main()
