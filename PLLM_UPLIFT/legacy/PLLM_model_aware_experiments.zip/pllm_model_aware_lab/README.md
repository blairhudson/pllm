# PLLM model-aware offline preparation experiments

Single online evaluator; offline Preparation now holds public weights; Client does not. No HE, no OT and no second online inference worker in these new reference programs.

Read `REPORT.md` before interpreting the results. This is unaudited research code, not production cryptography. All model matrices are synthetic; no LLM or GPU throughput is demonstrated.

## Run

Python 3.10 or newer, NumPy and threadpoolctl are required. Tested environment details are in the JSON results.

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python run_graphs.py
OPENBLAS_NUM_THREADS=1 python bounds_and_attacks.py
OPENBLAS_NUM_THREADS=4 python crt_benchmark.py
OPENBLAS_NUM_THREADS=1 python packed_and_integrity.py
python summarize.py
```

Each graph receives a fresh random root. Fixtures are deterministic, while timing and cryptographic material vary. No external downloads or network access are needed.

## Contents

- `model_garbling.py`: one-time affine-label graph, separate/fused/bounded gate variants, exact serializer byte counts, client encoding/decoding.
- `run_graphs.py`: 108 graph executions and malformed-label/reuse controls; writes `graph_results.json`.
- `bounds_and_attacks.py`: exact integer geometric bounds, reachable supports and attacks; writes `math_results.json`.
- `crt_benchmark.py`: actual two/three-residue label arithmetic, CRT reconstruction, CPU timing; writes `crt_results.json`.
- `packed_and_integrity.py`: INT4 tile packing and exact residue arithmetic, changed-weight controls, explicitly hypothetical GPU budget; writes `packed_results.json`.
- `summarize.py`: aggregates captured results into `summary_results.json`.
- `REPORT.md`: methods, accounting, negative results, literature comparisons and security limitations.

The sparse hash-indexed garbling is a candidate implementation, not a proved construction. Never expose sparse point-and-permute indices; the included attack recovers private inputs from them. Never reuse one affine wire base for different private values. Do not confuse a public bound with an empirical activation range.
