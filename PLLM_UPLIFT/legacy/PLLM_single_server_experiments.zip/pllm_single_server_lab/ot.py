"""Research-only prime-order DH OT and offline matrix products.

Real Ristretto255 via libsodium; no ideal-OT oracle and no HE.
Semi-honest functional reference, not audited or maliciously secure.
The runner routes messages between separate role objects in one process.
"""
from __future__ import annotations
import ctypes as C
import ctypes.util
import hashlib
import os
import secrets
from dataclasses import dataclass
import numpy as np

libname = ctypes.util.find_library('sodium')
if not libname:
    raise RuntimeError('libsodium with Ristretto255 support is required')
lib = C.CDLL(libname)
lib.sodium_init()
Buf = C.c_ubyte * 32

def _buf(x: bytes) -> Buf:
    if len(x) != 32: raise ValueError('expected 32 bytes')
    return Buf.from_buffer_copy(x)

def scalar() -> bytes:
    out = Buf(); lib.crypto_core_ristretto255_scalar_random(out)
    return bytes(out)

def base(s: bytes) -> bytes:
    out=Buf()
    if lib.crypto_scalarmult_ristretto255_base(out,_buf(s)) != 0: raise ValueError('invalid scalar')
    return bytes(out)

def point(op: str, a: bytes, b: bytes) -> bytes:
    out=Buf()
    fn=getattr(lib, 'crypto_core_ristretto255_'+op)
    if fn(out,_buf(a),_buf(b)) != 0: raise ValueError('invalid point')
    return bytes(out)

def mul(s: bytes, p: bytes) -> bytes:
    if lib.crypto_core_ristretto255_is_valid_point(_buf(p)) != 1: raise ValueError('invalid point')
    out=Buf()
    if lib.crypto_scalarmult_ristretto255(out,_buf(s),_buf(p)) != 0: raise ValueError('identity or invalid point')
    return bytes(out)

def pad(shared: bytes, context: bytes, n: int) -> bytes:
    return hashlib.shake_256(b'PLLM-research-OT-v1'+context+shared).digest(n)

def xor(a: bytes,b: bytes) -> bytes:
    if len(a)!=len(b): raise ValueError('length mismatch')
    return bytes(x^y for x,y in zip(a,b))

class Sender:
    def __init__(self):
        self.secret=scalar(); self.A=base(self.secret); self.session=os.urandom(32)
        self.AA=mul(self.secret,self.A)
    def transfer(self, B:bytes, index:int, m0:bytes,m1:bytes) -> tuple[bytes,bytes]:
        v=mul(self.secret,B)
        ctx=self.session+index.to_bytes(8,'little')
        # a*(B-A) = a*B-a*A; reuse a*A for the batch.
        return xor(m0,pad(v,ctx,len(m0))), xor(m1,pad(point('sub',v,self.AA),ctx,len(m1)))

class Receiver:
    def __init__(self, A:bytes, session:bytes):
        self.A=A; self.session=session; self.pending={}
    def request(self,choice:int,index:int)->bytes:
        if choice not in (0,1) or index in self.pending: raise ValueError('bad choice or duplicate index')
        b=scalar(); B=base(b)
        if choice: B=point('add',B,self.A)
        self.pending[index]=(choice,mul(b,self.A))
        return B
    def receive(self,index:int,pair:tuple[bytes,bytes])->bytes:
        choice,shared=self.pending.pop(index)
        msg=pair[choice]; ctx=self.session+index.to_bytes(8,'little')
        return xor(msg,pad(shared,ctx,len(msg)))

@dataclass
class ModelHolder:
    W: np.ndarray
    modulus: int=251
    def __post_init__(self):
        self.W=np.asarray(self.W,dtype=np.int64)%self.modulus
        self.sender=Sender(); self.pad_sums=None
    def begin(self,lanes:int):
        self.pad_sums=np.zeros((self.W.shape[0],lanes),dtype=np.int64)
        return self.sender.A,self.sender.session
    def respond(self,B:bytes,index:int,column:int,lane:int,bit:int):
        p=self.modulus; m=self.W.shape[0]
        t=np.array([secrets.randbelow(p) for _ in range(m)],dtype=np.int64)
        self.pad_sums[:,lane]=(self.pad_sums[:,lane]+t)%p
        m1=(t+(1<<bit)*self.W[:,column])%p
        return self.sender.transfer(B,index,t.astype(np.uint8).tobytes(),m1.astype(np.uint8).tobytes())
    def finish(self)->bytes:
        return self.pad_sums.astype(np.uint8).tobytes()

@dataclass
class MaskHolder:
    X: np.ndarray
    output_rows:int
    modulus:int=251
    def begin(self,A,session):
        self.X=np.asarray(self.X,dtype=np.int64)%self.modulus
        self.receiver=Receiver(A,session)
        self.result=np.zeros((self.output_rows,self.X.shape[1]),dtype=np.int64)
    def requests(self):
        idx=0
        for i in range(self.X.shape[0]):
            for lane in range(self.X.shape[1]):
                for bit in range(self.modulus.bit_length()):
                    choice=(int(self.X[i,lane])>>bit)&1
                    yield idx,i,lane,bit,self.receiver.request(choice,idx)
                    idx+=1
    def accept(self,index,lane,pair):
        out=np.frombuffer(self.receiver.receive(index,pair),dtype=np.uint8).astype(np.int64)
        self.result[:,lane]=(self.result[:,lane]+out)%self.modulus
    def finish(self,pads:bytes)->np.ndarray:
        t=np.frombuffer(pads,dtype=np.uint8).reshape(self.result.shape)
        return (self.result-t)%self.modulus

def offline_product(server:ModelHolder,prep:MaskHolder):
    """Message router. W exists only inside server; X only inside prep."""
    A,session=server.begin(prep.X.shape[1]); prep.begin(A,session)
    count=0; request_bytes=0; response_bytes=len(A)+len(session)
    for idx,i,lane,bit,B in prep.requests():
        pair=server.respond(B,idx,i,lane,bit)
        prep.accept(idx,lane,pair)
        count+=1; request_bytes+=len(B); response_bytes+=sum(map(len,pair))
    pads=server.finish(); response_bytes+=len(pads)
    return prep.finish(pads), {'base_ots':count,'prep_to_inference_bytes':request_bytes,
        'inference_to_prep_bytes':response_bytes,'total_offline_bytes':request_bytes+response_bytes}
