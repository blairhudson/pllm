"""Generate independently checkable totals from the captured experiment files."""
from pathlib import Path
import json

p=Path(__file__).resolve().parent
load=lambda name:json.loads((p/name).read_text())
a=load('protocol_results.json');b=load('benchmark_results.json')
c=load('differential_results.json');d=load('kronecker_results.json')
result={
 'architecture':'one online evaluator; offline preparation; no HE; no prep weight-matrix input',
 'protocol':{'base_OT_cases':a['base_ot']['correct_transfers'],
   'offline_product_coordinates':sum(r['exact_coordinates'] for r in a['model_free_offline_products']),
   'fresh_graphs':a['single_evaluator_graphs']['exact_graphs'],
   'linear_and_unary_stages':a['single_evaluator_graphs']['exact_linear_stages'],
   'fresh_private_products':a['arithmetic_half_gates']['fresh_product_tests']},
 'by_graph_depth':[{k:r[k] for k in ('depth','width','online_input_bytes','online_output_bytes','all_setup_bytes','base_ots')}
     for r in a['single_evaluator_graphs']['cases'] if r['trial']==0],
 'differential':{'functions_tested':sum(r['functions'] for r in c['exhaustive_functions']),
    'functions_with_input_independent_signatures':sum(r['constant_signature_functions'] for r in c['exhaustive_functions']),
    'exposed_offset_attack':c['exposed_label_offset']},
 'kernel_checks':sum(r['exact_checked_coordinates'] for r in b['matrices']),
 'kronecker_checks':sum(r['exact_checked_coordinates'] for r in d['matrices']),
 'batch_ratios':[{k:r[k] for k in ('n','ratio_18_lanes_to_best_scalar','ratio_72_lanes_to_best_scalar','batch18_speedup_vs_separate')} for r in b['matrices']],
 'packing_ratios':[{k:r[k] for k in ('n','packed_over_unpacked_ratio')} for r in d['matrices']],
 'calculated_not_executed_8192_square_offline_OT_ciphertext_bytes':8192**2*18*8*2,
 'calculated_not_executed_8192_square_offline_OT_query_bytes':8192*18*8*32,
}
(p/'summary_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
