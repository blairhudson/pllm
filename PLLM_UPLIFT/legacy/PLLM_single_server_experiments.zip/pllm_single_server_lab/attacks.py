"""Adversarial tests of deliberately optimistic, unproven constructions.
These are attacks on specific proposals, not general impossibility claims.
"""
from __future__ import annotations
import math, itertools
import numpy as np

def rank_mod(A,p):
    A=np.array(A,dtype=np.int64)%p; r=0
    for col in range(A.shape[1]):
        nz=np.flatnonzero(A[r:,col])
        if not len(nz):continue
        j=r+int(nz[0]);A[[r,j]]=A[[j,r]]
        A[r]=(A[r]*pow(int(A[r,col]),-1,p))%p
        for i in range(A.shape[0]):
            if i!=r and A[i,col]:A[i]=(A[i]-A[i,col]*A[r])%p
        r+=1
        if r==A.shape[0]:break
    return r

def commutant_dimension(matrices,p):
    n=matrices[0].shape[0]; eqs=[]
    for W in matrices:
        for i in range(n):
            for j in range(n):
                row=np.zeros(n*n,dtype=np.int64)
                for k in range(n):
                    row[i*n+k]+=W[k,j];row[k*n+j]-=W[i,k]
                eqs.append(row)
    return n*n-rank_mod(eqs,p)

def gf_mul(a,b):
    out=0
    for _ in range(8):
        if b&1:out^=a
        a<<=1
        if a&256:a^=0x11b
        b>>=1
    return out

def run():
    rng=np.random.default_rng(64021); result={}
    # Coefficients of (d+r)^3-s over Z_2^k directly reveal r through 3r.
    n=0
    for k in [8,16,24,32,64]:
        q=1<<k
        for _ in range(100):
            r=int.from_bytes(rng.bytes(8),'little')%q
            coeff2=3*r%q
            assert coeff2*pow(3,-1,q)%q==r;n+=1
    result['published_cubic_coefficients']={'exact_mask_recoveries':n,'tested_ring_bits':[8,16,24,32,64]}
    # 2-adic degeneracy in a square hides only one bit of a k-bit mask.
    sq=[]
    for k in [4,6,8,10]:
        q=1<<k
        sizes=[sum((2*c)%q==(2*r)%q for c in range(q)) for r in range(q)]
        assert set(sizes)=={2};sq.append({'bits':k,'mask_candidates':2,'leaked_bits':k-1,'masks_tested':q})
    result['two_adic_square'] = sq
    # Exposed phase coefficients reveal a full cyclic Fourier mask.
    N=16384;maxerr=0.0;ok=0
    for r in range(N):
        th=2*math.pi*r/N
        a=round(math.cos(th)*2**30);b=round(math.sin(th)*2**30)
        rr=round((math.atan2(b,a)%(2*math.pi))*N/(2*math.pi))%N
        ok+=rr==r
    assert ok==N
    result['exposed_fourier_phase']={'phases_recovered':ok,'domain':N,'coefficient_fraction_bits':30}
    # Copyable scalar bridge G(d)=ReLU(d+r)-s; full-domain finite differences recover r.
    q=256; grid=np.arange(q,dtype=np.int64)
    f=np.where(grid<q//2,grid,0)
    templates=np.array([(f[(grid+r)%q]-f[r])%q for r in range(q)])
    fork=0
    for r in range(q):
        s=int(rng.integers(q));G=(f[(grid+r)%q]-s)%q
        candidates=np.flatnonzero(np.all(templates==(G-G[0])%q,axis=1))
        assert candidates.tolist()==[r];fork+=1
    result['copyable_bridge']={'input_masks_recovered':fork,'queries_per_bridge':q,'domain':q}
    # A fast secret conjugation preserving unchanged public matrices collapses.
    comm=[]
    for n in [3,4,5,6]:
        dims=[]
        for _ in range(20):
            W1=rng.integers(0,257,(n,n));W2=rng.integers(0,257,(n,n))
            dims.append(commutant_dimension([W1,W2],257))
        comm.append({'dimension':n,'trials':len(dims),'commutant_dimensions':dims})
    assert all(set(row['commutant_dimensions'])=={1} for row in comm)
    result['commuting_secret_basis']=comm
    # Scalar hiding loses input directions: classify a finite public codebook.
    code=rng.integers(1,257,(256,6));canon=lambda x:tuple((x*pow(int(x[0]),-1,257))%257)
    lookup={canon(x):i for i,x in enumerate(code)}
    assert len(lookup)==len(code)
    recovered=0
    for i,x in enumerate(code):
        c=int(rng.integers(1,257));recovered+=lookup[canon(c*x%257)]==i
    result['scalar_orbit_dictionary']={'inputs_identified':recovered,'public_codebook_size':len(code)}
    # Freshman's dream: the apparently free nonlinear function is F2-linear.
    sqr=[gf_mul(a,a) for a in range(256)];cubic=[gf_mul(sqr[a],a) for a in range(256)]
    additive=0;cubic_failures=0;relu_failures=0
    relu=np.where(grid<128,grid,0).tolist()
    for a in range(256):
        for b in range(256):
            additive+=sqr[a^b]==sqr[a]^sqr[b]
            cubic_failures+=cubic[a^b]!=(cubic[a]^cubic[b])
            relu_failures+=relu[a^b]!=(relu[a]^relu[b])
    assert additive==65536
    result['frobenius_escape']={'additive_square_cases':additive,'cubic_nonadditive_cases':cubic_failures,'relu_nonadditive_cases':relu_failures}
    return result
