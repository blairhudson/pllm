"""Test the hypothesis that two label lanes can share one exact FP64 dot.

This is Kronecker substitution with guard bits, not a cryptographic primitive.
It keeps the weight matrix public and preserves each encoded component.
"""
from __future__ import annotations
import json, math, statistics, time, random
from pathlib import Path
import numpy as np
import torch


def run():
    torch.set_num_threads(4)
    rng=np.random.default_rng(1828);records=[]
    for n in (2048,4096,8192):
        Wi=rng.integers(-7,8,size=(n,n),dtype=np.int8)
        Li=rng.integers(0,251,size=(n,18),dtype=np.int64)
        W=torch.from_numpy(Wi.astype(np.float32));W64=W.double()
        L=torch.from_numpy(Li.astype(np.float32));L64=L.double()
        bound=n*7*250
        bits=(2*bound).bit_length();base=1<<bits
        assert bound<base//2 and bound*(1+base)<2**53
        packed=(L64[:,0::2]+base*L64[:,1::2]).contiguous()
        def normal():return (W@L).remainder(251)
        def combined():
            z=(W64@packed).round().to(torch.int64)
            low=(z+base//2).remainder(base)-base//2
            high=(z-low)//base
            return torch.stack((low,high),dim=2).reshape(n,18).remainder(251)
        ix=rng.choice(n,32,replace=False)
        oracle=Wi[ix].astype(np.int64)@Li%251
        assert np.array_equal(normal()[ix].numpy(),oracle)
        assert np.array_equal(combined()[ix].numpy(),oracle)
        times={'18_fp32_lanes':[],'9_packed_fp64_lanes':[]}
        tasks=[('18_fp32_lanes',normal),('9_packed_fp64_lanes',combined)]
        for _,f in tasks:f();f()
        for j in range(9):
            random.Random(j).shuffle(tasks)
            for name,f in tasks:
                t=time.perf_counter();answer=f();times[name].append(time.perf_counter()-t)
        med={name:statistics.median(samples) for name,samples in times.items()}
        record={'n':n,'packing_base':base,'max_signed_component_dot':bound,
                'packed_dot_absolute_bound':bound*(1+base),'exact_checked_coordinates':32*18,
                'seconds_median':med,'seconds_samples':times,
                'packed_over_unpacked_ratio':med['9_packed_fp64_lanes']/med['18_fp32_lanes'],
                'weight_storage_bytes_fp32':n*n*4,'weight_storage_bytes_fp64':n*n*8}
        records.append(record);print(record,flush=True)
    result={'matrices':records,'packing_excluded_from_timing':True,
            'included':'matrix evaluation, remainder, and packed-output extraction',
            'scope':'four-thread CPU; no GPU, garbled gates, CRT, rescaling or model execution'}
    Path(__file__).with_name('kronecker_results.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':run()
