"""Exhaustive finite-difference tests and explicit bad-encoding attack.

These are conditional algebra results for an evaluator that can freely query
scalar remasking functions. They are NOT a lower bound for general garbling.
"""
from __future__ import annotations
import itertools, json
from pathlib import Path
import numpy as np
from garbling import P,LANES,Unary,random,enc,relu


def signature(f,x,q):
    return tuple((f[(x+t)%q]-f[x])%q for t in range(q))


def all_functions():
    result=[]
    for q in (2,3,4,5):
        tested=private=0
        for f in itertools.product(range(q),repeat=q):
            equal=all(signature(f,x,q)==signature(f,0,q) for x in range(q))
            a=(f[1]-f[0])%q
            affine=all(f[x]==(a*x+f[0])%q for x in range(q))
            assert equal==affine
            tested+=1; private+=equal
        result.append({'q':q,'functions':tested,'constant_signature_functions':private,
                       'affine_functions':q*q})
    return result


def profiles():
    out=[]
    for q in (16,64,251,256):
        for name,f in [('affine',[(7*x+11)%q for x in range(q)]),
                       ('square',[x*x%q for x in range(q)]),
                       ('relu',[x if x <=(q-1)//2 else 0 for x in range(q)])]:
            groups={}
            for x in range(q):groups.setdefault(signature(f,x,q),[]).append(x)
            out.append({'q':q,'function':name,'distinct_signatures':len(groups),
                        'smallest_ambiguity':min(map(len,groups.values())),
                        'largest_ambiguity':max(map(len,groups.values()))})
    return out


def exposed_delta_attack():
    # Negative control: standard garbling keeps delta secret. Deliberately
    # expose it here so the evaluator can forge labels for shifted semantics.
    templates={signature([relu(x) for x in range(P)],x,P):x for x in range(P)}
    assert len(templates)==P
    recovered=0; queries=0
    for trial in range(24):
        delta=random((LANES,));delta[-1]=1
        a=random((LANES,));b=random((LANES,))
        gate=Unary(a,b,delta,relu)
        x=(trial*47+9)%P
        label=enc(a,x,delta)
        initial=gate.evaluate(label)
        observable=[]
        for t in range(P):
            forged=(label+t*delta)%P
            shifted=gate.evaluate(forged)
            observable.append(int((shifted[-1]-initial[-1])%P));queries+=1
        assert templates[tuple(observable)]==x
        recovered+=1
    return {'trials':24,'exact_input_recoveries':recovered,'forged_queries':queries,
            'condition':'global label offset deliberately disclosed; NOT an attack on secret-offset garbling'}


def run():
    result={'exhaustive_functions':all_functions(),'signatures':profiles(),
            'exposed_label_offset':exposed_delta_attack()}
    Path(__file__).with_name('differential_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':run()
