"""Matched CPU microbenchmark of a native scalar vs batched label lanes.

NOT a GPU benchmark, quantized LLM engine, full garbling benchmark, or TPS.
The signed 4-bit weights and byte inputs guarantee exact FP32 accumulation
at these dimensions: n*7*250 < 2^24. W is stored in FP32 here.
"""
from __future__ import annotations
import json,time,statistics,platform,random
import numpy as np
import torch

def run():
    torch.set_num_threads(4)
    rng=np.random.default_rng(1729);rows=[]
    for n in [2048,4096,8192]:
        W=torch.from_numpy(rng.integers(-7,8,size=(n,n),dtype=np.int8).astype(np.float32))
        columns=torch.from_numpy(rng.integers(0,251,size=(n,72),dtype=np.int16).astype(np.float32))
        vectors={k:columns[:,:k].contiguous() for k in [1,4,18,36,72]}
        # Independent int64 check on 24 sampled output rows.
        ix=rng.choice(n,24,replace=False); wi=W[ix].numpy().astype(np.int64)
        for k,L in vectors.items():
            got=(W@L).remainder(251)
            expected=wi@L.numpy().astype(np.int64)%251
            assert np.array_equal(got[ix].numpy(),expected)
        tasks=list(vectors)+['gemv','separate18'];timings={str(k):[] for k in tasks}
        def task(k):
            if k=='gemv':return torch.mv(W,columns[:,0].contiguous()).remainder(251)
            if k=='separate18':return torch.stack([torch.mv(W,vectors[18][:,i].contiguous()) for i in range(18)],dim=1).remainder(251)
            return (W@vectors[k]).remainder(251)
        for k in tasks: task(k);task(k)
        for rep in range(9):
            random.Random(222+rep).shuffle(tasks)
            for k in tasks:
                t=time.perf_counter();out=task(k);timings[str(k)].append(time.perf_counter()-t)
        med={k:statistics.median(v) for k,v in timings.items()}
        rows.append({'n':n,'weight_bytes':W.numel()*W.element_size(),'max_absolute_accumulator_bound':n*7*250,
             'seconds_median':med,'seconds_samples':timings,
             'ratio_18_lanes_to_best_scalar':med['18']/min(med['1'],med['gemv']),
             'ratio_72_lanes_to_best_scalar':med['72']/min(med['1'],med['gemv']),
             'batch18_speedup_vs_separate':med['separate18']/med['18'],
             'exact_checked_coordinates':24*(1+4+18+36+72)})
        print(n, med,flush=True)
    result={'environment':{'torch':torch.__version__,'python':platform.python_version(),'threads':torch.get_num_threads(),'gpu':False},
        'baseline':'same FP32 storage, small integer weights, byte inputs, final remainder for all paths',
        'excluded':'OT, tables, crypto hashing, CRT reconstruction, rescaling, sampling, real model quality',
        'matrices':rows}
    with open('benchmark_results.json','w') as f:json.dump(result,f,indent=2)
if __name__=='__main__':run()
