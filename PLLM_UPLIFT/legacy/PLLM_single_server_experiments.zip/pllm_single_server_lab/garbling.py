"""Functional single-evaluator arithmetic-garbling reference.

Affine label arithmetic follows established arithmetic garbling; SHAKE
label-keyed tables here are research code, not a security-certified scheme.
One graph instance must receive only one encoded input assignment.
"""
from __future__ import annotations
import hashlib, os, secrets, time
import numpy as np
from ot import ModelHolder, MaskHolder, offline_product, xor

P=251
LANES=18  # 17 random offset components, plus a fixed permutation component.

def random(shape):
    return np.array([secrets.randbelow(P) for _ in range(int(np.prod(shape)))],dtype=np.int64).reshape(shape)

def enc(base,x,delta):
    return (base+np.asarray(x,dtype=np.int64)[...,None]*delta)%P

def pack(a):return np.asarray(a,dtype=np.uint8).tobytes()

def stream(key,gate,n):return hashlib.shake_256(b'PLLM-garble-table-v1'+gate+key).digest(n)

def seal(key,gate,out):
    tag=hashlib.sha256(b'PLLM-garble-tag-v1'+gate+out).digest()[:16]
    return xor(out+tag,stream(key,gate,len(out)+16))

def unseal(key,gate,c):
    plain=xor(c,stream(key,gate,len(c)))
    out,tag=plain[:-16],plain[-16:]
    if hashlib.sha256(b'PLLM-garble-tag-v1'+gate+out).digest()[:16] != tag:
        raise ValueError('invalid label/table combination')
    return np.frombuffer(out,dtype=np.uint8).astype(np.int64)

class Unary:
    def __init__(self,in_base,out_base,delta,func):
        self.gate=os.urandom(16); self.rows=[None]*P
        for x in range(P):
            inp=enc(in_base,x,delta); out=enc(out_base,int(func(x))%P,delta)
            self.rows[int(inp[-1])]=seal(pack(inp),self.gate,pack(out))
    def evaluate(self,label):
        a=np.asarray(label,dtype=np.int64)
        if a.shape!=(LANES,) or np.any(a<0) or np.any(a>=P):raise ValueError('invalid label')
        return unseal(pack(a),self.gate,self.rows[int(a[-1])])
    @property
    def nbytes(self):return len(self.gate)+sum(map(len,self.rows))

class Client:
    def __init__(self,in_base,delta,out_base):
        self.in_base=in_base.copy(); self.delta=delta.copy(); self.out_base=out_base.copy()
        self.used=False
    def encode(self,x):
        if self.used:raise ValueError('input-label state already consumed')
        self.used=True
        return enc(self.in_base,x,self.delta)
    def decode(self,labels):
        x=(labels[:,-1]-self.out_base[:,-1])%P
        if not np.array_equal(enc(self.out_base,x,self.delta),labels):raise ValueError('invalid output labels')
        return x

class Evaluator:
    def __init__(self,weights,tables):self.weights=weights;self.tables=tables
    def evaluate(self,labels, snapshots=False):
        L=labels.copy(); snaps=[]
        for W,gates in zip(self.weights,self.tables):
            L=(W@L)%P
            L=np.stack([g.evaluate(l) for g,l in zip(gates,L)])
            if snapshots:snaps.append(L.copy())
        return (L,snaps) if snapshots else L

def prepare(weights,func,use_ot=True):
    """Runner. Dealer receives dimensions and OT results, not weight arrays.

    Actual output bases are obtained through the offline message protocol.
    W@base is used only by the test oracle, not by the preparation role.
    """
    delta=random((LANES,));delta[-1]=1
    base0=random((weights[0].shape[1],LANES)); current=base0
    tables=[]; counts={'base_ots':0,'prep_to_inference_bytes':0,
       'inference_to_prep_bytes':0,'total_offline_bytes':0,'garbled_tables_bytes':0}
    for W in weights:
        if use_ot:
            mapped,c=offline_product(ModelHolder(W,P),MaskHolder(current,W.shape[0],P))
            for k,v in c.items():counts[k]+=v
        else:
            # Correctness-only local setup comparator, explicitly not model-free preparation.
            mapped=(W@current)%P
        new=random((W.shape[0],LANES))
        gates=[Unary(b,o,delta,func) for b,o in zip(mapped,new)]
        counts['garbled_tables_bytes']+=sum(g.nbytes for g in gates)
        tables.append(gates);current=new
    client=Client(base0,delta,current)
    counts['prep_to_client_bytes']=base0.size+delta.size+current.size
    counts['all_setup_bytes']=counts['total_offline_bytes']+counts['garbled_tables_bytes']+counts['prep_to_client_bytes']
    return client,Evaluator(weights,tables),counts

def relu(x):return x if x<=P//2 else 0

def reference(weights,x,func):
    for W in weights:x=np.array([func(int(y)) for y in (W@x)%P],dtype=np.int64)
    return x

class Multiply:
    """Two arithmetic half gates; O(p), not p^2, encrypted rows."""
    def __init__(self,a_base,b_base,out_base,delta):
        u=random((LANES,));v=(out_base+u)%P;r=int(b_base[-1])
        self.left=Unary(a_base,u,delta,lambda x:x*r)
        self.gate=os.urandom(16);self.rows=[None]*P
        for y in range(P):
            lab=enc(b_base,y,delta)
            payload=(v-int(lab[-1])*a_base)%P
            self.rows[int(lab[-1])]=seal(pack(lab),self.gate,pack(payload))
    def evaluate(self,a,b):
        u=self.left.evaluate(a)
        v=unseal(pack(b),self.gate,self.rows[int(b[-1])])
        return (v+int(b[-1])*a-u)%P
    @property
    def nbytes(self):return self.left.nbytes+len(self.gate)+sum(map(len,self.rows))
