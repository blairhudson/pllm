from __future__ import annotations
import json,time,platform,os
import numpy as np
from ot import Sender,Receiver,ModelHolder,MaskHolder,offline_product
from garbling import prepare,reference,relu,Unary,Multiply,enc,random,P,LANES
from attacks import run as attacks

def main():
    rng=np.random.default_rng(182022);results={}
    s=Sender();r=Receiver(s.A,s.session)
    for i in range(512):
        c=i%2;messages=(os.urandom(32),os.urandom(32)); B=r.request(c,i)
        assert r.receive(i,s.transfer(B,i,*messages))==messages[c]
    results['base_ot']={'correct_transfers':512,'group':'Ristretto255 via libsodium','hash':'SHAKE-256','security_status':'unaudited semi-honest reference; not a malicious-security implementation'}
    cases=[]
    for m,n,k in [(3,4,1),(6,4,18),(8,6,4),(5,8,18)]:
        W=rng.integers(-7,8,(m,n));X=rng.integers(P,size=(n,k))
        t=time.perf_counter();y,c=offline_product(ModelHolder(W),MaskHolder(X,m));secs=time.perf_counter()-t
        assert np.array_equal(y,W@X%P)
        cases.append({'shape':[m,n,k],**c,'elapsed_seconds':secs,'exact_coordinates':m*k})
    results['model_free_offline_products']=cases
    # Separate fresh garblings. No graph is given two distinct input assignments.
    cases=[];forgeries=0;reuse_rejected=0
    for depth in [2,4,8]:
        for trial in range(4):
            W=[rng.integers(-3,4,(4,4)) for _ in range(depth)]
            x=rng.integers(P,size=4)
            t=time.perf_counter();cl,ev,c=prepare(W,relu,use_ot=True);prep_s=time.perf_counter()-t
            L=cl.encode(x)
            t=time.perf_counter();out=ev.evaluate(L);eval_s=time.perf_counter()-t
            assert np.array_equal(cl.decode(out),reference(W,x,relu))
            try:cl.encode((x+1)%P);raise AssertionError('reuse allowed')
            except ValueError:reuse_rejected+=1
            # Query incorrect labels at the first nonlinearity.
            valid=W[0]@L%P
            for j,gate in enumerate(ev.tables[0]):
                bad=valid[j].copy();bad[-1]=(bad[-1]+1)%P
                try:gate.evaluate(bad);raise AssertionError('forgery accepted')
                except ValueError:forgeries+=1
            cases.append({'depth':depth,'width':4,'trial':trial,'online_input_bytes':L.size,'online_output_bytes':out.size,
                'online_prep_calls':0,'online_intermediate_messages':0,**c,'prep_seconds':prep_s,'online_evaluator_seconds':eval_s})
    results['single_evaluator_graphs']={'cases':cases,'exact_graphs':len(cases),'exact_linear_stages':sum(c['depth'] for c in cases),
        'invalid_label_tests_rejected':forgeries,'client_assignment_reuse_tests_rejected':reuse_rejected,
        'arithmetic':'Z_251, 18 label components; NOT native float, not an LLM',
        'prep_model_access':'no W arrays passed to the MaskHolder or garbling functions; offline OTs return label-base products'}
    prod=[]
    for i in range(128):
        delta=random((LANES,));delta[-1]=1
        a,b,z=random((3,LANES));g=Multiply(a,b,z,delta)
        x,y=map(int,rng.integers(P,size=2));v=g.evaluate(enc(a,x,delta),enc(b,y,delta))
        assert np.array_equal(v,enc(z,x*y%P,delta))
        prod.append(g.nbytes)
    results['arithmetic_half_gates']={'fresh_product_tests':len(prod),'all_exact':True,'bytes_per_gate':prod[0],'online_messages':0,'hash_decryptions_per_evaluation':2}
    results['attacks']=attacks()
    results['environment']={'python':platform.python_version(),'numpy':np.__version__,'machine':platform.machine(),'gpu':False}
    with open('protocol_results.json','w') as f:json.dump(results,f,indent=2)
    print(json.dumps({'graphs':len(cases),'linear_stages':sum(c['depth'] for c in cases),'attacks':results['attacks']},indent=2))
if __name__=='__main__':main()
