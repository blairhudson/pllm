# PLLM single-evaluator research experiments

Research snapshot: 14 September 2026.

The target is one online inference server, a small client, offline-only preparation,
no homomorphic encryption, and no model matrix supplied to Preparation. This
package explores that topology with arithmetic garbling and attacks several
attractive lower-cost alternatives. It does **not** demonstrate a private LLM,
near-native tokens per second, or an audited cryptographic implementation.

## Reproduce

Requires Python 3.11+, NumPy, and libsodium with Ristretto255 support. The optional
CPU benchmarks additionally require PyTorch. On Debian/Ubuntu, the runtime library
is commonly packaged as `libsodium23`; on macOS, Homebrew provides `libsodium`.

```sh
python -m pip install numpy torch
OPENBLAS_NUM_THREADS=1 python run_protocols.py
OPENBLAS_NUM_THREADS=1 python differential_tests.py
OPENBLAS_NUM_THREADS=1 python benchmark.py
OPENBLAS_NUM_THREADS=1 python kronecker_test.py
python summarise.py
```

Run from this directory. `run_protocols.py` and the two benchmarks write results
in the current directory. The other scripts write beside their source files.
Existing JSON files contain the captured execution used in the report. Fresh
cryptographic randomness means repeated timings and keys differ; correctness
and byte counts should agree. Benchmarks use four CPU threads and nine timing
samples per configuration. No GPU is used.

## Contents

- `REPORT.md`: construction, threat-model limits, discoveries, measurements,
  negative results and primary-source references.
- `ot.py`: actual Ristretto255 base OT and a deliberately simple offline
  matrix-product protocol. No HE and no ideal-OT oracle.
- `garbling.py`: affine labels, unary garbled gates, arithmetic multiplication
  half-gates, an offline setup router, client, and single evaluator.
- `run_protocols.py`: independent plaintext-oracle comparisons and lifecycle tests.
- `attacks.py`: polynomial, 2-adic, Fourier, executable-bridge, commuting-basis
  and Frobenius negative controls.
- `differential_tests.py`: exhaustive checks of the conditional scalar-bridge
  lemma and an attack on deliberately exposed label offsets.
- `benchmark.py`: same-matrix scalar/label-lane CPU comparison.
- `kronecker_test.py`: exact two-component packing into wider arithmetic.
- `summarise.py`: derive report totals from captured JSON.
- `*_results.json`, `*_run.log`: captured measurements and test outcomes.

## Security boundary

The code is an unaudited, semi-honest functional reference. Role objects are in
one process; the test driver sees all data. The SHAKE-based table format is an
illustration of published arithmetic-garbling structure, not a new proven
cipher. Incorrect-label rejection is not a malicious-security proof. Authenticated
model binding, active-security setup, selective-failure handling, crash/rollback
protection, production constant-time implementations and network transport are
not implemented. Never deploy this package to protect real confidential data.

Preparation learns products of public weights and its random label bases; it is
not given the weight matrices. This does not provide model confidentiality or
prevent recovering public weights from sufficiently many observations. A session
is for one input assignment; the client ledger must not be restored or cloned.

Dependencies in the captured run: Python 3.13.5, NumPy 2.3.5; see the benchmark
JSON for the exact PyTorch build. These are observed versions, not version locks.
