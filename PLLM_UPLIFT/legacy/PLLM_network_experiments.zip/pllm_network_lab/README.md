# PLLM network and model-storage experiments

Read **REPORT.md** first. This is independent research code, not a replacement for the production PLLM runtime. No model weights or secrets are included.

## Run

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python run_all.py
```

Tested on Python 3.13.5. Numba is only needed for `fast_codec.py`; the other codec tests need NumPy, and the Paillier experiments additionally need cryptography. `run_all.py` executes real 2048-bit modular exponentiations. It overwrites local JSON results. Random HE keys/coins and timings vary across runs; synthetic workload seeds are fixed.

## Files

| File | Purpose |
|---|---|
| `bound_codec.py` | Simple public per-coordinate output-bound baseline |
| `syndrome_codec.py` | Exact-on-domain reference codec and BCH decoder |
| `fast_codec.py` | Byte-compatible Numba codec and its benchmark |
| `run_experiments.py` | Positive, negative, collision, baseline and rounding tests |
| `compressed_execution.py` | Server computation on encoded corrections; prediction experiment |
| `weightless_setup.py` | Actual packed Paillier preprocessing with model-free roles |
| `toy_weightless_graph.py` | All-weights-remote toy graph, including tied embedding/head |
| `run_all.py` | Reproduction entry point |
| `*_results.json` | Captured measured results and limitations |
| `REPORT.md` | Protocol derivation, results, prior work and unresolved requirements |

Important: the codec is not an authentication mechanism. The test suite includes a concrete out-of-domain collision that decodes incorrectly without raising an exception. Do not deploy it with an assumption that decoding success proves correctness. The HE implementation is not audited or constant-time; all roles run in one process. Full model-authenticated verification and an efficient real-model embedding boundary are not implemented.
