"""Simple guaranteed baseline: public per-coordinate signed-output bounds.
Client needs a trusted width manifest, not W. No empirical outlier assumptions.
"""
from __future__ import annotations
import numpy as np
from syndrome_codec import pack_unsigned,unpack_unsigned,centered,DecodeError

class PublicBoundCodec:
    def __init__(self,widths:np.ndarray):
        self.widths=np.asarray(widths,dtype=np.int64)
        if self.widths.ndim!=1 or np.any(self.widths<1) or np.any(self.widths>32):
            raise ValueError('Invalid public widths')
        self.groups=[(int(w),np.flatnonzero(self.widths==w)) for w in np.unique(self.widths)]
        self.packet_bytes=sum((len(indices)*w+7)//8 for w,indices in self.groups)
    def encode(self,z:np.ndarray)->bytes:
        z=np.asarray(z,dtype=np.int64)
        if z.shape!=self.widths.shape:raise ValueError('Wrong vector size')
        return b''.join(pack_unsigned(z[indices]&((1<<w)-1),w) for w,indices in self.groups)
    def decode(self,packet:bytes,s:np.ndarray)->np.ndarray:
        if len(packet)!=self.packet_bytes:raise DecodeError('Invalid packet size')
        s=np.asarray(s,dtype=np.int64)
        if s.shape!=self.widths.shape:raise ValueError('Wrong mask size')
        result=np.empty(len(self.widths),dtype=np.int64);offset=0
        for w,indices in self.groups:
            length=(len(indices)*w+7)//8
            low=unpack_unsigned(packet[offset:offset+length],w,len(indices));offset+=length
            result[indices]=centered(low+s[indices],w)
        return result
