"""Reproducible synthetic tests; no downloaded models or network benchmark."""
from __future__ import annotations
import json, math, platform, time, zlib
from pathlib import Path
import numpy as np
from syndrome_codec import MaskedOutputCodec, DecodeError, pack_unsigned, centered
from bound_codec import PublicBoundCodec

SEED=20260913

def stats(values):
    return {'median_ms':float(np.median(values))*1000,'p95_ms':float(np.percentile(values,95))*1000,'samples':len(values)}

def run():
    rng=np.random.default_rng(SEED)
    result={'seed':SEED,'environment':{'python':platform.python_version(),'numpy':np.__version__,'platform':platform.platform()},
            'scope':'Synthetic integer vectors and products only. Fixed profile. No LLM quality, network, integrity, or production benchmark.'}
    correctness=[]
    for n,k,b,t in [(31,16,8,3),(127,24,8,4),(255,32,16,8),(1024,24,12,8),(4096,24,12,16)]:
        codec=MaskedOutputCodec(n,k,b,t); vectors=0;coordinates=0
        for case in range(120):
            y=rng.integers(-(1<<(b-1)),1<<(b-1),n,dtype=np.int64)
            count=case%(t+1);loc=rng.choice(n,count,replace=False)
            if case%4==0:
                vals=np.array([-(1<<(k-1)),(1<<(k-1))-1,-(1<<(b-1))-1,1<<(b-1)],dtype=np.int64)
                y[loc]=np.resize(vals,count)
            elif case%4==1:
                # Errors whose low lift bits vanish: exercise more than binary support.
                y[loc]=centered(y[loc]+(1<<min(k-1,b+2)),k)
            else:y[loc]=rng.integers(-(1<<(k-1)),1<<(k-1),count,dtype=np.int64)
            s=rng.integers(0,1<<k,n,dtype=np.int64)
            packet=codec.encode((y-s)&((1<<k)-1))
            actual=codec.decode(packet,s)
            assert np.array_equal(y,actual),(n,k,case)
            assert len(packet)==codec.packet_bytes
            vectors+=1;coordinates+=n
        correctness.append({'n':n,'ring_bits':k,'low_bits':b,'outlier_budget':t,
                            'exact_vectors':vectors,'exact_coordinates':coordinates,
                            'raw_bytes':(n*k+7)//8,'packet_bytes':codec.packet_bytes})
    result['within_budget_correctness']=correctness
    c=MaskedOutputCodec(4096,24,12,16)
    enc=[];dec=[];raw_sizes=[];zlib_sizes=[];exact=0
    for j in range(45):
        y=rng.integers(-2048,2048,c.n,dtype=np.int64)
        ix=rng.choice(c.n,c.t,replace=False)
        y[ix]=rng.choice(np.array([-7000000,5000000]),len(ix))
        s=rng.integers(0,1<<24,c.n,dtype=np.int64);z=(y-s)&((1<<24)-1)
        start=time.perf_counter();packet=c.encode(z);middle=time.perf_counter()
        got=c.decode(packet,s);end=time.perf_counter()
        assert np.array_equal(got,y);exact+=1
        if j>=5:enc.append(middle-start);dec.append(end-middle)
        raw=pack_unsigned(z,24);raw_sizes.append(len(raw));zlib_sizes.append(len(zlib.compress(raw,9)))
    result['main_profile']={'n':c.n,'ring_bits':24,'low_bits':12,'outlier_budget':16,
       'parity_rows':c.code.rows,'raw_bytes':raw_sizes[0],'packet_bytes':c.packet_bytes,
       'downlink_saving_fraction':1-c.packet_bytes/raw_sizes[0],
       'zlib_bytes_median':float(np.median(zlib_sizes)),
       'encode':stats(enc),'decode':stats(dec),'setup_parity_matrix_bytes':c.code.H.nbytes,
       'exact_vectors':exact,'timing_note':'Same-process CPython/NumPy implementation, five warmups, no network. Dense int64 parity matrix is not optimized.'}
    outside=[]
    for excess in [1,4,16,64]:
        rejected=wrong=correct=0
        for j in range(30):
            y=rng.integers(-2048,2048,c.n,dtype=np.int64)
            loc=rng.choice(c.n,c.t+excess,replace=False)
            y[loc]=rng.choice(np.array([-3000000,4000000]),len(loc))
            s=rng.integers(0,1<<24,c.n,dtype=np.int64)
            try:got=c.decode(c.encode((y-s)&((1<<24)-1)),s)
            except DecodeError:rejected+=1;continue
            if np.array_equal(got,y):correct+=1
            else:wrong+=1
        outside.append({'outlier_count':c.t+excess,'vectors':30,'rejected':rejected,'wrong_without_exception':wrong,'correct':correct})
    result['outside_budget_observed']=outside
    # Explicit ambiguity: two different sparse-domain candidates are unnecessary.
    # A >t-weight binary codeword has zero H syndrome. Gaussian elimination yields one.
    H=c.code.H.astype(np.uint8).copy();rows,cols=H.shape;pivots=[];rr=0
    for col in range(cols):
        selected=np.flatnonzero(H[rr:,col])
        if not len(selected):continue
        p=rr+int(selected[0]);H[[rr,p]]=H[[p,rr]]
        others=np.flatnonzero(H[:,col]);others=others[others!=rr]
        H[others]^=H[rr]
        pivots.append(col);rr+=1
        if rr==rows:break
    free=next(i for i in range(cols) if i not in set(pivots))
    cw=np.zeros(cols,dtype=np.int64);cw[free]=1
    for r,pivot in enumerate(pivots):cw[pivot]=int(H[r,free])
    assert not np.any((c.code.H@cw)&1)
    # A high-bit codeword gives exactly zero ring syndrome, and zero low bits.
    alternate=-(1<<23)*cw
    s=rng.integers(0,1<<24,c.n,dtype=np.int64)
    packet0=c.encode((-s)&((1<<24)-1))
    packet1=c.encode((alternate-s)&((1<<24)-1))
    assert packet0==packet1
    decoded=c.decode(packet1,s)
    assert np.array_equal(decoded,np.zeros(c.n,dtype=np.int64))
    assert not np.array_equal(decoded,alternate)
    result['explicit_out_of_domain_ambiguity']={'overflow_coordinates':int(cw.sum()),'budget':c.t,
        'identical_packets_for_distinct_outputs':True,'decoder_returns_wrong_vector_without_exception':True,
        'lesson':'The bounded-domain condition and independent integrity verification are mandatory. Decoder rejection is not a correctness certificate.'}
    # Non-adaptively chosen public b=12,t=16: show sensitivity to output tails.
    profiles=[]
    for name in ['normal_sigma_512','normal_sigma_768','student_t3_scale_256']:
        counts=[];successful=failed=0
        for j in range(35):
            if name=='normal_sigma_512':a=rng.normal(0,512,c.n)
            elif name=='normal_sigma_768':a=rng.normal(0,768,c.n)
            else:a=rng.standard_t(3,c.n)*256
            y=np.clip(np.rint(a),-(1<<23),(1<<23)-1).astype(np.int64)
            count=int(np.sum((y < -2048)|(y>=2048)));counts.append(count)
            s=rng.integers(0,1<<24,c.n,dtype=np.int64)
            try:got=c.decode(c.encode((y-s)&((1<<24)-1)),s)
            except DecodeError:failed+=1;continue
            if np.array_equal(got,y):successful+=1
            else:failed+=1
        profiles.append({'distribution':name,'vectors':35,'outliers_min':min(counts),'outliers_max':max(counts),
            'outliers_median':float(np.median(counts)),'exact':successful,'not_exact_or_rejected':failed})
    result['synthetic_distribution_sensitivity']=profiles
    # Actual exact integer products on independent synthetic matrix, not activations from an LLM.
    W=rng.integers(-7,8,size=(4096,128),dtype=np.int64)
    public_row_bounds=127*np.abs(W).sum(axis=1)
    safe_bits=np.array([int(v).bit_length()+1 for v in public_row_bounds])
    result['simple_public_bound_baseline']={'matrix_shape':[4096,128],
       'activation_abs_bound':127,'max_row_abs_sum':int(np.abs(W).sum(axis=1).max()),
       'bits_min':int(safe_bits.min()),'bits_max':int(safe_bits.max()),
       'per_coordinate_bound_payload_bytes':int((int(safe_bits.sum())+7)//8),
       'uniform_bound_payload_bytes':int((4096*int(safe_bits.max())+7)//8),
       'raw_24_bit_payload_bytes':12288,
       'note':'Guaranteed for every activation in the public range, without sparse-outlier assumptions. Must be a comparison baseline.'}
    products=[W@rng.integers(-127,128,128,dtype=np.int64) for _ in range(30)]
    safe_codec=PublicBoundCodec(safe_bits)
    for j,y in enumerate(products):
        s=np.full(4096,1234567+j,dtype=np.int64)
        packet=safe_codec.encode((y-s)&((1<<24)-1))
        assert np.array_equal(y,safe_codec.decode(packet,s))
    result['simple_public_bound_baseline'].update({'measured_grouped_payload_bytes':safe_codec.packet_bytes,'exact_products':len(products)})
    product_profiles=[]
    for b in [14,15]:
        prodcodec=MaskedOutputCodec(4096,24,b,16)
        counts=[];ok=failed=wrong=0
        for y in products:
            counts.append(int(np.sum((y<-(1<<(b-1)))|(y>=(1<<(b-1))))))
            s=rng.integers(0,1<<24,4096,dtype=np.int64)
            try:got=prodcodec.decode(prodcodec.encode((y-s)&((1<<24)-1)),s)
            except DecodeError:failed+=1;continue
            if np.array_equal(y,got):ok+=1
            else:wrong+=1
        product_profiles.append({'matrix_shape':[4096,128],'weights_range':[-7,7],
           'activation_range':[-127,127],'ring_bits':24,'low_bits':b,'outlier_budget':16,
           'products':len(products),'exact_products':ok,'rejected':failed,'wrong_without_exception':wrong,
           'outliers_min':min(counts),'outliers_max':max(counts),
           'raw_bytes':4096*3,'packet_bytes':prodcodec.packet_bytes,
           'saving_fraction':1-prodcodec.packet_bytes/(4096*3),
           'note':'Fixed profiles, identical synthetic products for both widths. Not a quantized pretrained model.'})
    result['synthetic_matrix_products']=product_profiles
    # A competing lossy construction, checked exhaustively; no claim about model quality.
    k=8;f=3;B=1<<f;outmod=1<<(k-f);checks=0;max_error=0
    for y in range(-112,113):
        actual=[]
        for s in range(1<<k):
            v=(y-s)&255
            transmitted=((v+B-1)//B)%outmod
            got=int(centered(np.array([(transmitted+s//B)%outmod]),k-f)[0])
            expected=math.ceil((y-(s%B))/B)
            assert got==expected
            actual.append(got);checks+=1;max_error=max(max_error,abs(got-y/B))
        assert np.mean(actual)==y/B
    result['masked_stochastic_requantization']={'exhaustive_cases':checks,'ring_bits':k,'dropped_bits':f,
       'max_output_unit_error':max_error,'unbiased_for_enumerated_masks':True,
       'disposition':'Not recommended for the exact protocol: changes arithmetic functionality and invalidates the unchanged exact-product verifier.'}
    # Architecture-only accounting from official Qwen config; all 24-bit widths assumed.
    stages=[('qkv',896,1152),('o',896,896),('gate_up',896,9728),('down',4864,896)]
    accounting=[]
    for name,n,m in stages:
        co=MaskedOutputCodec(m,24,12,16)
        accounting.append({'stage':name,'input_coefficients':n,'output_coefficients':m,
                           'upload_bytes':3*n,'raw_download_bytes':3*m,'coded_download_bytes':co.packet_bytes})
    upload=24*sum(s['upload_bytes'] for s in accounting)
    raw=24*sum(s['raw_download_bytes'] for s in accounting)
    coded=24*sum(s['coded_download_bytes'] for s in accounting)
    result['illustrative_qwen_body_budget']={'layers':24,'stages':accounting,'assumed_uniform_ring_bits':24,
       'fixed_low_bits':12,'fixed_budget_per_stage':16,'upload_bytes':upload,
       'raw_download_bytes':raw,'coded_download_bytes':coded,
       'baseline_online_payload_bytes':upload+raw,'coded_online_payload_bytes':upload+coded,
       'body_online_payload_saving_fraction':1-(upload+coded)/(upload+raw),
       'caveat':'Arithmetic projection, not measured Qwen traffic. Does not establish outlier budgets; excludes embeddings, head, setup, metadata, verifier setup, and transport overhead.'}
    return result

if __name__=='__main__':
    report=run()
    target=Path(__file__).with_name('codec_results.json')
    target.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
