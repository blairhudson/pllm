"""All-weight-remote toy autoregressive graph; NOT a pretrained LLM.

Includes tied embedding and output head, hidden matrices, local clipping,
private one-hot token lookup, and greedy next-token selection. Exact, but the
one-hot lookup has O(vocabulary) traffic and is not an efficient PIR scheme.
"""
from __future__ import annotations
import json,secrets,time
from pathlib import Path
import numpy as np
from weightless_setup import Preparation, Client, Inference, generate_key
from syndrome_codec import MaskedOutputCodec,pack_unsigned,unpack_unsigned
from compressed_execution import CodedInference

def run():
    rng=np.random.default_rng(71213)
    embedding=rng.integers(-3,4,size=(16,32),dtype=np.int64)
    weights={'embedding':embedding,'hidden_up':rng.integers(-3,4,(32,16),dtype=np.int64),
             'hidden_down':rng.integers(-3,4,(16,32),dtype=np.int64),'head':embedding.T}
    key=generate_key();batch=8;k=24
    servers={};clients={};preparers={};corrections={};codecs={};setup_rows=[]
    for name,W in weights.items():
        m,n=W.shape;seed=secrets.token_bytes(32)
        prep=Preparation(key,seed,n,m,batch,k,3)
        client=Client(seed,n,m,batch,k);server=Inference(W,key.public)
        codec=MaskedOutputCodec(m,k,12,1)
        start=time.perf_counter();request=prep.request();response=server.prepare(request)
        c=prep.finish(response);seconds=time.perf_counter()-start
        servers[name]=CodedInference(W,codec);clients[name]=client;preparers[name]=prep
        corrections[name]=[codec.encode(c[:,j]) for j in range(batch)];codecs[name]=codec
        setup_rows.append({'stage':name,'matrix_shape':[m,n],'encrypted_request_bytes':len(request),
           'encrypted_response_bytes':len(response),'correction_bytes':sum(map(len,corrections[name])),
           'raw_correction_bytes':len(pack_unsigned(c,k)),
           'setup_seconds':seconds,'weight_entries_in_client':0,'weight_entries_in_preparation':0})
    # None of the Client or Preparation objects contains or receives W.
    # Public key/shape/bounds and masks are their only stage-specific input.
    uplink=downlink=raw_downlink=products=0;tokens=[];token=5
    timings=[]
    for row in range(batch):
        x=np.zeros(32,dtype=np.int64);x[token]=1
        reference=x.copy()
        start=time.perf_counter()
        for name in ['embedding','hidden_up','hidden_down','head']:
            client=clients[name];server=servers[name];codec=codecs[name]
            u=(x-client.r[:,row])&((1<<k)-1)
            request=pack_unsigned(u,k);decoded=unpack_unsigned(request,k,len(u))
            response=server.online(decoded,corrections[name][row])
            x=codec.decode(response,client.s[:,row])
            expected=weights[name]@reference
            assert np.array_equal(x,expected)
            uplink+=len(request);downlink+=len(response);raw_downlink+=codec.n*3;products+=1
            reference=expected
            if name!='head':
                # Explicit toy model functionality, not a transformer approximation.
                x=np.clip(x,0,15);reference=np.clip(reference,0,15)
        token=int(np.argmax(x));assert token==int(np.argmax(reference));tokens.append(token)
        timings.append(time.perf_counter()-start)
    return {'description':'Synthetic four-stage autoregressive graph, tied embeddings/head, local clipped ReLU and greedy sampling; NOT an LLM.',
       'vocabulary':32,'hidden':16,'generated_tokens':tokens,'exact_stage_products':products,
       'setup':setup_rows,'setup_total_bytes':sum(r['encrypted_request_bytes']+r['encrypted_response_bytes']+r['correction_bytes'] for r in setup_rows),
       'online_upload_bytes':uplink,'online_download_bytes':downlink,'uncompressed_online_download_bytes':raw_downlink,
       'online_payload_saving_fraction':1-(uplink+downlink)/(uplink+raw_downlink),
       'median_online_step_ms':float(np.median(timings))*1000,
       'client_weight_entries':0,'preparation_weight_entries':0,
       'compressed_corrections_used_end_to_end':True,
       'limits':['Same process with role objects, not operating-system isolation.','Ciphertext/preprocessing implementation not audited or constant-time.',
                 'No malicious result verification. Oracle checks only in test driver.',
                 'One-hot input costs O(vocabulary) coefficients, so it is not an efficient full-size embedding protocol.',
                 'Model weights generated synthetically; outputs have no language-model quality meaning.']}

if __name__=='__main__':
    result=run();Path(__file__).with_name('toy_graph_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
