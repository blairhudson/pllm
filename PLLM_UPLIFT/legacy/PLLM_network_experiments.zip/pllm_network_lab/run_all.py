"""Run every experiment and replace the local result JSON files."""
from __future__ import annotations
import json,os,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')

def main()->None:
    steps=[('run_experiments.py','codec_results.json'),
           ('fast_codec.py','fast_codec_results.json'),
           ('compressed_execution.py','compressed_execution_results.json'),
           ('weightless_setup.py','weightless_results.json'),
           ('toy_weightless_graph.py','toy_graph_results.json')]
    for program,output in steps:
        print(f'Running {program}',flush=True)
        run=subprocess.run([sys.executable,str(ROOT/program)],cwd=ROOT,text=True,
                           capture_output=True,check=False)
        if run.returncode:
            sys.stderr.write(run.stdout+run.stderr)
            raise SystemExit(run.returncode)
        data=json.loads(run.stdout)
        (ROOT/output).write_text(json.dumps(data,indent=2)+'\n')
        print(f'Wrote {output}',flush=True)

if __name__=='__main__':main()
