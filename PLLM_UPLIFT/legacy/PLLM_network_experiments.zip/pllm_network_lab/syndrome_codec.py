"""Research prototype: lossless compression of additive masked ring outputs.

Given z=(y-s) mod 2**k, the encoder sees z, not y or s. The decoder
has s. It recovers y exactly when at most t coordinates lie outside the
b-bit signed interval. Fixed-length packets; no model weights, no fallback.
Not an authenticated codec; production needs an independent integrity check.
"""
from __future__ import annotations
import math
import numpy as np

class DecodeError(ValueError):
    pass

PRIMITIVES = {3:0xB,4:0x13,5:0x25,6:0x43,7:0x89,8:0x11D,
              9:0x211,10:0x409,11:0x805,12:0x1053,13:0x201B,
              14:0x4443,15:0x8003,16:0x1100B}

def centered(x: np.ndarray, bits: int) -> np.ndarray:
    return ((np.asarray(x, dtype=np.int64) + (1 << (bits-1))) & ((1<<bits)-1)) - (1 << (bits-1))

def pack_unsigned(x: np.ndarray, bits: int) -> bytes:
    a=np.asarray(x,dtype=np.uint64).ravel()
    if bits < 1 or bits > 32 or np.any(a >= (1 << bits)):
        raise ValueError('Invalid value or bit width')
    b=((a[:,None] >> np.arange(bits,dtype=np.uint64)) & 1).astype(np.uint8)
    return np.packbits(b.ravel(),bitorder='little').tobytes()

def unpack_unsigned(data: bytes, bits: int, count: int) -> np.ndarray:
    if len(data) != (bits*count+7)//8:
        raise DecodeError('Invalid field length')
    a=np.unpackbits(np.frombuffer(data,dtype=np.uint8),bitorder='little')
    if np.any(a[count*bits:]):
        raise DecodeError('Noncanonical padding')
    b=a[:count*bits].reshape(count,bits).astype(np.int64)
    return b @ (1 << np.arange(bits,dtype=np.int64))

class BinaryBCH:
    """Shortened primitive binary BCH syndrome decoder, correcting t bits."""
    def __init__(self,n:int,t:int):
        self.n=n;self.t=t; self.m=max(3,math.ceil(math.log2(n+1)))
        if self.m not in PRIMITIVES or t < 1 or 2*t >= n:
            raise ValueError('Unsupported code dimensions')
        self.order=(1<<self.m)-1
        self.exp=np.empty(2*self.order,dtype=np.int64)
        self.log=np.full(self.order+1,-1,dtype=np.int64)
        x=1
        for i in range(self.order):
            if self.log[x] != -1:
                raise ValueError('Polynomial is not primitive')
            self.exp[i]=x; self.log[x]=i
            x <<= 1
            if x & (1<<self.m): x ^= PRIMITIVES[self.m]
        if x != 1: raise ValueError('Invalid field')
        self.exp[self.order:]=self.exp[:self.order]
        points=np.arange(n,dtype=np.int64)
        rows=[]
        for j in range(1,2*t,2):
            v=self.exp[(points*j)%self.order]
            for bit in range(self.m): rows.append((v >> bit)&1)
        self.H=np.array(rows,dtype=np.int64)
        self.rows=t*self.m
        self.root_logs=(-points)%self.order
    def mul(self,a:int,b:int)->int:
        return 0 if a==0 or b==0 else int(self.exp[self.log[a]+self.log[b]])
    def div(self,a:int,b:int)->int:
        if not b: raise ZeroDivisionError
        return 0 if not a else int(self.exp[(int(self.log[a])-int(self.log[b]))%self.order])
    def decode(self,syndrome:np.ndarray)->np.ndarray:
        v=np.asarray(syndrome,dtype=np.int64)&1
        if not np.any(v): return np.empty(0,dtype=np.int64)
        S=[0]*(2*self.t+1)
        for j in range(1,2*self.t+1):
            if j&1:
                chunk=v[((j-1)//2)*self.m:((j+1)//2)*self.m]
                S[j]=sum(int(a)<<i for i,a in enumerate(chunk))
            else:S[j]=self.mul(S[j//2],S[j//2])
        seq=S[1:]
        C=[0]*(2*self.t+1); B=C.copy();C[0]=B[0]=1
        L=0; shift=1; prev=1
        for at in range(2*self.t):
            discrepancy=seq[at]
            for j in range(1,L+1): discrepancy ^= self.mul(C[j],seq[at-j])
            if not discrepancy: shift+=1;continue
            old=C.copy(); scale=self.div(discrepancy,prev)
            for j in range(2*self.t+1-shift):
                C[j+shift] ^= self.mul(scale,B[j])
            if 2*L <= at:
                L=at+1-L;B=old;prev=discrepancy;shift=1
            else:shift+=1
        if L > self.t: raise DecodeError('Too many BCH errors')
        vals=np.full(self.n,C[0],dtype=np.int64)
        for j in range(1,L+1):
            if C[j]:
                vals ^= self.exp[(self.log[C[j]]+j*self.root_logs)%self.order]
        positions=np.flatnonzero(vals==0)
        if len(positions)!=L or not np.array_equal(self.H[:,positions].sum(axis=1)&1,v):
            raise DecodeError('Inconsistent BCH syndrome')
        return positions

class MaskedOutputCodec:
    def __init__(self,n:int,k:int=24,b:int=12,t:int=16):
        if not (1 <= b < k <=32):raise ValueError('Require 1 <= b < k <=32')
        self.n=n;self.k=k;self.b=b;self.t=t
        self.q=1<<k;self.B=1<<b;self.d=k-b
        self.code=BinaryBCH(n,t)
        self.low_bytes=(n*b+7)//8
        self.high_bytes=(self.code.rows*self.d+7)//8
    @property
    def packet_bytes(self)->int:return self.low_bytes+self.high_bytes
    def encode(self,z:np.ndarray)->bytes:
        z=np.asarray(z,dtype=np.int64)
        if z.shape!=(self.n,) or np.any(z<0) or np.any(z>=self.q):
            raise ValueError('Bad masked vector')
        parity=(self.code.H@z)&(self.q-1)
        return pack_unsigned(z&(self.B-1),self.b)+pack_unsigned(parity>>self.b,self.d)
    def decode(self,packet:bytes,s:np.ndarray)->np.ndarray:
        if len(packet)!=self.packet_bytes:raise DecodeError('Bad packet length')
        s=np.asarray(s,dtype=np.int64)
        if s.shape!=(self.n,):raise ValueError('Bad mask shape')
        low=unpack_unsigned(packet[:self.low_bytes],self.b,self.n)
        high=unpack_unsigned(packet[self.low_bytes:],self.d,self.code.rows)
        y0=centered(low+s,self.b)
        parity=(high<<self.b)+((self.code.H@low)&(self.B-1))
        residual=(parity+self.code.H@s-self.code.H@y0)&(self.q-1)
        if np.any(residual&(self.B-1)):raise DecodeError('Invalid divisibility')
        syndrome=residual>>self.b
        h=np.zeros(self.n,dtype=np.int64)
        support=set()
        for bit in range(self.d):
            loc=self.code.decode(syndrome&1)
            support.update(loc.tolist())
            if len(support)>self.t:raise DecodeError('Too many overflow coordinates')
            h[loc] |= 1<<bit
            correction=self.code.H[:,loc].sum(axis=1)
            if np.any((syndrome-correction)&1):raise DecodeError('Invalid lift')
            # Signed division followed by reduction implements lifting over 2**d.
            syndrome=((syndrome-correction)//2)&((1<<(self.d-bit-1))-1)
        result=centered(y0+(h<<self.b),self.k)
        return result

if __name__=='__main__':
    rng=np.random.default_rng(1)
    for n in [31,127,1024,4096]:
        code=BinaryBCH(n,min(4,(n-1)//3))
        for z in range(20):
            loc=rng.choice(n,size=int(rng.integers(0,code.t+1)),replace=False)
            assert np.array_equal(np.sort(loc),code.decode(code.H[:,loc].sum(axis=1)&1))
        c=MaskedOutputCodec(n,24,12,code.t)
        for z in range(10):
            y=rng.integers(-2048,2048,size=n,dtype=np.int64)
            loc=rng.choice(n,size=code.t,replace=False)
            y[loc]=rng.integers(-(1<<23),1<<23,size=code.t)
            s=rng.integers(0,1<<24,size=n,dtype=np.int64)
            packet=c.encode((y-s)&((1<<24)-1))
            got=c.decode(packet,s)
            assert np.array_equal(y,got),(n,z,y[loc],got[loc])
        print('passed',n,c.packet_bytes)
