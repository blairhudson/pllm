"""Optional Numba implementation of the same codec, not a different protocol.
Fixed wire format agrees byte-for-byte with syndrome_codec.py. No constant-time
claim; output-dependent client execution needs isolation or traffic scheduling.
"""
from __future__ import annotations
import numpy as np
from numba import njit
from syndrome_codec import MaskedOutputCodec, DecodeError

@njit(cache=True)
def _mul(a,b,exp,log):
    if a==0 or b==0:return 0
    return exp[log[a]+log[b]]

@njit(cache=True)
def _bch(v,t,m,exp,log,H):
    order=(1<<m)-1;n=H.shape[1]
    S=np.zeros(2*t+1,dtype=np.int64)
    for j in range(1,2*t+1):
        if j&1:
            for bit in range(m):S[j]|=(v[((j-1)//2)*m+bit]&1)<<bit
        else:S[j]=_mul(S[j//2],S[j//2],exp,log)
    if np.all(S==0):return np.empty(0,dtype=np.int64)
    C=np.zeros(2*t+1,dtype=np.int64);B=C.copy();C[0]=1;B[0]=1
    L=0;shift=1;prev=1
    for at in range(2*t):
        discrepancy=S[at+1]
        for j in range(1,L+1):discrepancy^=_mul(C[j],S[at-j+1],exp,log)
        if discrepancy==0:shift+=1;continue
        old=C.copy();scale=exp[(log[discrepancy]-log[prev])%order]
        for j in range(2*t+1-shift):C[j+shift]^=_mul(scale,B[j],exp,log)
        if 2*L<=at:L=at+1-L;B=old;prev=discrepancy;shift=1
        else:shift+=1
    if L>t:raise ValueError('Too many BCH errors')
    loc=np.empty(t,dtype=np.int64);count=0
    for pos in range(n):
        value=C[0]
        for j in range(1,L+1):
            if C[j]:value^=exp[(log[C[j]]-j*pos)%order]
        if value==0:
            if count==t:raise ValueError('Too many roots')
            loc[count]=pos;count+=1
    if count!=L:raise ValueError('Inconsistent roots')
    for row in range(H.shape[0]):
        parity=0
        for j in range(count):parity^=H[row,loc[j]]
        if parity!=(v[row]&1):raise ValueError('Inconsistent syndrome')
    return loc[:count]

@njit(cache=True)
def _pack(values,bits):
    out=np.zeros((len(values)*bits+7)//8,dtype=np.uint8)
    acc=0;available=0;at=0
    for value in values:
        acc |= value<<available;available+=bits
        while available>=8:
            out[at]=acc&255;at+=1;acc>>=8;available-=8
    if available:out[at]=acc
    return out

@njit(cache=True)
def _unpack(data,bits,count):
    out=np.empty(count,dtype=np.int64);acc=0;available=0;at=0;mask=(1<<bits)-1
    for j in range(count):
        while available<bits:
            acc |= int(data[at])<<available;at+=1;available+=8
        out[j]=acc&mask;acc>>=bits;available-=bits
    if acc!=0:raise ValueError('Noncanonical padding')
    return out

@njit(cache=True)
def _encode(z,H,k,b):
    qmask=(1<<k)-1
    lows=_pack(z&((1<<b)-1),b)
    values=np.zeros(H.shape[0],dtype=np.int64)
    for row in range(H.shape[0]):
        total=0
        for col in range(H.shape[1]):total+=int(H[row,col])*z[col]
        values[row]=(total&qmask)>>b
    highs=_pack(values,k-b)
    return np.concatenate((lows,highs))

@njit(cache=True)
def _decode(packet,s,H,k,b,t,m,exp,log,low_bytes):
    n=len(s);d=k-b;B=1<<b
    low=_unpack(packet[:low_bytes],b,n)
    high=_unpack(packet[low_bytes:],d,H.shape[0])
    y0=((low+s+B//2)&(B-1))-B//2
    # s + low - y0 is an exact multiple of B.
    carry=(s+low-y0)>>b
    syndrome=np.empty(H.shape[0],dtype=np.int64)
    for row in range(H.shape[0]):
        low_sum=0;carry_sum=0
        for col in range(n):
            low_sum+=int(H[row,col])*low[col]
            carry_sum+=int(H[row,col])*carry[col]
        syndrome[row]=(high[row]+carry_sum-(low_sum>>b))&((1<<d)-1)
    h=np.zeros(n,dtype=np.int64);seen=np.zeros(n,dtype=np.uint8);seen_count=0
    for bit in range(d):
        loc=_bch(syndrome,t,m,exp,log,H)
        for pos in loc:
            if seen[pos]==0:seen[pos]=1;seen_count+=1
            h[pos]|=1<<bit
        if seen_count>t:raise ValueError('Too many overflow coordinates')
        for row in range(H.shape[0]):
            correction=0
            for pos in loc:correction+=H[row,pos]
            syndrome[row]=((syndrome[row]-correction)//2)&((1<<(d-bit-1))-1)
    return ((y0+(h<<b)+(1<<(k-1)))&((1<<k)-1))-(1<<(k-1))

class FastMaskedOutputCodec(MaskedOutputCodec):
    def __init__(self,n:int,k:int=24,b:int=12,t:int=16):
        super().__init__(n,k,b,t)
        self.H8=self.code.H.astype(np.uint8)
        # Generic parity matrix, not model data. Avoid retaining int64 duplicate.
        self.code.H=self.H8
    def encode(self,z:np.ndarray)->bytes:
        z=np.asarray(z,dtype=np.int64)
        if z.shape!=(self.n,) or np.any(z<0) or np.any(z>=self.q):raise ValueError('Invalid vector')
        return _encode(z,self.H8,self.k,self.b).tobytes()
    def decode(self,packet:bytes,s:np.ndarray)->np.ndarray:
        if len(packet)!=self.packet_bytes:raise DecodeError('Bad packet length')
        s=np.asarray(s,dtype=np.int64)
        if s.shape!=(self.n,) or np.any(s<0) or np.any(s>=self.q):raise ValueError('Invalid mask')
        try:return _decode(np.frombuffer(packet,dtype=np.uint8),s,self.H8,self.k,self.b,self.t,
                            self.code.m,self.code.exp,self.code.log,self.low_bytes)
        except ValueError as error:raise DecodeError(str(error)) from error

if __name__=='__main__':
    import json,time
    from pathlib import Path
    rng=np.random.default_rng(20260913)
    exact=0;profiles=[]
    for n,k,b,t in [(31,16,8,3),(255,32,16,8),(4096,24,12,16)]:
        slow=MaskedOutputCodec(n,k,b,t);fast=FastMaskedOutputCodec(n,k,b,t)
        enc=[];dec=[]
        for case in range(110):
            y=rng.integers(-(1<<(b-1)),1<<(b-1),n,dtype=np.int64)
            # Two all-odd high parts deliberately exercise every lift plane.
            loc=rng.choice(n,t,replace=False);y[loc]=rng.integers(-(1<<(k-1)),1<<(k-1),t)
            s=rng.integers(0,1<<k,n,dtype=np.int64);z=(y-s)&((1<<k)-1)
            start=time.perf_counter();packet=fast.encode(z);mid=time.perf_counter()
            got=fast.decode(packet,s);end=time.perf_counter()
            assert packet==slow.encode(z)
            assert np.array_equal(y,got)
            if case<10:assert np.array_equal(got,slow.decode(packet,s))
            if case>=10:enc.append((mid-start)*1000);dec.append((end-mid)*1000)
            exact+=1
        profiles.append({'n':n,'k':k,'b':b,'t':t,'raw_bytes':n*k//8,'packet_bytes':fast.packet_bytes,
           'encode_median_ms':float(np.median(enc)),'decode_median_ms':float(np.median(dec)),
           'encode_p95_ms':float(np.percentile(enc,95)),'decode_p95_ms':float(np.percentile(dec,95)),
           'timed_samples':len(enc),'generic_parity_matrix_bytes':fast.H8.nbytes})
    data={'implementation':'Numba 0.65.1; first ten cases per profile excluded, including compilation.',
          'exact_cases':exact,'byte_compatible_cases':exact,'profiles':profiles,
          'caveat':'Same-process synthetic microbenchmark; client branches on recovered data; no constant-time or end-to-end speedup claim.'}
    Path(__file__).with_name('fast_codec_results.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(data,indent=2))
