"""Executable reference for model-free Preparation using packed Paillier.

2048-bit modulus; standard-library big integers and cryptography RSA prime
sampling. Research code, not constant-time or production-audited cryptography.
All model weights exist only in Inference; tests keep a separate oracle copy.
Balanced radix packing batches INDEPENDENT preprocessing records.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import shake_256
import math,secrets,time
import numpy as np
from cryptography.hazmat.primitives.asymmetric import rsa
from syndrome_codec import centered

@dataclass(frozen=True)
class PublicKey:
    n:int
    @property
    def n2(self):return self.n*self.n
    @property
    def ciphertext_bytes(self):return (self.n2.bit_length()+7)//8
    def encrypt(self,m:int)->int:
        while True:
            r=secrets.randbelow(self.n-1)+1
            if math.gcd(r,self.n)==1:break
        return ((1+self.n*(m%self.n))*pow(r,self.n,self.n2))%self.n2
    def serialize(self,values:list[int])->bytes:
        return b''.join(x.to_bytes(self.ciphertext_bytes,'big') for x in values)
    def deserialize(self,data:bytes,count:int)->list[int]:
        size=self.ciphertext_bytes
        if len(data)!=size*count:raise ValueError('Bad ciphertext length')
        vals=[int.from_bytes(data[i*size:(i+1)*size],'big') for i in range(count)]
        if any(x<=0 or x>=self.n2 or math.gcd(x,self.n)!=1 for x in vals):
            raise ValueError('Invalid ciphertext')
        return vals

@dataclass(frozen=True)
class SecretKey:
    public:PublicKey
    lam:int
    mu:int
    def decrypt(self,c:int)->int:
        n=self.public.n
        z=((pow(c,self.lam,n*n)-1)//n)*self.mu%n
        return z-n if z>n//2 else z

def generate_key(bits:int=2048)->SecretKey:
    if bits<2048:raise ValueError('This experiment requires >=2048 bits')
    while True:
        numbers=rsa.generate_private_key(public_exponent=65537,key_size=bits).private_numbers()
        n=numbers.p*numbers.q; lam=math.lcm(numbers.p-1,numbers.q-1)
        if math.gcd(n,lam)==1:return SecretKey(PublicKey(n),lam,pow(lam,-1,n))

def masks(seed:bytes,n:int,m:int,batch:int,k:int)->tuple[np.ndarray,np.ndarray]:
    if len(seed)!=32:raise ValueError('Require a 32-byte seed')
    context=f'pllm-network-lab-v1|{n}|{m}|{batch}|{k}|'.encode()
    def one(label:bytes,count:int):
        raw=shake_256(context+label+seed).digest(4*count)
        return np.frombuffer(raw,dtype='<u4').astype(np.int64)&((1<<k)-1)
    return one(b'r|',n*batch).reshape(n,batch),one(b's|',m*batch).reshape(m,batch)

def pack_balanced(values:np.ndarray,slot_bits:int)->int:
    result=0
    for x in reversed(values.tolist()):result=(result<<slot_bits)+int(x)
    return result

def unpack_balanced(value:int,slot_bits:int,count:int)->np.ndarray:
    base=1<<slot_bits;out=[]
    for _ in range(count):
        digit=((value+base//2)%base)-base//2
        out.append(digit);value=(value-digit)//base
    if value:raise ValueError('Packing overflow or malformed response')
    return np.array(out,dtype=np.int64)

class Preparation:
    def __init__(self,key:SecretKey,seed:bytes,n:int,m:int,batch:int,k:int,weight_abs_bound:int):
        self.key=key;self.n=n;self.m=m;self.batch=batch;self.k=k
        # Public scalar bound, NOT the weights. Ensures no signed radix carries.
        self.slot_bits=(n*weight_abs_bound*(1<<(k-1))*2+1).bit_length()
        if self.slot_bits*batch > key.public.n.bit_length()-2:
            raise ValueError('Too many records for this Paillier packing')
        self.r,self.s=masks(seed,n,m,batch,k)
    def request(self)->bytes:
        vals=[self.key.public.encrypt(pack_balanced(row,self.slot_bits))
              for row in centered(self.r,self.k)]
        return self.key.public.serialize(vals)
    def finish(self,response:bytes)->np.ndarray:
        vals=self.key.public.deserialize(response,self.m)
        wr=np.array([unpack_balanced(self.key.decrypt(c),self.slot_bits,self.batch) for c in vals])
        return (wr-self.s)&((1<<self.k)-1)

class Inference:
    def __init__(self,W:np.ndarray,key:PublicKey):
        self.W=np.asarray(W,dtype=np.int64);self.key=key
    def prepare(self,request:bytes)->bytes:
        encrypted=self.key.deserialize(request,self.W.shape[1]);out=[]
        modulus=self.key.n2
        for row in self.W:
            value=1
            for c,weight in zip(encrypted,row):
                if weight:value=value*pow(c,int(weight),modulus)%modulus
            out.append(value)
        return self.key.serialize(out)
    def online(self,u:np.ndarray,corrections:np.ndarray,k:int)->np.ndarray:
        return (self.W@u+corrections)&((1<<k)-1)

class Client:
    def __init__(self,seed:bytes,n:int,m:int,batch:int,k:int):
        self.r,self.s=masks(seed,n,m,batch,k);self.k=k
    def request(self,x:np.ndarray)->np.ndarray:return (x-self.r)&((1<<self.k)-1)
    def recover(self,v:np.ndarray)->np.ndarray:return centered(v+self.s,self.k)

def run_trials()->dict:
    rng=np.random.default_rng(90210);W=rng.integers(-7,8,size=(16,32),dtype=np.int64)
    t=time.perf_counter();key=generate_key();key_seconds=time.perf_counter()-t
    rows=[]
    for batch in [1,8,32,60]:
        seed=secrets.token_bytes(32);prep=Preparation(key,seed,32,16,batch,24,7)
        client=Client(seed,32,16,batch,24);server=Inference(W,key.public)
        t=time.perf_counter();request=prep.request();t1=time.perf_counter()
        response=server.prepare(request);t2=time.perf_counter()
        c=prep.finish(response);t3=time.perf_counter()
        x=rng.integers(-127,128,size=(32,batch),dtype=np.int64)
        got=client.recover(server.online(client.request(x),c,24))
        assert np.array_equal(got,W@x)
        assert np.array_equal(c,(W@centered(prep.r,24)-prep.s)&((1<<24)-1))
        raw_correction_bytes=16*batch*3
        rows.append(dict(batch=batch,exact_products=batch,output_coefficients=16*batch,
            slot_bits=prep.slot_bits,encrypted_request_bytes=len(request),
            encrypted_response_bytes=len(response),correction_push_bytes=raw_correction_bytes,
            total_preparation_bytes=len(request)+len(response)+raw_correction_bytes,
            preparation_bytes_per_record=(len(request)+len(response)+raw_correction_bytes)/batch,
            encrypt_seconds=t1-t,server_seconds=t2-t1,decrypt_seconds=t3-t2,
            total_seconds=t3-t,seconds_per_record=(t3-t)/batch,
            client_weight_entries=0,preparation_weight_entries=0))
    return dict(primitive='Paillier',modulus_bits=key.public.n.bit_length(),
                ciphertext_bytes=key.public.ciphertext_bytes,keygen_seconds=key_seconds,
                matrix_shape=[16,32],ring_bits=24,
                caveat='Research implementation; one process with separated role objects; no protocol isolation or malicious-security claim.',
                rows=rows)

if __name__=='__main__':
    import json
    print(json.dumps(run_trials(),indent=2))
