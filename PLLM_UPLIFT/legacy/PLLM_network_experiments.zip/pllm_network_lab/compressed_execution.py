"""Compute directly from compressed corrections; no correction decompression.

The wire code represents (z mod B, H*z mod q), suppressing redundant low
syndrome bits. This map is additive across its two rings. The provider can
therefore add encoded corrections to a low-bit product and H*W product.
"""
from __future__ import annotations
import json,time
from pathlib import Path
import numpy as np
from syndrome_codec import MaskedOutputCodec, pack_unsigned, unpack_unsigned, centered

class CodedInference:
    def __init__(self,W:np.ndarray,codec:MaskedOutputCodec):
        self.W=np.asarray(W,dtype=np.int64);self.codec=codec
        if self.W.shape[0]!=codec.n:raise ValueError('Wrong output dimensions')
        self.W_low=self.W&(codec.B-1)
        self.HW=(codec.code.H@self.W)&(codec.q-1)
    def online(self,u:np.ndarray,compressed_correction:bytes)->bytes:
        c=self.codec
        if len(compressed_correction)!=c.packet_bytes:raise ValueError('Bad correction length')
        low_c=unpack_unsigned(compressed_correction[:c.low_bytes],c.b,c.n)
        high_c=unpack_unsigned(compressed_correction[c.low_bytes:],c.d,c.code.rows)
        Hc=(high_c<<c.b)+((c.code.H@low_c)&(c.B-1))
        low_y=(self.W_low@(u&(c.B-1))+low_c)&(c.B-1)
        syndrome=(self.HW@u+Hc)&(c.q-1)
        return pack_unsigned(low_y,c.b)+pack_unsigned(syndrome>>c.b,c.d)

def run():
    rng=np.random.default_rng(8117);profiles=[]
    for m,n,k,b,t in [(127,32,16,12,4),(1024,128,24,16,8),(4096,128,24,15,16)]:
        W=rng.integers(-7,8,(m,n),dtype=np.int64);c=MaskedOutputCodec(m,k,b,t)
        start=time.perf_counter();provider=CodedInference(W,c);setup=time.perf_counter()-start
        exact=0;eligible=0;timings=[]
        for _ in range(40):
            x=rng.integers(-7,8,n,dtype=np.int64);y=W@x
            assert np.sum((y<-(1<<(b-1)))|(y>=(1<<(b-1))))<=t
            eligible+=1
            r=rng.integers(0,1<<k,n,dtype=np.int64)
            s=rng.integers(0,1<<k,m,dtype=np.int64)
            correction=(W@r-s)&((1<<k)-1)
            packed_c=c.encode(correction)
            u=(x-r)&((1<<k)-1)
            start=time.perf_counter();packet=provider.online(u,packed_c);timings.append(time.perf_counter()-start)
            reference_packet=c.encode((W@u+correction)&((1<<k)-1))
            assert packet==reference_packet
            recovered=c.decode(packet,s);assert np.array_equal(recovered,y);exact+=1
        raw_c=m*k//8;raw_upload=n*k//8
        profiles.append({'matrix_shape':[m,n],'k':k,'b':b,'t':t,'exact_products':exact,
           'byte_identical_response_packets':exact,'uncoded_correction_bytes':raw_c,
           'coded_correction_bytes':c.packet_bytes,'uncoded_response_bytes':raw_c,
           'coded_response_bytes':c.packet_bytes,'upload_bytes':raw_upload,
           'baseline_correction_plus_online_bytes':2*raw_c+raw_upload,
           'coded_correction_plus_online_bytes':2*c.packet_bytes+raw_upload,
           'provider_model_summary_bytes':provider.HW.nbytes,
           'provider_setup_seconds':setup,'median_provider_online_ms':float(np.median(timings))*1000,
           'warning':'No HE setup traffic included here. Extra server summary and arithmetic, not a measured compute speedup.'})
    # Mask-side prediction with the same fixed encoder: only client side information changes.
    m,n=4096,128;W=rng.integers(-7,8,(m,n),dtype=np.int64)
    codec=MaskedOutputCodec(m,24,10,16)
    x=rng.integers(-100,101,n,dtype=np.int64);previous_y=W@x
    predicted_exact=0;absolute_eligible=0;delta_outlier_counts=[]
    for _ in range(40):
        x=np.clip(x+rng.integers(-2,3,n,dtype=np.int64),-127,127)
        y=W@x;s=rng.integers(0,1<<24,m,dtype=np.int64)
        residual=y-previous_y
        delta_outlier_counts.append(int(np.sum((residual< -512)|(residual>=512))))
        absolute_eligible+=int(np.sum((y < -512)|(y>=512))<=16)
        # Server receives neither predictor nor residual.
        packet=codec.encode((y-s)&((1<<24)-1))
        decoded_residual=codec.decode(packet,(s-previous_y)&((1<<24)-1))
        got=centered(decoded_residual+previous_y,24)
        assert np.array_equal(got,y);predicted_exact+=1;previous_y=y
    return {'compressed_execution_profiles':profiles,'prediction':{
       'description':'Synthetic input random walk, same fixed matrix; predictor is previous output, not model weights.',
       'matrix_shape':[m,n],'ring_bits':24,'low_bits':10,'outlier_budget':16,
       'exact_steps':predicted_exact,'steps_whose_absolute_output_met_same_budget':absolute_eligible,
       'delta_outliers_max':max(delta_outlier_counts),'raw_response_bytes':m*3,'coded_response_bytes':codec.packet_bytes,
       'saving_fraction':1-codec.packet_bytes/(m*3),'extra_client_state_int64_bytes':previous_y.nbytes,
       'caveat':'Constructed temporal correlation; no evidence that consecutive real transformer activations have this property.'}}

if __name__=='__main__':
    result=run();Path(__file__).with_name('compressed_execution_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
