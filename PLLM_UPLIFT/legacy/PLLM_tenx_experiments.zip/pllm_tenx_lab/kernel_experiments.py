"""Exact arithmetic microbenchmarks; not full-model/cryptographic execution."""
import ctypes,json,time,statistics,subprocess,platform
import numpy as np
from threadpoolctl import threadpool_limits


def main():
    from pathlib import Path
    flags = Path('/proc/cpuinfo').read_text().lower() if Path('/proc/cpuinfo').exists() else ''
    if platform.machine() != 'x86_64' or not any(f in flags for f in ('avx512_vnni', 'avx512vnni')):
        raise SystemExit('Kernel tests require Linux x86-64 with AVX-512 VNNI; use the Python experiments on other CPUs.')
    subprocess.run(['g++','-O3','-march=native','-shared','-fPIC','lut_kernels.cpp','-o','lut_kernels.so'],check=True)
    lib=ctypes.CDLL('./lut_kernels.so');ptr=ctypes.c_void_p
    lib.direct.argtypes=[ptr,ptr,ptr]+[ctypes.c_int]*3
    lib.four_russians.argtypes=[ptr,ptr,ptr]+[ctypes.c_int]*4
    rng=np.random.default_rng(98);lookup=[];coords=0
    for m,n in [(256,1024),(512,2048),(1024,4096)]:
        k=36;w=rng.integers(-7,8,size=(m,n),dtype=np.int8);x=np.vstack([rng.integers(0,p,size=(18,n),dtype=np.uint8) for p in (251,241)])
        want=w.astype(np.int64)@x.T.astype(np.int64);ps=np.array([251]*18+[241]*18);want%=ps
        y=np.empty((m,k),dtype=np.int32);direct=lambda:lib.direct(w.ctypes.data,x.ctypes.data,y.ctypes.data,m,n,k)
        direct();assert np.array_equal(y,want);coords+=m*k
        funcs={'vnni':direct};meta={}
        for g in [4,8,10]:
            nb=(n+g-1)//g;pad=np.zeros((m,nb*g),dtype=np.uint8);pad[:,:n]=w.view(np.uint8)&15
            digits=pad.reshape(m,nb,g);pat=np.zeros((m,nb,4),dtype=np.uint16)
            for b in range(4):pat[:,:,b]=np.sum(((digits>>b)&1).astype(np.uint16)*(1<<np.arange(g,dtype=np.uint16)),axis=2)
            pat=np.ascontiguousarray(pat)
            def f(pat=pat,g=g):lib.four_russians(pat.ctypes.data,x.ctypes.data,y.ctypes.data,m,n,k,g)
            funcs[f'lut_g{g}']=f;f();assert np.array_equal(y,want);coords+=m*k
            meta[f'lut_g{g}']={'temporary_table_bytes':nb*(1<<g)*k*2,'stored_pattern_bytes':pat.nbytes,'packed_pattern_information_bytes':m*nb*4*g//8}
        timings={name:[] for name in funcs}
        for _ in range(3):
            for f in funcs.values():f()
        for _ in range(11):
            for name in rng.permutation(list(funcs)):
                st=time.perf_counter();funcs[name]();timings[name].append(time.perf_counter()-st)
        meds={k:statistics.median(v) for k,v in timings.items()}
        lookup.append({'m':m,'n':n,'median_seconds':meds,'samples':timings,'metadata':meta})
        print('lookup',m,n,meds,flush=True)
    wide=[]
    with threadpool_limits(limits=4):
        for n in [512,1024,2048]:
            w=rng.integers(-7,8,size=(n,n),dtype=np.int64);w32=w.astype(np.float32);w64=w.astype(np.float64)
            a=rng.integers(0,251,size=(n,36),dtype=np.int64);a[:,18:]%=241;a32=a.astype(np.float32)
            b=rng.integers(0,2**31-1,size=(n,6),dtype=np.int64);b64=b.astype(np.float64)
            funcs={'two_small_fields':lambda:np.remainder(w32@a32,np.array([251]*18+[241]*18,dtype=np.float32)),
                   'one_mersenne31_field':lambda:np.remainder(w64@b64,float(2**31-1))}
            # Same bounded integer semantics are supported, but encoded labels
            # differ by representation. Verify raw matrix arithmetic independently.
            wanta=w@a;wanta%=np.array([251]*18+[241]*18)
            wantb=w@b;wantb%=2**31-1
            assert np.array_equal(funcs['two_small_fields'](),wanta)
            assert np.array_equal(funcs['one_mersenne31_field'](),wantb);coords+=n*42
            for _ in range(3):
                for f in funcs.values():f()
            ts={z:[] for z in funcs}
            for _ in range(15):
                for name in rng.permutation(list(funcs)):
                    st=time.perf_counter();funcs[name]();ts[name].append(time.perf_counter()-st)
            meds={name:statistics.median(v) for name,v in ts.items()}
            wide.append({'n':n,'median_seconds':meds,'samples':ts,'small_to_wide_speedup':meds['two_small_fields']/meds['one_mersenne31_field'],
                         'small_weight_bytes':w32.nbytes,'wide_weight_bytes':w64.nbytes,'small_label_bytes':36,'wide_label_bytes':24})
            print('wide',n,meds,flush=True)
    with open('kernel_results.json','w') as f:json.dump({'lookup':lookup,'wider_field':wide,'exact_output_coordinates':coords,'platform':platform.platform(),
        'notes':['Four-Russians measured construction plus online use of temporary tables; static public weight pattern compilation excluded.',
                 'Lookup baseline is an AVX-512 VNNI int8 dot kernel, not Python loops.',
                 'Mersenne comparison is four-thread CPU FP64 vs FP32 BLAS, exact under fixture integer bounds, includes modular reduction.',
                 'No GPU/native-LLM or full gate conversions benchmark; no model-quality conclusion.']},f,indent=2)
if __name__=='__main__':main()
