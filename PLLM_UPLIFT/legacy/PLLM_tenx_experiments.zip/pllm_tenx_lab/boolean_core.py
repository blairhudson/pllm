"""Small XOR/AND compiler and SHA-256 half-gates reference.
Research only: no constant-time/production security claim. Half-gate equations
follow Zahur-Rosulek-Evans. SHA-256 is used as a domain-separated RO heuristic.
"""
from __future__ import annotations
import hashlib,os
import numpy as np

class Circuit:
    def __init__(self):
        self.nodes=[('const',0),('const',1)];self.inputs=[];self.memo={};self.outputs=[]
    def inp(self):
        i=len(self.nodes);self.nodes.append(('input',len(self.inputs)));self.inputs.append(i);return i
    def inv(self,a):
        if a<2:return 1-a
        n=self.nodes[a]
        if n[0]=='not':return n[1]
        return self._node(('not',a))
    def _node(self,key):
        if key not in self.memo:self.memo[key]=len(self.nodes);self.nodes.append(key)
        return self.memo[key]
    def xor(self,a,b):
        if a==b:return 0
        if a==0:return b
        if b==0:return a
        if a==1:return self.inv(b)
        if b==1:return self.inv(a)
        return self._node(('xor',*sorted((a,b))))
    def land(self,a,b):
        if a==0 or b==0:return 0
        if a==1:return b
        if b==1 or a==b:return a
        if self.nodes[a]==('not',b) or self.nodes[b]==('not',a):return 0
        return self._node(('and',*sorted((a,b))))
    def const(self,x,n):return [(x>>i)&1 for i in range(n)]
    def add(self,a,b,n,carry=0):
        aa=a+[0]*max(0,n-len(a));bb=b+[0]*max(0,n-len(b));out=[]
        for i in range(n):
            t=self.xor(aa[i],bb[i]);out.append(self.xor(t,carry))
            carry=self.xor(aa[i],self.land(t,self.xor(aa[i],carry)))
        return out,carry
    def subconst(self,a,k,n):return self.add(a,self.const((1<<n)-k,n),n)
    def mux(self,sel,a,b):return [self.xor(y,self.land(sel,self.xor(x,y))) for x,y in zip(a,b,strict=True)]
    def subtract(self,a,b,n):return self.add(a,[self.inv(x) for x in b]+[1]*(n-len(b)),n,1)[0]
    def evaluate(self,inputs):
        values=[False,True]
        for node in self.nodes[2:]:
            op=node[0]
            if op=='input':z=inputs[node[1]]
            elif op=='not':z=np.logical_not(values[node[1]])
            elif op=='xor':z=np.logical_xor(values[node[1]],values[node[2]])
            else:z=np.logical_and(values[node[1]],values[node[2]])
            values.append(z)
        return [values[i] for i in self.outputs]
    @property
    def ands(self):return sum(x[0]=='and' for x in self.nodes)


def crt_circuit():
    c=Circuit();a=[c.inp() for _ in range(8)];ta=[c.inp() for _ in range(8)];tb=[c.inp() for _ in range(8)]
    s,_=c.add(ta,tb,9);d,ge=c.subconst(s,241,9);t=c.mux(ge,d,s)[:8]
    # 251*t + a = 256*t - 4*t - t + a in 16-bit positional form.
    v=c.subtract([0]*8+t,[0]*2+t,16)
    v=c.subtract(v,t,16);v,_=c.add(v,a,16)
    _,negative=c.subconst(v,30246,16)
    correction=[negative if bit else 0 for bit in c.const(65536-60491,16)]
    v,_=c.add(v,correction,16);c.outputs=v
    return c


def H(label:int,context:bytes,gate:int,half:int)->int:
    return int.from_bytes(hashlib.sha256(b'pllm-half-v1'+context+gate.to_bytes(8,'little')+bytes([half])+label.to_bytes(16,'little')).digest()[:16],'little')

class Garbled:
    def __init__(self,c:Circuit):
        self.c=c;self.context=os.urandom(16);self.delta=int.from_bytes(os.urandom(16),'little')|1
        self.zero=[0,self.delta];self.tables={}
        for i,n in enumerate(c.nodes[2:],2):
            if n[0]=='input':z=int.from_bytes(os.urandom(16),'little')
            elif n[0]=='not':z=self.zero[n[1]]^self.delta
            elif n[0]=='xor':z=self.zero[n[1]]^self.zero[n[2]]
            else:
                a,b=self.zero[n[1]],self.zero[n[2]];pa,pb=a&1,b&1
                ha0=H(a,self.context,i,0);ha1=H(a^self.delta,self.context,i,0)
                hb0=H(b,self.context,i,1);hb1=H(b^self.delta,self.context,i,1)
                tg=ha0^ha1^(self.delta if pb else 0);te=hb0^hb1^a
                z=ha0^(tg if pa else 0)^hb0^((te^a) if pb else 0)
                self.tables[i]=(tg,te)
            self.zero.append(z)
    def input_labels(self,bits):return [self.zero[i]^(self.delta if int(v) else 0) for i,v in zip(self.c.inputs,bits,strict=True)]
    def evaluate(self,labels):
        vals=[0,0]
        for i,n in enumerate(self.c.nodes[2:],2):
            if n[0]=='input':z=labels[n[1]]
            elif n[0]=='not':z=vals[n[1]]
            elif n[0]=='xor':z=vals[n[1]]^vals[n[2]]
            else:
                a,b=vals[n[1]],vals[n[2]];tg,te=self.tables[i]
                z=H(a,self.context,i,0)^(tg if a&1 else 0)^H(b,self.context,i,1)^((te^a) if b&1 else 0)
            vals.append(z)
        return [vals[i] for i in self.c.outputs]
    def decode(self,labels):
        out=[]
        for i,l in zip(self.c.outputs,labels,strict=True):
            if l==self.zero[i]:out.append(0)
            elif l==self.zero[i]^self.delta:out.append(1)
            else:raise ValueError('invalid output label')
        return out
    def serialize(self):
        return self.context+b''.join(x.to_bytes(16,'little') for i in sorted(self.tables) for x in self.tables[i])


def test_crt():
    c=crt_circuit();t=np.arange(60491,dtype=np.int64);a=t%251;b=t%241
    ta=(-a*217)%241;tb=(b*217)%241
    inp=[((x>>i)&1).astype(bool) for x in [a,ta,tb] for i in range(8)]
    outs=c.evaluate(inp);z=sum(np.asarray(v,dtype=np.int64)<<i for i,v in enumerate(outs))
    want=np.where(t>=30246,t-60491,t)&65535
    assert np.array_equal(z,want)
    count=0
    for x in [0,1,250,251,30245,30246,60490]+np.random.default_rng(67).integers(60491,size=57).tolist():
        g=Garbled(c);a=x%251;b=x%241
        inputs=[(v>>i)&1 for v in [a,(-a*217)%241,(b*217)%241] for i in range(8)]
        out=g.decode(g.evaluate(g.input_labels(inputs)));z=sum(v<<i for i,v in enumerate(out))
        assert z==int(want[x]);count+=1
    return {'exhaustive_crt_cases':60491,'fresh_garbled_crt_cases':count,'and_gates':c.ands,'total_nodes':len(c.nodes),'garbled_core_bytes':16+32*c.ands}
if __name__=='__main__':print(test_crt())
