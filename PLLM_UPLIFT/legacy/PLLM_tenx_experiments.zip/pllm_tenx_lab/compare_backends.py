"""Matched arithmetic-label -> nonlinear -> arithmetic-label comparisons."""
from __future__ import annotations
import json,time,statistics,os
import numpy as np
from boolean_core import Circuit,Garbled,crt_circuit
from logic_baseline import compile_table
from garbled_transducer import vec,delta,label,reduce,pack,unpack,seal,openrow,InputBridge,WeightedGarbled
from weighted_diagrams import Diagram,functions

def compose(first:Circuit,second:Circuit)->Circuit:
    c=first
    mapping={0:0,1:1};mapping.update(zip(second.inputs,first.outputs,strict=True))
    for i,node in enumerate(second.nodes[2:],2):
        if node[0]=='input':continue
        if node[0]=='not':z=c.inv(mapping[node[1]])
        elif node[0]=='xor':z=c.xor(mapping[node[1]],mapping[node[2]])
        else:z=c.land(mapping[node[1]],mapping[node[2]])
        mapping[i]=z
    c.outputs=[mapping[i] for i in second.outputs]
    return c

class BitReturn:
    def __init__(self,gc:Garbled,outbase,d):
        self.rows=[];bases=[vec() for _ in range(15)];bases.append(reduce(outbase-sum(bases)))
        for bit,wire in enumerate(gc.c.outputs):
            context=os.urandom(16);rr=[None,None];weight=(1<<bit) if bit<15 else -(1<<15)
            for value in [0,1]:
                key=gc.zero[wire]^(gc.delta if value else 0)
                rr[key&1]=seal(key.to_bytes(16,'little'),context,pack(label(bases[bit],value*weight,d)))
            self.rows.append((context,rr))
    def evaluate(self,labels):
        out=np.zeros((2,18),dtype=np.int64)
        for value,(context,rows) in zip(labels,self.rows,strict=True):
            out=reduce(out+unpack(openrow(value.to_bytes(16,'little'),context,rows[value&1])))
        return out
    def serialize(self):return b''.join(c+len(r).to_bytes(4,'little')+b''.join(r) for c,r in self.rows)

def main():
    rng=np.random.default_rng(712);out=[];fresh=0
    previous=json.load(open('logic_results.json'))
    for item in previous['functions']:
        name=item['name'];values=functions()[name];best=item['best'];order=list(range(15,-1,-1)) if best['order']=='msb' else list(range(16))
        bc=compile_table(values,order,best['method']);c=compose(crt_circuit(),bc)
        diagram=Diagram(values,list(range(15,-1,-1)));timings={'weighted':[],'boolean':[]};sizes={}
        for rep in range(8):
            b=vec();ob=vec();d=delta();x=int(rng.integers(-30245,30246));enc=label(b,x,d)
            full=Garbled(c);input_full=InputBridge(b,d,full);ret=BitReturn(full,ob,d)
            gcrt=Garbled(crt_circuit());input_dd=InputBridge(b,d,gcrt)
            dd=WeightedGarbled(diagram,[gcrt.zero[i] for i in gcrt.c.outputs],gcrt.delta,ob,d)
            assert not hasattr(input_dd.gc,'delta') and not hasattr(input_dd.gc,'zero')
            sizes={'boolean_bytes':len(input_full.serialize())+len(ret.serialize()),'weighted_bytes':len(input_dd.serialize())+len(dd.serialize())}
            fns={'weighted':lambda:dd.evaluate(input_dd.evaluate(enc)),
                 'boolean':lambda:ret.evaluate(input_full.evaluate(enc))}
            for _ in range(2):
                for fn in fns.values():assert np.array_equal(fn(),label(ob,int(values[x&65535]),d))
            for _ in range(7):
                for mode in rng.permutation(['weighted','boolean']):
                    start=time.perf_counter();v=fns[mode]();timings[mode].append(time.perf_counter()-start)
                    assert np.array_equal(v,label(ob,int(values[x&65535]),d))
            fresh+=1
        med={k:statistics.median(v) for k,v in timings.items()}
        row={'name':name,**sizes,'full_boolean_and_gates':c.ands,'online_seconds':med,'samples':timings,
             'weighted_speedup_vs_boolean':med['boolean']/med['weighted'],
             'weighted_setup_multiplier_vs_boolean':sizes['weighted_bytes']/sizes['boolean_bytes'],'fresh_pairs':8}
        out.append(row);print(name,row['weighted_speedup_vs_boolean'],med,sizes,flush=True)
    with open('backend_comparison.json','w') as f:json.dump({'rows':out,'fresh_pairs':fresh,'notes':['Both paths include the same arithmetic input and output semantics and all conversions.','Both use 128-bit Boolean labels and SHA-256/SHAKE Python references, not production AES backends.','Interleaved timings; repeated identical labels measure performance, not multi-input reuse.']},f,indent=2)
if __name__=='__main__':main()
