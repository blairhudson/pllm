"""Exact additive-edge decision diagrams for fixed finite functions.
No cryptography here: the public compiler canonicalizes residual tables modulo
an additive integer constant. Every path has the same public number of levels.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import numpy as np

@dataclass(frozen=True)
class Node:
    level: int
    low: int
    high: int
    wl: int
    wh: int

class Diagram:
    def __init__(self, values: np.ndarray, order: list[int], additive: bool=True):
        vals = np.asarray(values, dtype=np.int64)
        self.bits=len(order)
        if len(vals)!=1<<self.bits or sorted(order)!=list(range(self.bits)):
            raise ValueError('table size/order mismatch')
        self.order=order[:]; self.nodes: dict[int,Node]={}; self.levels=[[] for _ in order]
        self.additive=additive
        # index in traversal order: the first chosen variable is the MSB
        positions=np.arange(len(vals),dtype=np.int64)
        indices=np.zeros_like(positions)
        for j,bit in enumerate(order): indices |= ((positions>>(self.bits-1-j))&1)<<bit
        ordered=vals[indices]
        memo:dict[tuple[int,bytes],int]={}
        self.leaves:dict[int,int]={}; leaf_ids:dict[int,int]={}
        def visit(v:np.ndarray,level:int)->tuple[int,int]:
            offset=int(v[0]) if additive else 0
            u=v-offset
            if level==self.bits:
                leaf=int(u[0])
                if leaf not in leaf_ids:
                    ident=-(len(leaf_ids)+1);leaf_ids[leaf]=ident;self.leaves[ident]=leaf
                return leaf_ids[leaf],offset
            key=(level,u.tobytes())
            old=memo.get(key)
            if old is not None:return old,offset
            half=len(v)//2
            lo,wl=visit(u[:half],level+1);hi,wh=visit(u[half:],level+1)
            ident=len(self.nodes)
            self.nodes[ident]=Node(level,lo,hi,wl,wh)
            self.levels[level].append(ident);memo[key]=ident
            return ident,offset
        self.root,self.offset=visit(ordered,0)
        self.table_hash=hashlib.sha256(vals.tobytes()).hexdigest()

    def evaluate(self,x:int)->int:
        node=self.root; answer=self.offset
        for level,bit in enumerate(self.order):
            n=self.nodes[node]
            if n.level!=level:raise AssertionError('nonuniform path')
            if (x>>bit)&1:node=n.high;answer+=n.wh
            else:node=n.low;answer+=n.wl
        return answer+self.leaves[node]

    def check_all(self,values:np.ndarray)->None:
        for x,y in enumerate(values):
            if self.evaluate(x)!=int(y):raise AssertionError((x,self.evaluate(x),y))

    def stats(self)->dict:
        return dict(nodes=len(self.nodes),leaves=len(self.leaves),
                    widths=[len(x) for x in self.levels],order=self.order,
                    levels=self.bits,table_sha256=self.table_hash)

def functions(bits:int=16)->dict[str,np.ndarray]:
    raw=np.arange(1<<bits,dtype=np.int64)
    signed=np.where(raw>=(1<<(bits-1)),raw-(1<<bits),raw)
    scale=1<<(bits-4); x=signed/scale
    return {
        'silu_q8':np.rint(256*x/(1+np.exp(-x))).astype(np.int64),
        'clipped_relu':np.minimum(255,np.maximum(0,signed)//32),
        'sigmoid_q12':np.rint(4096/(1+np.exp(-x))).astype(np.int64),
        'exp_q8':np.rint(256*np.exp(x/2)).astype(np.int64),
    }

def main():
    import json,time
    rows=[]
    for name,vals in functions().items():
        for order_name,order in [('msb',list(range(15,-1,-1))),('lsb',list(range(16))),('ends',[15,0,14,1,13,2,12,3,11,4,10,5,9,6,8,7])]:
            t=time.perf_counter();d=Diagram(vals,order);d.check_all(vals)
            row={'function':name,'order_name':order_name,'seconds':time.perf_counter()-t,**d.stats()};rows.append(row)
            print(name,order_name,len(d.nodes),flush=True)
    with open(__file__.replace('weighted_diagrams.py','diagram_results.json'),'w') as f:json.dump(rows,f,indent=2)
if __name__=='__main__':main()
