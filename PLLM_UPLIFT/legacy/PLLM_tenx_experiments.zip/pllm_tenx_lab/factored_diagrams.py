"""Exact affine-edge quotient: canonicalize residuals under offset AND scale.
Scales must be units in every label field. This is an EVBDD-style public
representation, not a new general decision-diagram primitive.
"""
from dataclasses import dataclass
import numpy as np
import hashlib,math,json
from weighted_diagrams import functions
@dataclass(frozen=True)
class Node:
    level:int;low:int;high:int;wl:int;wh:int;sl:int;sh:int
class Factored:
    def __init__(self,values,order,primes=(251,241)):
        self.order=order;self.bits=len(order);self.nodes={};self.levels=[[] for _ in order];self.leaves={-1:0}
        ix=np.arange(len(values));mapped=np.zeros_like(ix)
        for j,b in enumerate(order):mapped|=((ix>>(self.bits-1-j))&1)<<b
        ordered=np.asarray(values,dtype=np.int64)[mapped];memo={}
        def rec(v,lev):
            offset=int(v[0]);u=v-offset;nonzero=u[u!=0]
            if len(nonzero):
                g=int(np.gcd.reduce(np.abs(nonzero)))
                for p in primes:
                    while g%p==0:g//=p
                if nonzero[0]<0:g=-g
            else:g=1
            u=u//g
            if lev==self.bits:return -1,offset,g
            key=(lev,u.tobytes())
            if key in memo:return memo[key],offset,g
            lo,wl,sl=rec(u[:len(u)//2],lev+1);hi,wh,sh=rec(u[len(u)//2:],lev+1)
            ident=len(self.nodes);self.nodes[ident]=Node(lev,lo,hi,wl,wh,sl,sh)
            memo[key]=ident;self.levels[lev].append(ident);return ident,offset,g
        self.root,self.offset,self.scale=rec(ordered,0)
        self.table_hash=hashlib.sha256(np.asarray(values,dtype=np.int64).tobytes()).hexdigest()
    def evaluate(self,x):
        value=self.offset;scale=self.scale;n=self.root
        for b in self.order:
            nd=self.nodes[n]
            if (x>>b)&1:n=nd.high;value+=scale*nd.wh;scale*=nd.sh
            else:n=nd.low;value+=scale*nd.wl;scale*=nd.sl
        return value
    def stats(self):return {'nodes':len(self.nodes),'widths':[len(x) for x in self.levels],'table_sha256':self.table_hash}
if __name__=='__main__':
    rows=[]
    for name,vals in functions().items():
        for ordername,order in [('msb',list(range(15,-1,-1))),('lsb',list(range(16)))]:
            d=Factored(vals,order)
            assert all(d.evaluate(i)==int(x) for i,x in enumerate(vals))
            row={'name':name,'order':ordername,**d.stats()};rows.append(row);print(name,ordername,len(d.nodes),flush=True)
    json.dump(rows,open('factored_diagram_results.json','w'),indent=2)
