"""Single-evaluator weighted branching-program experiment.
Custom research construction, NOT an audited garbling backend. Fresh per use.
All data-dependent paths have exactly 16 levels and opaque random state keys.
"""
from __future__ import annotations
import os,hashlib,json,time,statistics
import numpy as np
from boolean_core import Circuit,Garbled,crt_circuit,test_crt
from weighted_diagrams import Diagram,functions

PRIMES=(251,241); LANES=18; LABEL_BYTES=36

def rv(p,n=18):
    out=[]
    while len(out)<n:out.extend(x for x in os.urandom(2*n) if x<p)
    return np.array(out[:n],dtype=np.int64)
def vec():return np.stack([rv(p) for p in PRIMES])
def reduce(v):return np.stack([np.asarray(v[i],dtype=np.int64)%p for i,p in enumerate(PRIMES)])
def delta():
    d=vec();d[:,-1]=1;return d
def label(b,x,d):return reduce(b+int(x)*d)
def pack(x):return np.asarray(x,dtype=np.uint8).tobytes()
def unpack(x):
    if len(x)!=36:raise ValueError('invalid label size')
    a=np.frombuffer(x,dtype=np.uint8).astype(np.int64).reshape(2,18)
    if any(np.any(a[i]>=p) for i,p in enumerate(PRIMES)):raise ValueError('invalid residue')
    return a
def xor(a,b):return bytes(x^y for x,y in zip(a,b,strict=True))
def seal(key,context,data):
    tag=hashlib.sha256(b'tag'+context+data).digest()[:16]
    return xor(data+tag,hashlib.shake_256(b'pad'+context+key).digest(len(data)+16))
def openrow(key,context,row):
    raw=xor(row,hashlib.shake_256(b'pad'+context+key).digest(len(row)));data,tag=raw[:-16],raw[-16:]
    if tag!=hashlib.sha256(b'tag'+context+data).digest()[:16]:raise ValueError('bad row')
    return data

def bits(v,n=8):return [(int(v)>>i)&1 for i in range(n)]
def packbits(labels):return b''.join(int(v).to_bytes(16,'little') for v in labels)
def unpackbits(raw):
    if len(raw)%16:raise ValueError('bad bit labels')
    return [int.from_bytes(raw[i:i+16],'little') for i in range(0,len(raw),16)]

class InputBridge:
    def __init__(self,base,d,gc:Garbled):
        self.parts=[]
        public=object.__new__(Garbled);public.c=gc.c;public.context=gc.context;public.tables=dict(gc.tables)
        self.gc=public
        for j,p in enumerate(PRIMES):
            context=os.urandom(16);rows=[None]*p
            for x in range(p):
                key=np.asarray((base[j]+x*d[j])%p,dtype=np.uint8).tobytes()
                if j==0:vals=bits(x)+bits((-x*217)%241);wires=gc.c.inputs[:16]
                else:vals=bits((x*217)%241);wires=gc.c.inputs[16:]
                out=[gc.zero[w]^(gc.delta if v else 0) for w,v in zip(wires,vals,strict=True)]
                rows[key[-1]]=seal(key,context,packbits(out))
            self.parts.append((context,rows))
    def evaluate(self,encoded):
        inputs=[]
        for j,(context,rows) in enumerate(self.parts):
            key=np.asarray(encoded[j],dtype=np.uint8).tobytes();inputs+=unpackbits(openrow(key,context,rows[key[-1]]))
        return self.gc.evaluate(inputs)
    def serialize(self):
        return b''.join(context+len(rows).to_bytes(4,'little')+b''.join(rows) for context,rows in self.parts)+self.gc.serialize()

class WeightedGarbled:
    def __init__(self,diagram:Diagram,bitzero:list[int],bitdelta:int,outbase,d):
        if not diagram.additive or list(diagram.leaves.values())!=[0]:raise ValueError('need additive zero-terminal DD')
        self.context=os.urandom(16);self.order=diagram.order[:];self.rows={}
        keys={i:os.urandom(16) for i in list(diagram.nodes)+list(diagram.leaves)}
        potentials={i:vec() for i in diagram.nodes};potentials.update({i:np.zeros((2,18),dtype=np.int64) for i in diagram.leaves})
        potentials[diagram.root]=label(outbase,diagram.offset,d)
        for ident,node in diagram.nodes.items():
            current=keys[ident];rows=[None,None];bit=node.level
            for value,child,w in [(0,node.low,node.wl),(1,node.high,node.wh)]:
                bitlabel=bitzero[self.order[bit]]^(bitdelta if value else 0)
                contribution=reduce(potentials[ident]-potentials[child]+w*d)
                payload=keys[child]+pack(contribution)
                rows[bitlabel&1]=seal(current+bitlabel.to_bytes(16,'little'),self.context,payload)
            self.rows[self.address(current)]=tuple(rows)
        self.root=keys[diagram.root]
        self.end=hashlib.sha256(b'end'+self.context+keys[next(iter(diagram.leaves))]).digest()[:16]
        # Neither keys, potentials, diagram nodes nor semantic table enter evaluator state.
    def address(self,state):return hashlib.sha256(b'address'+self.context+state).digest()[:16]
    def evaluate(self,bitlabels,trace=False):
        state=self.root;out=np.zeros((2,18),dtype=np.int64);visited=[]
        for bit in self.order:
            address=self.address(state);visited.append(address);rows=self.rows[address]
            bl=bitlabels[bit];data=openrow(state+bl.to_bytes(16,'little'),self.context,rows[bl&1])
            state=data[:16];out=reduce(out+unpack(data[16:]))
        if hashlib.sha256(b'end'+self.context+state).digest()[:16]!=self.end:raise ValueError('wrong terminal')
        return (out,visited) if trace else out
    def serialize(self):
        # Sorted random addresses, not semantic insertion order.
        return self.context+self.root+self.end+bytes(self.order)+len(self.rows).to_bytes(4,'little')+b''.join(k+b''.join(self.rows[k]) for k in sorted(self.rows))

class DirectGate:
    def __init__(self,base,outbase,d,values,lo=-30245,hi=30245):
        self.context=os.urandom(16);self.rows={}
        domain=np.arange(lo,hi+1,dtype=np.int64)
        il=np.stack([(base[j]+domain[:,None]*d[j])%p for j,p in enumerate(PRIMES)],axis=1).astype(np.uint8)
        fv=values[domain&65535]
        ol=np.stack([(outbase[j]+fv[:,None]*d[j])%p for j,p in enumerate(PRIMES)],axis=1).astype(np.uint8)
        for a,b in zip(il,ol,strict=True):
            key=a.tobytes();addr=self.address(key);self.rows[addr]=seal(key,self.context,b.tobytes())
    def address(self,key):return hashlib.sha256(b'direct-address'+self.context+key).digest()[:16]
    def evaluate(self,encoded):
        key=pack(encoded);return unpack(openrow(key,self.context,self.rows[self.address(key)]))
    def serialize(self):return self.context+len(self.rows).to_bytes(4,'little')+b''.join(k+self.rows[k] for k in sorted(self.rows))


def main():
    rng=np.random.default_rng(2301);results={'crt':test_crt(),'functions':[],'limitations':[
        'Custom weighted garbling and mixed representation have no complete simulation proof.',
        'Single-process role-separated functional reference; no transformer/GPU/TPS evaluation.',
        '16 fixed decision levels; codebook and all garbled material fresh per semantic input.',
        'Baseline is the previous flat hashed arithmetic-table format, not logrow or optimized Yao.',
        'Exactness is relative to published discrete integer tables generated using NumPy binary64.',
    ]}
    correctness=0;tamper=0
    for name,values in functions().items():
        diagram=Diagram(values,list(range(15,-1,-1)));diagram.check_all(values)
        samples=[];directtimes=[];setup=[];sz=None
        # One actual direct baseline per function (serialized, not a size-only estimate).
        base=vec();ob=vec();d=delta();start=time.perf_counter();direct=DirectGate(base,ob,d,values);direct_setup=time.perf_counter()-start
        direct_size=len(direct.serialize())
        for rep in range(12):
            b=base if rep==0 else vec();o=ob if rep==0 else vec();dd=d if rep==0 else delta()
            gc=Garbled(crt_circuit());start=time.perf_counter();bridge=InputBridge(b,dd,gc)
            bitzero=[gc.zero[i] for i in gc.c.outputs]
            weighted=WeightedGarbled(diagram,bitzero,gc.delta,o,dd);setup.append(time.perf_counter()-start)
            sz={'bridge_bytes':len(bridge.serialize()),'weighted_bytes':len(weighted.serialize())}
            x=int(rng.integers(-30245,30246));encoded=label(b,x,dd)
            start=time.perf_counter();bb=bridge.evaluate(encoded);out,trace=weighted.evaluate(bb,True);samples.append(time.perf_counter()-start)
            assert len(trace)==16 and len(set(trace))==16
            assert np.array_equal(out,label(o,int(values[x&65535]),dd));correctness+=1
            if rep==0:
                start=time.perf_counter();baseline=direct.evaluate(encoded);directtimes.append(time.perf_counter()-start)
                assert np.array_equal(out,baseline)
                # Repeat identical public benchmarking input, not a second semantic assignment.
                for _ in range(24):
                    start=time.perf_counter();direct.evaluate(encoded);directtimes.append(time.perf_counter()-start)
                for _ in range(24):
                    start=time.perf_counter();weighted.evaluate(bridge.evaluate(encoded));samples.append(time.perf_counter()-start)
            # A wrong bit label must not unlock the actual first edge.
            broken=bb.copy();broken[15]^=2
            try:weighted.evaluate(broken)
            except (ValueError,KeyError):tamper+=1
            else:raise AssertionError('tamper accepted')
        row={'name':name,'diagram':diagram.stats(),**sz,'total_setup_bytes':sum(sz.values()),'direct_bytes':direct_size,
             'setup_reduction_factor':direct_size/sum(sz.values()),'fresh_gates':12,
             'hybrid_online_seconds_samples':samples,'direct_online_seconds_samples':directtimes,
             'hybrid_online_seconds_median':statistics.median(samples),'direct_online_seconds_median':statistics.median(directtimes),
             'hybrid_setup_seconds_median':statistics.median(setup),'direct_setup_seconds':direct_setup,
             'input_label_bytes':36,'output_label_bytes':36,'online_prep_calls':0,'intermediate_messages':0}
        results['functions'].append(row);print(name,row['total_setup_bytes'],direct_size,row['setup_reduction_factor'],row['hybrid_online_seconds_median'],flush=True)
    results['fresh_gates_correct']=correctness;results['tampered_labels_rejected']=tamper
    # Plain exact linear-to-nonlinear composition. Actual protected projection tested below.
    values=functions()['silu_q8'];diagram=Diagram(values,list(range(15,-1,-1)))
    block_cases=0;coordinates=0
    for _ in range(4):
        W=rng.integers(-7,8,size=(4,128),dtype=np.int64);x=rng.integers(-50,51,size=128,dtype=np.int64)
        base=np.stack([np.stack([rv(p) for __ in range(128)]) for p in PRIMES]);dd=delta()
        encoded=np.stack([(base[j]+x[:,None]*dd[j])%p for j,p in enumerate(PRIMES)])
        incoming=np.stack([W@encoded[j]%p for j,p in enumerate(PRIMES)])
        incoming_base=np.stack([W@base[j]%p for j,p in enumerate(PRIMES)])
        bound=50*np.abs(W).sum(axis=1);assert np.max(bound)<30246
        for row in range(4):
            ob=vec();gc=Garbled(crt_circuit());bridge=InputBridge(incoming_base[:,row,:],dd,gc)
            wg=WeightedGarbled(diagram,[gc.zero[i] for i in gc.c.outputs],gc.delta,ob,dd)
            answer=wg.evaluate(bridge.evaluate(incoming[:,row,:]))
            target=int(values[int(W[row]@x)&65535]);assert np.array_equal(answer,label(ob,target,dd));coordinates+=1
        block_cases+=1
    results['fresh_public_matrix_blocks']=block_cases;results['protected_matrix_activation_outputs']=coordinates
    with open(__file__.replace('garbled_transducer.py','transducer_results.json'),'w') as f:json.dump(results,f,indent=2)
if __name__=='__main__':main()
