#include <cstdint>
#include <vector>
#include <immintrin.h>
extern "C" {
// AVX-512 VNNI baseline; weights int8, labels uint8, transposed label layout.
void direct(const int8_t* W,const uint8_t* X,int32_t* Y,int m,int n,int k){
 for(int i=0;i<m;i++)for(int c=0;c<k;c++){
  __m512i acc=_mm512_setzero_si512();int j=0;
  for(;j+64<=n;j+=64){auto w=_mm512_loadu_si512(W+(int64_t)i*n+j);auto x=_mm512_loadu_si512(X+(int64_t)c*n+j);acc=_mm512_dpbusd_epi32(acc,x,w);}
  int64_t s=_mm512_reduce_add_epi32(acc);
  for(;j<n;j++)s+=(int)W[(int64_t)i*n+j]*(int)X[(int64_t)c*n+j];
  int p=c<18?251:241;int z=s%p;Y[(int64_t)i*k+c]=z<0?z+p:z;
 }
}
void four_russians(const uint16_t* patterns,const uint8_t* X,int32_t* Y,int m,int n,int k,int g){
 int blocks=(n+g-1)/g, count=1<<g;
 std::vector<uint16_t> table((int64_t)blocks*count*k);
 for(int b=0;b<blocks;b++)for(int s=1;s<count;s++){
  int bit=__builtin_ctz((unsigned)s),last=s&(s-1),j=b*g+bit;
  auto dst=table.data()+((int64_t)b*count+s)*k;auto src=table.data()+((int64_t)b*count+last)*k;
  for(int c=0;c<k;c++)dst[c]=src[c]+(j<n?X[(int64_t)c*n+j]:0);
 }
 for(int i=0;i<m;i++){
  std::vector<int32_t> accum(4*k,0);
  for(int b=0;b<blocks;b++)for(int bit=0;bit<4;bit++){
   int pat=patterns[((int64_t)i*blocks+b)*4+bit];auto src=table.data()+((int64_t)b*count+pat)*k;auto dst=accum.data()+bit*k;
   for(int c=0;c<k;c++)dst[c]+=src[c];
  }
  for(int c=0;c<k;c++){
   int s=accum[c]+2*accum[k+c]+4*accum[2*k+c]-8*accum[3*k+c];int p=c<18?251:241;int z=s%p;Y[(int64_t)i*k+c]=z<0?z+p:z;
  }
 }
}
}
