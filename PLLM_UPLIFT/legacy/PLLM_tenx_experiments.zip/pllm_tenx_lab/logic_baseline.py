"""Stronger non-novel baseline: shared Shannon/Davio XOR-AND logic synthesis.
The circuit evaluates every gate; no data-dependent public branch is exposed.
"""
from __future__ import annotations
import json,time,hashlib
import numpy as np
from boolean_core import Circuit,Garbled,crt_circuit
from weighted_diagrams import functions

def compile_table(values,order,method='davio',outbits=16):
    c=Circuit();variables=[c.inp() for _ in order];n=len(order)
    ix=np.arange(1<<n,dtype=np.int64);mapped=np.zeros_like(ix)
    for j,bit in enumerate(order):mapped|=((ix>>(n-j-1))&1)<<bit
    vals=np.asarray(values,dtype=np.int64)[mapped];memo={}
    def rec(v,level):
        flip=bool(v[0]);u=np.logical_xor(v,flip)
        if not np.any(u):return int(flip)
        key=(level,np.packbits(u,bitorder='little').tobytes())
        if key in memo:r=memo[key]
        else:
            lo,hi=np.split(u,2);l=rec(lo,level+1)
            if method=='davio':d=rec(np.logical_xor(lo,hi),level+1)
            else:d=c.xor(l,rec(hi,level+1))
            r=c.xor(l,c.land(variables[order[level]],d));memo[key]=r
        return c.inv(r) if flip else r
    c.outputs=[rec(((vals>>b)&1).astype(bool),0) for b in range(outbits)]
    return c

def main():
    rng=np.random.default_rng(515);results=[];fresh=0
    for name,table in functions().items():
        rows=[];best=None;best_c=None
        for method in ['shannon','davio']:
            for ordername,order in [('msb',list(range(15,-1,-1))),('lsb',list(range(16)))]:
                start=time.perf_counter();c=compile_table(table,order,method);duration=time.perf_counter()-start
                row={'method':method,'order':ordername,'and_gates':c.ands,'all_nodes':len(c.nodes),'compile_seconds':duration};rows.append(row)
                if best is None or c.ands<best['and_gates']:best=row;best_c=c
        c=best_c
        raw=np.arange(65536,dtype=np.int64);inp=[((raw>>b)&1).astype(bool) for b in range(16)]
        out=c.evaluate(inp);got=sum(np.asarray(v,dtype=np.int64)<<i for i,v in enumerate(out))
        assert np.array_equal(got,table&65535)
        timings=[]
        for _ in range(8):
            x=int(rng.integers(65536));g=Garbled(c);labels=g.input_labels([(x>>b)&1 for b in range(16)])
            start=time.perf_counter();result=g.evaluate(labels);timings.append(time.perf_counter()-start)
            decoded=sum(v<<i for i,v in enumerate(g.decode(result)));assert decoded==int(table[x]&65535);fresh+=1
        # Full 16-bit signed output -> two arithmetic residues: a two-row
        # Boolean-label keyed projection per bit, encoding +/-2**bit Delta
        # with base shares summing to the desired output base. Data-only formula.
        bit_to_arithmetic=16*(16+4+2*(36+16))
        input_bridge=106168
        results.append({'name':name,'profiles':rows,'best':best,
                        'core_bytes':16+32*c.ands,
                        'bit_to_arithmetic_bytes_formula':bit_to_arithmetic,
                        'total_bytes_with_bridges_formula':input_bridge+16+32*c.ands+bit_to_arithmetic,
                        'core_evaluation_seconds':timings,'exhaustive_cases':65536})
        print(name,best,results[-1]['total_bytes_with_bridges_formula'],flush=True)
    with open('logic_results.json','w') as f:json.dump({'functions':results,'fresh_garbled_evaluations':fresh},f,indent=2)
if __name__=='__main__':main()
