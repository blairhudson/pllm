"""Explicit failures of tempting shortcuts. Not attacks on the retained design."""
from __future__ import annotations
import hashlib, json, os
from collections import Counter
import numpy as np
from weighted_diagrams import Diagram, functions
from garbled_transducer import PRIMES, delta, reduce

P = PRIMES[0] * PRIMES[1]

def crt_signed(a: int, b: int) -> int:
    x = a + 251 * (((b - a) * 217) % 241)
    return int(x if x <= P // 2 else x - P)

def visible_potential(key: bytes) -> np.ndarray:
    # Deliberately unsafe: evaluator knows key, hence knows this potential.
    words = np.frombuffer(hashlib.shake_256(b'unsafe-potential' + key).digest(288), dtype='<u8')
    return np.stack([words[i*18:(i+1)*18] % p for i, p in enumerate(PRIMES)]).astype(np.int64)

def main() -> None:
    rng = np.random.default_rng(2305)
    result = {'scope': 'Negative controls: intentionally weakened constructions, not security proofs.'}
    collisions = []
    for name, values in functions().items():
        for modulus in (251, 241, 256, 4096):
            seen = {}; example = None
            for x in range(-30245, 30246):
                residue = x % modulus; y = int(values[x & 65535])
                if residue in seen and seen[residue][1] != y:
                    a, fa = seen[residue]
                    example = {'x': a, 'other_x': x, 'same_residue': residue,
                               'f_x': fa, 'f_other': y}
                    break
                seen[residue] = (x, y)
            assert example is not None
            collisions.append({'function': name, 'input_modulus': modulus, **example})
    result['unsafe_input_domain_folding'] = collisions

    values = functions()['clipped_relu']; histogram = Counter(); recovered = 0
    for raw in range(65536):
        depth = 0
        while depth < 16:
            size = 1 << (16-depth); start = (raw // size) * size
            if np.all(values[start:start+size] == values[start]): break
            depth += 1
        histogram[depth] += 1
        predicted_negative = depth == 1
        recovered += int(predicted_negative == (raw >= 32768))
    assert recovered == 65536
    result['unsafe_early_termination'] = {
        'depth_histogram': dict(sorted(histogram.items())),
        'input_signs_recovered_from_path_length': recovered,
        'tested_inputs': 65536,
        'retained_design': 'Every path is padded to exactly 16 decision levels.'}

    cases = 0; edge_checks = 0
    for name, values in functions().items():
        diagram = Diagram(values, list(range(15,-1,-1)))
        for _ in range(64):
            dd = delta(); raw = int(rng.integers(0,65536))
            keys = {i: os.urandom(16) for i in list(diagram.nodes) + list(diagram.leaves)}
            pot = {i: visible_potential(k) for i, k in keys.items()}
            state = diagram.root; recovered_output = diagram.offset
            for bit in diagram.order:
                node = diagram.nodes[state]; value = (raw >> bit) & 1
                child, weight = (node.high,node.wh) if value else (node.low,node.wl)
                contribution = reduce(pot[state] - pot[child] + weight*dd)
                # These two state keys and the decrypted contribution are visible online.
                unmasked = reduce(contribution - visible_potential(keys[state]) + visible_potential(keys[child]))
                found_weight = crt_signed(int(unmasked[0,-1]), int(unmasked[1,-1]))
                assert found_weight == weight
                recovered_output += found_weight; edge_checks += 1; state = child
            assert recovered_output == int(values[raw]); cases += 1
    result['unsafe_public_potentials'] = {
        'outputs_recovered': cases, 'edge_weights_recovered': edge_checks,
        'reason': 'Known potentials expose weight*Delta; Delta permutation coordinate is one.',
        'retained_design': 'Node potentials are independently secret and never derived from evaluator-visible state keys.'}
    with open(__file__.replace('attack_controls.py','attack_results.json'),'w') as f: json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k != 'unsafe_input_domain_folding'},indent=2))
if __name__ == '__main__': main()
