# PLLM 10× component-search laboratory

Read `REPORT.md` first. This is research code, not a private-inference product or a security-audited library.

## Reproduce

Python 3.11+ and NumPy/threadpoolctl are required. Captured versions are pinned in `requirements.txt`. Run from this directory:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python weighted_diagrams.py
python garbled_transducer.py
python logic_baseline.py
python compare_backends.py
python factored_diagrams.py
python attack_controls.py
```

The optional kernel tests additionally require g++, Linux x86-64 and AVX-512 VNNI:

```sh
python kernel_experiments.py
```

That command compiles `lut_kernels.cpp` locally. Do not run the compiled kernel on a CPU that lacks AVX-512 VNNI. No precompiled native library is included in the archive.

Each program writes its own JSON results. Re-running changes fresh cryptographic values and timings; table definitions, exact algebra and public byte counts should be stable. `compare_backends.py` reads the circuit profiles in `logic_results.json`, so run synthesis first. No network access, API credentials, model download or external service is used by the experiments.

## Files

- `weighted_diagrams.py`: additive-edge finite-function compiler and exhaustive checks.
- `boolean_core.py`: Boolean circuit builder, half-gates reference and CRT conversion.
- `garbled_transducer.py`: flat lookup and weighted transducer with complete arithmetic input bridge; exact matrix-to-gate tests.
- `logic_baseline.py`: shared Shannon/Davio synthesis with four candidate profiles.
- `compare_backends.py`: full arithmetic-input/output matched Boolean/transducer comparisons.
- `factored_diagrams.py`: public multiplicative-plus-additive diagram experiment; not a garbled implementation.
- `lut_kernels.cpp`, `kernel_experiments.py`: exact subset-sum/VNNI and wide-field kernel comparisons.
- `attack_controls.py`: deliberately unsafe shortcuts and explicit recovery attacks.
- `*_results.json`, `backend_comparison.json`: captured results and raw samples.
- `environment.json`: actual captured runtime versions and CPU.
- `MANIFEST.sha256`: integrity hashes for the packaged files.

The programs deliberately expose garbler and plaintext state to the outer test harness. The online evaluator objects omit those secrets, but this is not network isolation or a production trust boundary. Cryptographic tests use fresh instances; timing repeats the same semantic input. No different-input garbling reuse is supported or asserted safe.
