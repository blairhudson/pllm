---
title: "PLLM: Private Multi-Party Inference and an Extensible Research Harness"
author: |
  Blair Hudson  
  deployscience labs  
  [blair@deployscience.com](mailto:blair@deployscience.com)
date: 23 September 2026
web-date: September 2026
edition: "08"
description: How PLLM separates private LLM inference roles and turns independently implemented research into measurable capabilities.
pdf: whitepaper.pdf
subject: private LLM inference, multi-party systems, autonomous research harness, reproducible benchmarks
documentclass: article
classoption: [10pt]
papersize: letter
geometry: [margin=0.74in]
colorlinks: false
indent: false
---

## Why PLLM

PLLM is a **high-performance private LLM multi-party inference runtime and
extensible autonomous research harness**. A hosted endpoint ordinarily receives
the request it computes on. PLLM instead aims to give separate operators useful
work without granting either remote role the complete activation. Its second
job: turn independently implemented research into compatible components that
can be tested against a common baseline, rather than accepting paper-reported
speedups across different models and trust assumptions.

High performance and economic value are **objectives**, not conclusions drawn
from the present measurements. A faster isolated kernel is not automatically a
faster, private, deployable model.

## One private request

Client keeps prompts, tokenization, nonlinear and attention state, masks,
sampling, and output. Before generation, trusted Preparation expands fresh
stage seeds and uploads one-use masked corrections for public model matrices.
Online, Inference receives a ticket and masked activation; Client reconstructs
the result. Preparation is idle online. A trusted local gateway can expose
Responses and Chat Completions APIs without turning the remote roles into
application endpoints.

![Offline and online work across Client, Preparation, and Inference. Each correction row is used once.](paper/figures/mechanics.png)

Preparation must follow the protocol, erase masks, and **not collude** with
Inference; co-located loopback processes do not demonstrate independent
operators. The current public path keeps attention, nonlinear work, and token
boundaries local to Client. It does not establish malicious-provider security.

## Research becomes a candidate capability

Researchers implement pinned papers through typed component or provider
contracts. Immutable experiments bind model, composition, workload, and
deployment. Bounded search proposes **valid** candidates; matched benchmarks
retain failures. Functional, numeric, privacy, quality, and deployment checks
gate adoption.

![From paper provenance to a typed implementation, compatible plan, matched evidence, and an eligible deployment choice.](paper/figures/research-loop.png)

This is an autonomous *experiment-enabling* loop, not automatic paper-to-code
translation or security certification. Papers are provenance, never executable
dependencies. Static provider manifests support discovery; native provider
runtime loading is not yet exposed. New research can improve a deployed choice
only when an implementation passes these gates and beats its **eligible matched
baseline**. No winner crosses different model, privacy, numeric, hardware,
input/output-token, output-cap, or warm-state cohorts by assumption.

## Economic value needs an honest denominator

A candidate can be economically useful if it meets the same privacy, model
quality, and service constraints while reducing *total cost per successful
response*: client work, offline preparation (including burned rows), online
compute, network, and operator resources. Latency, throughput, traffic, and
quality have different units; a single speed number cannot replace this
accounting. PLLM represents metrics and matched benchmark results, but **has
not measured prices, energy, or an economic return**, nor established an
external state-of-the-art winner. Economic value is a testable hypothesis.

## Measured baseline; open comparison

One retained study ran Client, Preparation, and Inference on an Apple M5
loopback host using a pinned Qwen2.5-0.5B-Instruct checkpoint. Three warm
measurements per *different* input/output-token cohort give these full-response
medians (including offline preparation). They are historical measurements from
an earlier runtime revision, not current compiler or WAN results.

![Historical Qwen2.5-0.5B full-response medians for three distinct token cohorts; no cross-system performance claim.](paper/figures/qwen-baseline.png)

Optional client-side verification now also has a separate one-response, pinned
Qwen2.5 four-topology diagnostic. It kept prepared **online** bodies unchanged
but added offline material; full compute and network cost remain unknown.
Garbling and cache transformations remain bounded or uncomposed, not
whole-model Qwen speedups. Next: complete protected decoder
coverage, deploy genuinely independent roles, and compare alternatives on the
same checkpoint and workload with measured cost and quality. The
[technical paper](https://pllm.run/research/paper/) records precise methods,
paper-derived components, evidence, and missing comparisons.
